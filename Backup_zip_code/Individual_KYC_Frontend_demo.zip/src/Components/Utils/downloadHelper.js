export default async function downloadFile({ endpoint = '/media_pep_report_download', body = null, tab, name, filename }) {
  const apiBase = process.env.REACT_APP_API_BASE_URL || 'http://127.0.0.1:5003'
  const url = `${apiBase}${endpoint.startsWith('/') ? '' : '/'}${endpoint}`

  let payload = body || (tab || name ? { tab, name } : {})

  // If requesting the final entity/individual report, ensure backend gets `name`
  if (endpoint.includes('download_entity_final_report')) {
    if (body && body.entity && !body.name) {
      payload = { name: body.entity }
    } else if (!body && name) {
      payload = { name }
    }
  }

  try {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    if (!res.ok) throw new Error(`Server returned ${res.status} ${res.statusText}`)
    const blob = await res.blob()
    if (!blob || blob.size === 0) throw new Error('Empty response from server')
    const href = window.URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = href
    // Preserve file extension if provided, default to .txt
    // pick sensible default filename and extension
    if (endpoint.includes('download_entity_final_report')) {
      a.download = filename || `${name || (payload && payload.name) || 'KYC_Report'}.pdf`
    } else {
      a.download = filename || `${name || 'report'}.txt`
    }
    document.body.appendChild(a)
    a.click()
    a.remove()
    window.URL.revokeObjectURL(href)
    return true
  } catch (err) {
    throw err
  }
}
