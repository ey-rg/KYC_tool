import React, {useEffect, useState} from 'react'
import { connect } from 'react-redux';
import { Badge, Form, Button } from 'react-bootstrap';
import BasicTable from '../Utils/BasicTable';
import LayoutLoading from '../Utils/LayoutLoading';
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import axios from 'axios';
import documentUploadCss from './DocumentUpload.module.css';
import { messageService } from '../Utils/messageService';
import CustomModal from '../Utils/CustomModal';
import { MissingattributesIcon } from '../../assets/images';
import MissAttributes from './MissAttributes';

function BusinessTypeRisk({entityDetails}) {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedRow, setSelectedRow] = useState(null);
    const [notes, setNotes] = useState('');
    const [showMissAttributes, setShowMissAttributes] = useState(false);

    const headers = [
        { Header:"KYC Attributes", accessor:"Detail",
        Cell:(props) => {
          return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
        }
        },
        { Header:"Previous Details", accessor:"company_database"},
        { Header:"Latest Details", accessor:"llm",
        Cell:(props) => {
          return <span style={{color:"#0863f1"}}>{props.value}</span>
        }
        },
        { Header:"Source", accessor: "source"},        
        { Header:"Review Status", accessor:"matcher_li",
        Cell:(props) => {
          if (props.value === "Not Matched") {
            return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          } else if (props.value === "Matched") {
              return <span style={{color: "#6c757db3"}}>{props.value}</span>
          } else {
              return <span>{props.value}</span>
          }
        }
        },
        // { Header:"Company Database Update", accessor:"update_database",
        // Cell:(props) => {
        //     if (props.value === 'Required') {
        //        return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
        //     } else {
        //        return <span>{props.value}</span>
        //     }
        // }
        // },
        { Header:"Risk Status", accessor: "risk_status",
          Cell:(props) => {
            if (props.value === "Low") {
                return <Badge bg="success" className={documentUploadCss.badge}>{props.value}</Badge>
            } else {
                return <Badge bg="danger" className={documentUploadCss.badge}>{props.value}</Badge>
            }
          }
        },
        { Header: "", accessor: "Comment"}
    ]

    useEffect(() => {
    setLoading(true)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/entity_details`, {"tab": "business_type",
    "entity": entityDetails.entityName})
    .then(response => {
        setLoading(false)
        setData(response.data.output)
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant:"danger", message: "server problem"})
    })
    }, [])  
    
    return (
    <>
    <img src={MissingattributesIcon} alt="missingAttribute" style={{width: "45px"}} className={documentUploadCss.attributes}/>
    <Button className={`${documentUploadCss.attributes} backgroundDanger`} variant='danger' 
    onClick={() => setShowMissAttributes(true)}>Missing Attributes</Button>
    <div>
    <BasicTable availableColumns={headers} data={data} setSelectedData={setSelectedRow}></BasicTable>
    </div>
    {
        loading &&
        <LayoutLoading message="Loading"/>
    }
    {
      selectedRow !== null &&
      <CustomModal onHideHandler={() => setSelectedRow(null)}
            modalHeader={selectedRow.Detail}>
            <Form.Control as="textarea"
            name="inputText"
            style={{resize:"None", height:"150px"}}
            required
            className={documentUploadCss.notes}
            value={notes}/>
            <Button variant="success" className={documentUploadCss.upload}>Save</Button>     
        </CustomModal>
    }
    {
    showMissAttributes &&
    <CustomModal onHideHandler={() => setShowMissAttributes(false)} modalHeader='Missing Attributes'>
     <MissAttributes />
    </CustomModal>
  }
    </>
   )
}

const mapStateToProp = (state) => {
    return {
      entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(BusinessTypeRisk)
