import React, { useEffect, useState } from 'react'
import BasicTable from '../Utils/BasicTable'
import { connect } from 'react-redux'
import { selectEntityDetails } from '../../redux/entityDetails/selector'
import axios from 'axios'
import LayoutLoading from '../Utils/LayoutLoading'
import { Badge } from 'react-bootstrap'
import documentUploadCss from './DocumentUpload.module.css'
import { messageService } from '../Utils/messageService'
import { downloadIcon } from '../../assets/images'
import DoughnutChart from '../Utils/DoughnutChart'
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
} from 'chart.js'
import ChartDataLabels from 'chartjs-plugin-datalabels'

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  ChartDataLabels,
  Legend
)

// Note: DownloadReport moved inside component to manage loading state properly
// Function definition moved to component body - see useCallback below

function Screening({ entityDetails }) {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)

  // Issue: DownloadReport was defined outside component, moved inside with proper loading state management
  const DownloadReport = (tab, name, filename) => {
    setLoading(true)
    const apiBaseUrl = process.env.REACT_APP_API_BASE_URL || "http://127.0.0.1:5003"
    fetch(`${apiBaseUrl}/media_pep_report_download`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ tab, name })
    })
      .then(res => {
        if (!res.ok) throw new Error(`Server returned ${res.status}: ${res.statusText}`)
        return res.blob()
      })
      .then(blob => {
        if (blob.size === 0) throw new Error("Server returned empty response")
        const url = window.URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = filename || "report.txt"
        document.body.appendChild(a)
        a.click()
        a.remove()
        window.URL.revokeObjectURL(url)
        messageService.sendMessage({ variant: "success", message: "Report downloaded successfully" })
      })
      .catch(err => {
        console.error("Download failed:", err)
        messageService.sendMessage({ variant: "danger", message: `Download failed: ${err.message}` })
      })
      .finally(() => {
        setLoading(false)
      })
  }
  const [loadingMsg, setLoadingMsg] = useState("Loading")

  const headers = [
    {
      Header: "Name",
      accessor: "name",
      Cell: props => (
        <span style={{ fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)" }}>
          {props.value}
        </span>
      )
    },
    {
      Header: "NNS Summary",
      accessor: "media_screening_summary",
      Cell: ({ value, row }) => {
        const allReferences = row.original.references || [];

        // Define the hardcoded URLs per source type
        // const sourceLinks = {
        //   "Source 1": { source: "Times of India", url: "https://timesofindia.indiatimes.com" },
        //   "Source 2": { source: "Twitter", url: "https://x.com" }
        // };

         const sourceLinks = {
          "Source 1": { source: "Times of India", url: "https://en.antaranews.com/news/392045/bali-tightens-rules-to-stop-foreign-investment-encroaching-locals"},
          "Source 2": { source: "Twitter", url: "https://x.com/RT_com/status/1654644649359818754"}
        };

        // Decide which source key applies based on summary text
        let filteredReferences = [];

        if (value && value.includes("Source 1")) {
          // Show only Times of India link
          filteredReferences = [sourceLinks["Source 1"]];
        } else if (value && value.includes("Source 2")) {
          // Show only Twitter link
          filteredReferences = [sourceLinks["Source 2"]];
        } else {
          // Show whatever references come from API (deduplicated)
          const seenSources = new Set();
          filteredReferences = allReferences.filter(ref => {
            if (!seenSources.has(ref.source)) {
              seenSources.add(ref.source);
              return true;
            }
            return false;
          });
        }

        return (
          <span style={{ fontSize: "12px" }}>
            {value || "—"}

            {filteredReferences.length > 0 && (
              <>
                {" "}
                (
                {filteredReferences.map((ref, index) => (
                  <span key={index}>
                    <a
                      href={ref.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      style={{ textDecoration: "underline" }}
                      title={ref.url}
                    >
                      {ref.url}
                    </a>
                    {index < filteredReferences.length - 1 && " | "}
                  </span>
                ))}
                )
              </>
            )}
          </span>
        );
      }
    },
    {
      Header: "Sentiment Analysis",
      accessor: "sentiment_analysis",
      Cell: props => {
        const splitArray = {}
        const a = props.value.split('% Positive,')
        const b = a.length !== 0 ? a[1].split('% Negative,') : []
        const c = b.length !== 0 ? b[1].split('% Neutral') : []
        splitArray.labels = ['Positive', 'Negative', 'Neutral']
        splitArray.values = [Number(a[0]), Number(b[0]), Number(c[0])]
        // return <DoughnutChart chartData={splitArray} />
        return (
          <div style={{ width: "100px" }}>
            <DoughnutChart chartData={splitArray} />

            {/* Custom legend */}
            <div className="d-flex justify-content-center gap-2 mt-1" style={{ fontSize: "10px" }}>
              <span style={{ display: "inline-flex", alignItems: "center", gap: "4px" }}>
                <span style={{ color: '#198754' ,fontSize: "16px" }}>●</span> Positive
              </span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: "4px" }}>
                <span style={{ color: '#dc3545' ,fontSize: "16px" }}>●</span> Negative
              </span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: "4px" }}>
                <span style={{ color: 'grey' ,fontSize: "16px"}}>●</span> Neutral
              </span>
            </div>
          </div>
        )
      }
    },
    {
      Header: "Risk Status",
      accessor: "media_screening_result",
      Cell: props => {
        if (props.value === "Low") {
          return <Badge bg="success" className={documentUploadCss.badge}>{props.value}</Badge>
        } else if (props.value === "High") {
          return <Badge bg="danger" className={documentUploadCss.badge}>{props.value}</Badge>
        } else {
          return <span className={`backgroundColor ${documentUploadCss.badge}`}>{props.value}</span>
        }
      }
    },
    {
      Header: "NNS Report",
      accessor: "source",
      Cell: ({ row }) => (
        <img
          src={downloadIcon}
          alt="download"
          title="Download report"
          style={{ cursor: "pointer" }}
          onClick={() =>
            DownloadReport(
              "media_screen",
              row.original.name,
              row.original.name + "_report.txt"
            )
          }
        />
      )
    }
  ]

  // ==================== End here

  useEffect(() => {
    setLoading(true)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/media_pep_screen_result`, {
      tab: "media_screen",
      entity: entityDetails.entityName
    })
      .then(response => {
        setLoading(false)
        setData(response.data.output)
      })
      .catch(error => {
        setLoading(false)
        messageService.sendMessage({ variant: "danger", message: "server problem" })
      })
  }, [entityDetails.entityName])

  return (
    <>
      <div>
        <BasicTable availableColumns={headers} data={data} tableDivExtraStyle={{ height: "400px" }} />
      </div>
      {loading && <LayoutLoading message={loadingMsg} />}
    </>
  )
}

const mapStateToProp = state => ({
  entityDetails: selectEntityDetails(state)
})

export default connect(mapStateToProp, null)(Screening)
