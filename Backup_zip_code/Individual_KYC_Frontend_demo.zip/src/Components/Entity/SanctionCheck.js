import React, {useEffect, useState} from 'react'
import BasicTable from '../Utils/BasicTable'
import { connect } from 'react-redux'
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import axios from 'axios';
import LayoutLoading from '../Utils/LayoutLoading';
import { Badge } from 'react-bootstrap';
import documentUploadCss from './DocumentUpload.module.css';
import { messageService } from '../Utils/messageService';
import { downloadIcon } from '../../assets/images';
import downloadFile from '../Utils/downloadHelper';

function SanctionCheck() {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);

    const headers = [
        { Header:"Name", accessor:"name",
          Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)"}}>{props.value}</span>
          }
        },
        { Header:"Number of Hits", accessor:"sanaction_summary"},
        { Header: "Source", accessor: "source",
          Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)"}}>{props.value}</span>
        }
        },
        { Header:"Sanction Result", accessor:"sanaction_result",
        Cell:(props) => {
            if (props.value === "Matched") {
              return <span style={{fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)"}}>{props.value}</span>
            } else if (props.value === "Not Matched") {
              return <span style={{color: "#6c757db3", fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)"}}>{props.value}</span>
            } else {
              return <span style={{fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)"}}>{props.value}</span>
            }
        }
        },
        { Header:"Sanction Status", accessor: "sanaction_status",
          Cell:(props) => {
            if (props.value === "Low") {
                return <Badge bg="success" className={documentUploadCss.badge}>{props.value}</Badge>
            } else {
                return <Badge bg="danger" className={documentUploadCss.badge}>{props.value}</Badge>
            }
          }
        },
        { Header:"Sanction Report", accessor:"matcher_li",
        Cell: (props) => {
          return <img src={downloadIcon} alt="download" onClick={() => DownloadReport(props.row)}/>
        }
        }
    ]

    const DownloadReport = async (row) => {
      setLoading(true)
      try {
        await downloadFile({ endpoint: '/media_pep_report_download', tab: 'sanction_screen', name: row.values.name, filename: `report_${row.values.name}.txt` })
        setLoading(false)
        messageService.sendMessage({ variant: 'success', message: 'Report downloaded' })
      } catch (err) {
        setLoading(false)
        console.error('Download error', err)
        messageService.sendMessage({ variant: 'danger', message: `Download failed: ${err.message}` })
      }
    }

    useEffect(() => {
    setLoading(true);
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/media_pep_screen_result`, {"tab": "sanaction_screen"})
    .then(response => {
        setLoading(false)
        setData(response.data.output)
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message:"server problem"})
    })
    }, [])  
    
    return (
    <>
    <div>
    <BasicTable availableColumns={headers} data={data}></BasicTable>
    </div>
    {
        loading &&
        <LayoutLoading message="Fetching Data"/>
    }
    </>
   )
}

const mapStateToProp = (state) => {
    return {
      entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(SanctionCheck)
