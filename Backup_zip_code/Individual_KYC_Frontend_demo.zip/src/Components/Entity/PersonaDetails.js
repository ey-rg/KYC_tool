import React, { useEffect, useState } from 'react'
import axios from 'axios';
import BasicTable from '../Utils/BasicTable';
import LayoutLoading from '../Utils/LayoutLoading';
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import { connect } from 'react-redux';
import { messageService } from '../Utils/messageService';
import { Form, Button } from 'react-bootstrap';
import CustomModal from '../Utils/CustomModal';
import documentUploadCss from './DocumentUpload.module.css'
import { personHierarchy } from '../../assets/images';
import Hierarchy from './Hierarchy';
import { MissingattributesIcon } from '../../assets/images';
import MissAttributes from './MissAttributes';

function PersonaDetails({ entityDetails }) {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(false);
  const [selectedRow, setSelectedRow] = useState(null);
  const [notes, setNotes] = useState('');
  const [persHierarchy, setpersHierchy] = useState(false);
  const [showMissAttributes, setShowMissAttributes] = useState(false);

  const headers = [
    {
      Header: "KYC Attributes", accessor: "Detail",
      Cell: (props) => {
        return <span style={{ fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
      }
    },
    { Header: "Previous Details", accessor: "company_database",
    Cell: (props) => {
      const splitArray = props.value.split(',')
            return (
              <span>
              {
                splitArray.map(element => (
                  <div>{element}</div>
                ))
              }
              </span>
            )
    }
    },
    {
      Header: "Latest Details", accessor: "llm",
      Cell: (props) => {
        const splitArray = props.value.split(',')
        return (
          <span>
          {
            splitArray.map(element => (
              <div style={{color:"#0863f1"}}>{element}</div>
            ))
          }
          </span>
        )      
      }
    },
    { Header: "Source", accessor: "source" },
    {
      Header: "Review Status", accessor: "matcher_li",
      Cell: (props) => {
        if (props.value === "Not Matched") {
          return <span style={{ fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
        } else if (props.value === "Matched") {
          return <span style={{ color: "#6c757db3" }}>{props.value}</span>
        } else {
          return <span>{props.value}</span>
        }
      }
    },
    // {
    //   Header: "Company Database Update", accessor: "update_database",
    //   Cell: (props) => {
    //     if (props.value === 'Required') {
    //       return <span style={{ fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
    //     } else {
    //       return <span>{props.value}</span>
    //     }
    //   }
    // }
  ]

  const personHierarchyHandler = () => {
    setpersHierchy(true);
  }

  useEffect(() => {
    setLoading(true)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/entity_details`, {
      "tab": "personal_verification",
      "entity": entityDetails.entityName
    })
      .then(response => {
        setLoading(false)
        setData(response.data.output)
      })
      .catch(error => {
        setLoading(false)
        messageService.sendMessage({ variant: "danger", message: "Server Problem" })
      })
  }, [])

  return (
    <>
        <img src={personHierarchy} alt="personHierarchy" className={documentUploadCss.hierarchy} onClick={personHierarchyHandler}/>
        <img src={MissingattributesIcon} alt="missingAttribute" style={{width: "45px"}} className={documentUploadCss.attributes}/>
    <Button className={`${documentUploadCss.attributes} backgroundDanger`} variant='danger' 
    onClick={() => setShowMissAttributes(true)}>Missing Attributes</Button>
      <div>
        <BasicTable availableColumns={headers} data={data} setSelectedData={setSelectedRow}></BasicTable>
      </div>
      {
        loading &&
        <LayoutLoading message="Loading" />
      }
      {
        selectedRow !== null &&
        <CustomModal onHideHandler={() => setSelectedRow(null)}
          modalHeader={selectedRow.Detail}>
          <Form.Control as="textarea"
            name="inputText"
            style={{ resize: "None", height: "150px" }}
            required
            className={documentUploadCss.notes}
            value={notes} />
          <Button variant="success" className={documentUploadCss.upload}>Save</Button>
        </CustomModal>
      }
      {
    persHierarchy &&
    <CustomModal onHideHandler={() => setpersHierchy(false)} modalHeader="Ownership Hierarchy" fullscreen={true}>
     <Hierarchy tab="ownership_hierarchy" />
    </CustomModal>
  }
    {
    showMissAttributes &&
    <CustomModal onHideHandler={() => setShowMissAttributes(false)} modalHeader='Missing Attributes'>
     <MissAttributes />
    </CustomModal>
  }
    </>
  )
}

const mapStateToProp = (state) => {
  return {
    entityDetails: selectEntityDetails(state)
  }
}

export default connect(mapStateToProp, null)(PersonaDetails)
