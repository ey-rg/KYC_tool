import React, { useState } from 'react'
import { Breadcrumb, Alert, Modal } from 'react-bootstrap'
import EntityFlowModuleCss from './EntityFlow.module.css'
import { selectEntityDetails } from '../../redux/entityDetails/selector'
import { connect } from 'react-redux'
import EntityDetails from './EntityDetails'
import DocumentUpload from './DocumentUpload'
import MediaScreening from './MediaScreening'
import Summary from './Summary'
import { messageService } from '../Utils/messageService'
import { arrowRight, chatIcon, chatbot, OrgIcon, user,userLogo } from '../../assets/images'
import LayoutLoading from "../Utils/LayoutLoading";
import Home from './Home'
import EDD from './EDD'
import KycReport from './KycReport'
import axios from 'axios'
import { navigationService } from '../Utils/NavigationService'

function EntityFlow({ entityDetails }) {
  const breadCrumbItems = [
    { id: 1, title: 'Home', completed: false, active:true},
    { id: 2, title: 'KYC Documents', completed: false, active: false },
    // { id: 3, title: 'Individual KYC Information Review', active: false, completed: false,disabled: true },
    { id: 4, title: 'Client Screening', active: false, completed: true },
   // { id: 5, title: 'Review Summary', active: false, completed: true },
  ]

  const [breadCrumbs, setbreadCrumbs] = useState(breadCrumbItems);
  const [notify, setNotify] = useState({variant: '', message: ''})
  const [chatOpen, setChatOpen] = useState(false)
  const [loading, setLoading] = useState(false);
  const [qna, setQna] = useState([]);
  const [qnaCurrent, setQnaCurrent] = useState("");
  const [showMissDocs, setShowMissDocs] = useState(false);
  const [showMissAttr, setShowMissAttr] = useState(false);
  const [key, setKey] = useState("");

  const activateTabById = (id) => {
      breadCrumbItems.forEach(item => {
        item.active = item.id === id;
      });
      setbreadCrumbs([...breadCrumbItems]);
  };

  const subscription = messageService.getMessage().subscribe(notification => {
    setNotify({variant: notification.variant, message: notification.message})
  })

  const subscription2 = navigationService.getMessage().subscribe(msg => {
    if (msg === "missingDocuments") {
      breadCrumbItems.filter(item => !item.disabled).map(item => {
        item.active = false;
        return item;
      });
      // breadCrumbItems[1].active = true;
      activateTabById(2);
      setbreadCrumbs([...breadCrumbItems])
      setShowMissDocs(true)
    } else if (msg === "missingAttributes") {
      breadCrumbItems.map(item => {
        item.active = false;
        return item;
      });
      // breadCrumbItems[2].active = true;
      activateTabById(3);
      setbreadCrumbs([...breadCrumbItems])
      setShowMissAttr(true)
    } else if (msg === "ANNMatch") {
      breadCrumbItems.map(item => {
        item.active = false;
        return item;
      });
      // breadCrumbItems[3].active = true;
      activateTabById(4);

      setbreadCrumbs([...breadCrumbItems])
    } else if (msg === "PEPMatch") {
      breadCrumbItems.map(item => {
        item.active = false;
        return item;
      });
      // breadCrumbItems[3].active = true;
      activateTabById(5);
      setKey("PEP Check");
      setbreadCrumbs([...breadCrumbItems])
    }
  })

  const questionHandler = (e) => {
    setQnaCurrent(e.target.value);
  }

  const changeKYCFlow = (breadCrmbItem) => {
    breadCrumbItems.map(item => {
      if (item.id === breadCrmbItem.id) {
        item.active = true
      } else {
        item.active = false
      }
      return item;
    });
    setbreadCrumbs([...breadCrumbItems])
  }

  const chatIconHandler = () => {
    setChatOpen(true);
  }

  const ClickHandler = () => {
    setLoading(true);
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/qna`, {"tab": "entity",
    "question": qnaCurrent})
    .then(response => {
        setLoading(false)
        const qnas = [...qna];
        qnas.push(qnaCurrent, response.data.Answer)
        setQnaCurrent("");
        setQna(qnas);
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message: "Server Problem"})
    })
  }

  // ✅ MINIMAL ADDITION: locality-based individual values
  const isIndia = entityDetails?.locality === "INDIA";

  const displayCaseId = isIndia
    ? entityDetails?.caseIdIndia
    : entityDetails?.caseIdIndonesia;

  const displayIndividualName = isIndia
    ? entityDetails?.individualNameIndia
    : entityDetails?.individualNameIndonesia;
    
  return (
    <>
    {
      notify.message !== '' &&
      <Alert variant={notify.variant} className={EntityFlowModuleCss.alert}
      onClose={() => setNotify({variant:'', message: ''})} dismissible>{notify.message}</Alert>
    } 
    <div className={EntityFlowModuleCss.processFlow}>
    <span style={{ float: 'left' }}>
      {/* <div className={EntityFlowModuleCss.container}>
        <div className={EntityFlowModuleCss.steps}>
          {
            breadCrumbs.map(item => (
              <span className={EntityFlowModuleCss.circle}>{item.id}</span>
            ))
          }
          <div className={EntityFlowModuleCss.progress}>
            <div className={EntityFlowModuleCss.indicator}></div>
          </div>
        </div>
      </div> */}
      <div className={EntityFlowModuleCss.breadcrumb}>
        <Breadcrumb className={EntityFlowModuleCss.customBreadcrumb}>
          {
            breadCrumbs.map(item => (
              (item && item.active) ?
                <Breadcrumb.Item key={item.id} className={EntityFlowModuleCss.active}
                  onClick={() => changeKYCFlow(item)}>{item.title}</Breadcrumb.Item> :
                  <Breadcrumb.Item key={item.id} onClick={() => changeKYCFlow(item)}>{item.title}</Breadcrumb.Item>
            ))
          }
        </Breadcrumb>
      </div>
    </span>
    <span style={{ float: 'right', backgroundColor: "#d0e5fa", margin:"5px", alignItems: "center",padding: "1px",display: "flex"}}>
    <img src={userLogo} alt="Entity Org" style={{width: "50px", height:"48px"}}/>
      <div className={EntityFlowModuleCss.box}>
      <span>{entityDetails.entityName}</span>
      <span style={{ display: "block" }}>
        Case ID: {displayCaseId || "142463282"} 
        {/* CASE ID TOP RIGHT CORNER */}
      </span>

      <span style={{ display: "block" }}>
        {displayIndividualName || "Wayan Koster S"}
      </span>
      </div>
    </span>
  </div>
    <div className={EntityFlowModuleCss.pane}>     
      

      {
          breadCrumbs.find(item => item.id === 1 && item.active) && <Home />
        }
        {
          breadCrumbs.find(item => item.id === 2 && item.active) &&
            <DocumentUpload showDocs={showMissDocs}/>
        }
        {
          breadCrumbs.find(item => item.id === 3 && item.active) &&
            <EntityDetails showAttr={showMissAttr}/>
        }
        {
          breadCrumbs.find(item => item.id === 4 && item.active) &&
            <MediaScreening key={key}/>
        }
        {
          breadCrumbs.find(item => item.id === 5 && item.active) &&
            <Summary/>
      }

      <img src={chatIcon} alt="chatIcon" className={EntityFlowModuleCss.chatIcon} onClick={chatIconHandler}/>
      {
        chatOpen &&
        <Modal onHide={() => setChatOpen(false)} variant="primary" show={true} className="chatbot">
          <><Modal.Header className={EntityFlowModuleCss.chatbotHeader} closeButton={true}>
          <div>Ask Gennie</div>
          </Modal.Header>
          <Modal.Body>
            <div style={{width: "400px"}}>
              <div style={{height: "311px", overflowY:"scroll"}}>
                <><img src={chatbot} alt="chatbot"className={EntityFlowModuleCss.chatbot}/>
                <span className={EntityFlowModuleCss.chatbotText}>Hi! How can i help you today?</span></>
                {
                  qna.map((item, itemIndex) => {
                    if (itemIndex % 2 === 0){
                      return <div style={{display:"flex", justifyContent:"flex-end"}}>
                        <span className={EntityFlowModuleCss.chatbotText} 
                        style={{backgroundColor: "#006EB3", color: "white"}}>{item}</span>
                        <img src={user} alt="user-icon" style={{width: "25px"}}/>
                        </div>
                    } else {
                      return <div style={{display:"flex"}}><img src={chatbot} alt="chatbot"className={EntityFlowModuleCss.chatbot}/><span className={EntityFlowModuleCss.chatbotText}>{item}</span></div>
                    }
                  })
                }
              </div>
              <div className={EntityFlowModuleCss.questionDiv}>
              <input type="text" placeholder='Type Your Question here...' value={qnaCurrent}
              style={{border: "0", width: "350px", fontFamily: "var(--poppinsRegular)",
              fontSize: "var(--fontSizeSmall)", height:"40px"}} onChange={(e) => questionHandler(e)}/>
              <img src={arrowRight} alt="right" className={EntityFlowModuleCss.arrowRight} onClick={ClickHandler}/>
              </div>
            </div>
            <div>
            </div>
          </Modal.Body></>
        </Modal>
      }
    </div>
    {
            loading &&
            <LayoutLoading message="Loading"/>
        }
    </>
  )
}

const mapStateToProp = (state) => {
  return {
    entityDetails: selectEntityDetails(state)
  }
}

export default connect(mapStateToProp, null)(EntityFlow)
