import React, { useState } from 'react';
import CustomTabs from '../Utils/CustomTabs'
import CompanyDetails from './CompanyDetails'
import BusinessTypeRisk from './BusinessTypeRisk'
import PersonaDetails from './PersonaDetails'
import IndividualCDD from './IndividualCDD'
import { CompanyDetailsIcon, BusinessTypeIcon, PersonaDetailsIcon, IndividualCDDIcon } from '../../assets/images'
import _ from 'lodash';

function EntityDetails({ showAttr = false }) {
    const data = [
        { id: 1, documentName: 'Adhar Card', category: 'Government ID Proof', status: 'Available', comments: 'Verified'},
        { id: 2, documentName: 'PAN Card', category: 'Financial ID Proof', status: 'Available', comments: 'Verified'},
        { id: 3, documentName: 'Passport', category: 'Government ID Proof', status: 'Not Matched', comments: 'Pending'},
        // { id: 4, documentName: 'Voter ID Card', category: 'Government ID Proof', status: 'Not Available', comments: 'Pending'},
        // { id: 5, documentName: 'Ration Card', category: 'Address Proof', status: 'Not Available', comments: 'Pending'},
        { id: 4, documentName: 'Electricity Bill', category: 'Address Proof', status: 'Not Valid', comments: 'Pending - Blurred Image'}
    ];

    const groupedData = _.groupBy(data, 'category');
    const [openCategories, setOpenCategories] = useState({});

    const toggleCategory = (category) => {
        setOpenCategories(prev => ({
            ...prev,
            [category]: !prev[category]
        }));
    };

    return (
        <div>
            {Object.keys(groupedData).map(category => (
                <div key={category} style={{ marginBottom: '15px', border: '1px solid #ccc', borderRadius: '5px' }}>
                    {/* Category Header */}
                    <div
                        onClick={() => toggleCategory(category)}
                        style={{
                            backgroundColor: '#006EB3',
                            color: '#fff',
                            padding: '10px 15px',
                            cursor: 'pointer',
                            userSelect: 'none',
                            fontWeight: 'bold'
                        }}
                    >
                        {category} {openCategories[category] ? '▲' : '▼'}
                    </div>

                    {/* Dropdown Content */}
                    {openCategories[category] && (
                        <table
                            border="1"
                            width="100%"
                            style={{
                                borderCollapse: 'collapse',
                                marginTop: '5px',
                                tableLayout: 'fixed',
                                textAlign: 'left'
                            }}
                        >
                            <thead>
                                <tr style={{ backgroundColor: '#f0f0f0' }}>
                                    <th style={{ width: '10%', padding: '8px' }}>ID</th>
                                    <th style={{ width: '40%', padding: '8px' }}>Document Name</th>
                                    <th style={{ width: '25%', padding: '8px' }}>Status</th>
                                    <th style={{ width: '25%', padding: '8px' }}>Comments</th>
                                </tr>
                            </thead>
                            <tbody>
                                {groupedData[category].length > 0 ? (
                                    groupedData[category].map((doc, index) => (
                                        <tr
                                            key={doc.id}
                                            style={{ backgroundColor: index % 2 === 0 ? '#ffffff' : '#f9f9f9' }}
                                        >
                                            <td style={{ padding: '8px' }}>{doc.id}</td>
                                            <td style={{ padding: '8px' }}>{doc.documentName || '-'}</td>
                                            <td style={{ padding: '8px' }}>{doc.status || '-'}</td>
                                            <td style={{ padding: '8px' }}>{doc.comments || '-'}</td>
                                        </tr>
                                    ))
                                ) : (
                                    <tr>
                                        <td colSpan="4" style={{ textAlign: 'center', padding: '8px' }}>
                                            No documents available
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>
                    )}
                </div>
            ))}
        </div>
    );
}

export default EntityDetails;
