/**
 * UNIFIED & PARAMETRIZED DOCUMENT UPLOAD
 * ----------------------------------------------------
 * Original UI output preserved
 * Original functionality preserved (doc click, modal preview, comments, status badges)
 * No duplicate Status columns
 * Doc View column present & clickable (KYC table only)
 * Single conditional switch for INDIA / INDONESIA
 * No behavioral change to BasicTable or CustomModal
 */

import React, { useState, useMemo, useEffect } from 'react';
import { Button, Badge, Form,DropdownButton,Dropdown,ButtonGroup  } from 'react-bootstrap';
import BasicTable from '../Utils/BasicTable';
import CustomModal from '../Utils/CustomModal';
import documentUploadCss from './DocumentUpload.module.css';
import { saveIcon, missingDocument, AutoEmail} from '../../assets/images';
import axios from 'axios';
import { messageService } from '../Utils/messageService';
import LayoutLoading from '../Utils/LayoutLoading';
import { HOME_CASE_CONFIG } from '../Utils/homeCaseConfig';

/* ================= IMAGE IMPORTS ================= */
import {
  adhar_combined,
  pan_card,
  customer_passport,
  electricity_bill,
  indonesian_national_id,
  indonesian_utility_bill_blur,
  indonesian_passport,
  demo_indonesian_payslip,
  driving_license
} from '../../assets/images';

/* ================= CASE CONFIG ================= */
const DOCUMENTS_CONFIG = {
  INDIA: {
    documents: {
      NATIONAL_ID: { label: 'National ID', image: adhar_combined },
      PAN: { label: 'PAN Card', image: pan_card },
      PASSPORT: { label: 'Passport', image: customer_passport },
      UTILITY: { label: 'Utility Bill', image: electricity_bill },
      PAYSLIP: { label: 'Payslip', image: null },
      DRIVING_ID: { label: 'Driving License', image: driving_license }
    },
  },

  INDONESIA: {
    documents: {
      NATIONAL_ID: { label: 'National ID', image: indonesian_national_id },
      PASSPORT: { label: 'Passport', image: indonesian_passport },
      UTILITY: { label: 'Utility Bill', image: indonesian_utility_bill_blur },
      PAYSLIP: { label: 'Payslip', image: demo_indonesian_payslip},
      DRIVING_ID: { label: 'Driving License', image: driving_license }
    }
  }
};

/* ================= COMPONENT (Update case type)================= */
function DocumentUpload({ caseType = 'INDONESIA', showDocs = false }) {
  const DOCUMENTS =
    DOCUMENTS_CONFIG[caseType]?.documents || {};

  const KYC_ATTRIBUTES =
    HOME_CASE_CONFIG[caseType]?.kycAttributes || [];

  const [missDocs, setMissDocs] = useState(
    HOME_CASE_CONFIG[caseType]?.RM_comments?.documents?.missingList || []
  );

  const [kycData, setKycData] = useState(
    KYC_ATTRIBUTES.map(item => ({
      ...item,
      docView: DOCUMENTS?.[item.source]?.image || null,
      comments: item.comments || ''
    }))
  );
    
  const initialData = [
      {items: 'Adhar Card', status:"Available", comments: ''},
      {items: 'PAN Card', status: "Available", comments: ''},
      {items: 'Passport', status: "Available"},
      {items: 'Payslip', status: "Available"},
      {items: 'Utility Bill', status: "Available"}
    ];


  const [showImageModal, setShowImageModal] = useState(false);
  const [isLandscape, setIsLandscape] = useState(true);

  const [selectedImage, setSelectedImage] = useState(null);
  const [loading, setLoading] = useState(false);
  const [showMissDocs, setShowMissDocs] = useState(false);

  const [data, setData] = useState(initialData);

  const documentTableData = useMemo(
    () =>
      Object.values(DOCUMENTS).map(doc => ({
        items: doc.label,
        status: doc.image ? 'Available' : 'Not Available',
        comments: ''
      })),
    [DOCUMENTS]
  );

  const closePreview = () => {
    setShowImageModal(false);
  };
 

  const handleImageClick = (img) => {
    const probe = new Image();
    probe.onload = () => {
      setIsLandscape(probe.naturalWidth >= probe.naturalHeight);
      setSelectedImage(img);
      setShowImageModal(true);
    };
    probe.onerror = () => {
      // If probe fails (rare), still show image with a safe default
      setIsLandscape(true);
      setSelectedImage(img);
      setShowImageModal(true);
    };
    probe.src = img;
  };

  /* ========== DOCUMENT TABLE (ORIGINAL FORMAT) ========== */
  const documentHeaders = [
    {
      Header: 'Status',
      accessor: 'status',
      Cell: ({ value }) => (
        <Badge bg={value === 'Available' ? 'success' : 'secondary'}>
          {value}
        </Badge>
      )
    },
    
  ];

  useEffect(() => {
    const missingList = HOME_CASE_CONFIG[caseType]?.RM_comments?.documents?.missingList || [];
    setMissDocs(missingList);
  }, [caseType]);


    const missDocsHandler = () => {
        setShowMissDocs(true)
    }

  /* ========== KYC ATTRIBUTE TABLE (DOC VIEW ENABLED) ========== */
  const kycHeaders = [
    { Header: 'KYC Attribute', accessor: 'attribute' },
    { Header: 'Value', accessor: 'value' },
    {
      Header: 'Source',
      accessor: 'source',
      Cell: ({ value }) => DOCUMENTS?.[value]?.label || value
    },
    {
      Header: 'Doc View',
      accessor: 'docView',
      Cell: ({ value }) =>
        value ? (
          <Button variant="link" size="sm" onClick={() => handleImageClick(value)}>
            View
          </Button>
        ) : (
          '-'
        )
    },
    {
      Header: 'Status',
      accessor: 'status',
      Cell: ({ value }) => (
        <Badge bg={value === 'Matched' ? 'success' : 'danger'}>
          {value}
        </Badge>
      )
    },
    { Header: 'Info', accessor: 'info' },
    {
      Header: "Reviewer's Co.",
      accessor: 'comments',
      Cell: ({ value, row }) => (
        <Form.Control
          className={documentUploadCss.inputTextArea}
          value={value}
          onChange={(e) => {
            const updated = [...kycData];
            updated[row.index].comments = e.target.value;
            setKycData(updated);
          }}
        />
      )
    }
  ];

  const sendMailHandler = (eventKey) => {
      setLoading(true);

      // Include missing documents dynamically in payload
      const payload = {
        missingDocuments: missDocs,
        kycData: kycData
      };

      const url =
        eventKey === 1
          ? `${process.env.REACT_APP_API_BASE_URL}/email_RFI`
          : `${process.env.REACT_APP_API_BASE_URL}/email_EDD`;

      axios.post(url, payload)
        .then(response => {
          setLoading(false);
          messageService.sendMessage({ variant: "success", message: "Mail has been Sent Successfully." });
        })
        .catch(error => {
          setLoading(false);
          messageService.sendMessage({ variant: "danger", message: "Server error" });
        });
    };

  
    return (
    <>
      <div>
        <span style={{ margin: '10px 5px 0px 0px', float: 'right' }}>
          <img src={missingDocument} alt="missingDocument" style={{ width: '45px' }} />
          <Button
            className={`${documentUploadCss.documentList} backgroundDanger`}
            variant="danger"
            onClick={missDocsHandler}
          >
            Missing Documents
          </Button>

          <img src={AutoEmail} alt="AutoEmail" style={{ width: '36px', marginRight: '4px' }} />

          <DropdownButton
            as={ButtonGroup}
            title="Customer Outreach"
            className={`${documentUploadCss.documentDropdown} backgroundDanger`}
            variant="none"
            id="bg-nested-dropdown"
          >
            <Dropdown.Item eventKey="1" onClick={() => sendMailHandler(1)}>
              RFI
            </Dropdown.Item>
            <Dropdown.Item eventKey="2" onClick={() => sendMailHandler(2)}>
              EDD
            </Dropdown.Item>
          </DropdownButton>
        </span>
      </div>

      <div className={documentUploadCss.innerDiv} style={{ marginTop: '20px' }}>
        <BasicTable availableColumns={kycHeaders} data={kycData} />
      </div>

      {/* Document preview orientation adjustment  */}
    {
        showImageModal && (
        <CustomModal
            modalHeader="Document Preview"
            onHideHandler={() => setShowImageModal(false)}
            size={isLandscape ? "lg" : "md"}
            fullscreen={!isLandscape}
        >
            <img      
                src={selectedImage}
                alt="Preview"
                style={{
                width: "100%",
                maxHeight: isLandscape ? "80vh" : "85vh",
                margin: "0 auto",
                maxWidth: isLandscape ? "80vw" : "95vw",
                objectFit: "contain"
               }}
               />
        </CustomModal>
             )
      }


      {showMissDocs && (
        <CustomModal modalHeader="Missing Documents" onHideHandler={() => setShowMissDocs(false)}>
          {missDocs.length > 0 && (
            <ul
              style={{
                fontFamily: 'var(--poppinsRegular)',
                fontSize: 'var(--fontSizeSmall)',
                paddingLeft: '20px'
              }}
            >
              {missDocs.map((doc, index) => (
                <li key={index}>{doc}</li>
              ))}
            </ul>
          )}
        </CustomModal>
      )}


      {loading && <LayoutLoading message="Loading" />}
    </>
  );
}

export default DocumentUpload;