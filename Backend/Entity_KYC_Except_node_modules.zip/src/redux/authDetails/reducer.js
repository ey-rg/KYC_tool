import { LOGIN_SUCCESS, LOGOUT_SUCCESS, LOGIN_FAIL } from "./types";

const initialState = {
    authDetails: {isAuthenticated: '', role: '', name: ''}
};

const authDetailsReducer = (state=initialState,action)=> {
    switch(action.type){
    case LOGIN_SUCCESS:
       return {
         ...state,
         authDetails: action.payload
       }
    case LOGOUT_SUCCESS:
        return {
            ...state,
            authDetails: action.payload
        }
    case LOGIN_FAIL:
        return {
            ...state,
            authDetails: action.payload
        }
    default: 
       return {...state}
    }
};

export default authDetailsReducer;