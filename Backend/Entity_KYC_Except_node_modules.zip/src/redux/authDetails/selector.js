export const selectIsAuthenticated = state => state.authDetailsReducer.authDetails.isAuthenticated;
export const selectRole = state => state.authDetailsReducer.authDetails.role;
export const selectName = state => state.authDetailsReducer.authDetails.name