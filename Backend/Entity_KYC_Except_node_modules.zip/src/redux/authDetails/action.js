import { LOGIN_SUCCESS, LOGIN_FAIL, LOGOUT_SUCCESS } from "./types"

export const loginSuccess = (data)=>{
    return {
        type:LOGIN_SUCCESS,
        payload:data
    }
}
export const loginFail = (error)=>{
    return {
        type:LOGIN_FAIL,
        payload:error
    }
}

export const logoutSuccess = (data)=>{
    return {
        type:LOGOUT_SUCCESS,
        payload:data
    }
}