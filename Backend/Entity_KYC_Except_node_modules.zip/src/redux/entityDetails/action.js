import { SET_ENTITYDETAILS } from "./types";

export const setEntityDetails = (entityDetails) => {
    return {
        type: SET_ENTITYDETAILS,
        payload: entityDetails
    }
}