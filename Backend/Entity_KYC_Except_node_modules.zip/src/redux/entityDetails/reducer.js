import { SET_ENTITYDETAILS } from "./types";

const initialState = {
    entityDetails: {entityName: ''}
};

const entityDetailsReducer = (state=initialState,action)=> {
    switch(action.type){
    case SET_ENTITYDETAILS:
       return {
         ...state,
         entityDetails: action.payload
       }
    default: 
       return {...state}
    }
};

export default entityDetailsReducer;