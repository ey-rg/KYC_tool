import { SET_SUMMARYDETAILS } from "./types";

const initialState = {
    summaryDetails: {}
};

const entityDetailsReducer = (state=initialState,action)=> {
    switch(action.type){
    case SET_SUMMARYDETAILS:
       return {
         ...state,
         summaryDetails: action.payload
       }
    default: 
       return {...state}
    }
};

export default entityDetailsReducer;