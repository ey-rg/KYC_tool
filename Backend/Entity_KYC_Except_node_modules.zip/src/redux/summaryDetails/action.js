import { SET_SUMMARYDETAILS } from "./types";

export const setSummaryDetails = (summaryDetails) => {
    return {
        type: SET_SUMMARYDETAILS,
        payload: summaryDetails
    }
}