import { combineReducers } from 'redux'
import entityDetailsReducer from './entityDetails/reducer'
import authDetailsReducer from './authDetails/reducer';
import summaryDetailsReducer from './summaryDetails/reducer'

const rootReducer = combineReducers({
    entityDetailsReducer:entityDetailsReducer,
    authDetailsReducer: authDetailsReducer,
    summaryDetailsReducer: summaryDetailsReducer
})

export default rootReducer;

