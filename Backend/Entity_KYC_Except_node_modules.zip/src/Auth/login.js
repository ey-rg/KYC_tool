import React, {useState} from "react";
import { Kyc } from "../assets/images";
import loginCSS from "./login.module.css"
import { Form, Button } from "react-bootstrap"
import axios from "axios";
import LayoutLoading from "../Components/Utils/LayoutLoading";
import CustomAlert from "../Components/CustomAlert";
import { loginSuccess, loginFail } from "../redux/authDetails/action";
import { useDispatch } from "react-redux";
import { useNavigate } from "react-router-dom";
import { userLogo } from "../assets/images";

const initialState = {
  name: '',
  password: ''
}

function Login() {
  const [formData, setFormData] = useState(initialState);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState({errorMsg: '', variant: ''});
  const [roleMsg, setRoleMsg] = useState('')
  const dispatch = useDispatch()
  const navigate = useNavigate()

  const changeHandler = (e) => {
     setFormData({
      ...formData,
      [e.target.name]: (e.target.value)
     })
     if (e.target.name === 'password') {
      axios.post(`${process.env.REACT_APP_API_BASE_URL}/login_validation`, {"name": formData.name, "tab": "retrieve_role"})
      .then(response => {
        setRoleMsg(response.data.role)
      })
      .catch(error => {
      })
     }
  }

  const submitHandler = () => {
    setLoading(true)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/login_validation`, {"username": formData.name,
    "password": formData.password, "tab": "validation"})
    .then(response => {
        setLoading(false)
        dispatch(loginSuccess({
          isAuthenticated: true,
          name: formData.name,
          role: response.data.role
        }))
        switch (response.data.role) {
          case "maker":
            return navigate("/entity");
          case "admin":
              return navigate("/entityTracker");
          case "checker":
            return navigate("/entityChecker");
          default:
            return {redirect:"/login/"};
        }
    })
    .catch(error => {
        setLoading(false)
        setErrorMsg({variant: "danger", errorMsg: "Login Failed"})
        dispatch(loginFail({
          isAuthenticated: false,
          role: ""
        }))
    })    
  }

  return (
    <div style={{backgroundColor: "#d0e5fa"}}>
      <img src={Kyc} alt="EY" className={loginCSS.EYImage}></img>
      <div className={loginCSS.outerDiv}>
      <div className={loginCSS.title}>KYC Verification Engine</div>
        <div className={loginCSS.loginDiv}>
        <img src={userLogo} alt="userLogo" style={{ marginLeft: "40%" }}/>
          <Form onSubmit={submitHandler} className={loginCSS.form}>
          <Form.Control type="text" name="name" onChange={changeHandler} required placeholder="username"></Form.Control>
          {
            roleMsg !== '' &&
          <span style={{fontFamily: "var(--poppinsRegular)", fontSize: "10px",
           color: "black"}}>You are logging as {roleMsg}</span>
          }
           <div style={{marginTop:"30px"}}>
          <Form.Control type="password" name="password" onChange={changeHandler} required placeholder="password"></Form.Control>
          </div>
          <div>
          <Button type="submit"
                        name="signupBtn"
                        variant='success' style={{marginTop: "30px", width: "100%"}}
                    >Login</Button></div>
          </Form>
        </div>
      </div>
        {
            loading &&
            <LayoutLoading message="Loading"/>
        }
        {
            errorMsg.errorMsg !== "" &&
            <CustomAlert message={errorMsg.errorMsg} hideHandler={() => setErrorMsg(null)}></CustomAlert>
        }
    </div>
  )
}

export default Login