import React from "react";
import { Kyc, logout } from "../assets/images";
import loginCSS from "./login.module.css"
import { useNavigate } from "react-router-dom";
import { logOut } from "../assets/images";

function Logout() {
  const navigate = useNavigate();
  const loginHandler = () => {
    navigate("/login");
  }

  return (
    <div style={{backgroundColor: "#d0e5fa"}}>
      <img src={Kyc} alt="EY" className={loginCSS.EYImage}></img>
      <div className={loginCSS.outerDiv}>
      <div className={loginCSS.title}>KYC Verification Engine</div>
        <div className={loginCSS.loginDiv} style={{height: "140px"}}>
           <img src={logOut} alt="logout" style={{ marginLeft: "40%", width: "40px" }}/>
           <p className={loginCSS.message}> You have been logged out successfully</p>
           <p className={loginCSS.loginMessage} onClick={loginHandler}> Click here to Login </p>
        </div>
      </div>
    </div>
  )
}

export default Logout