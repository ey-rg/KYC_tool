import { useNavigate } from "react-router-dom";
import { selectIsAuthenticated } from "../redux/authDetails/selector";
import { connect } from "react-redux";

function AuthRequired({ children, authDetails }) {
  const navigate = useNavigate()
  return authDetails ? children : navigate("/login")
}

const mapStateToProp = (state) => {
    return {
      authDetails: selectIsAuthenticated(state)
    }
}

export default connect(mapStateToProp, null)(AuthRequired)
