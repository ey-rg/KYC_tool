import './App.css';
import TopNav from './TopNav';
import { HashRouter , Routes, Route, Navigate } from 'react-router-dom'
import React from 'react';
import { Provider } from 'react-redux';
import EntityLayout from './Components/Entity/EntityLayout';
import store from './redux/store';
import EntityFlow from './Components/Entity/EntityFlow';
import Login from './Auth/login';
import AuthRequired from './Auth/AuthRequired';
import Logout from './Auth/logout';
import MailForm from './Components/Entity/MailForm';
import CheckerLayout from './Components/Entity/CheckerLayout';
import TrackerLayout from './Components/Entity/TrackerLayout';

function App() {
  return (
    <div className="App">
      <Provider store={store}>
      <HashRouter>
      <Routes>
          <Route path="/" element={<Navigate to="/login" />} />
          <Route path="/login" element={<Login/>} />
          <Route path="/logout" element={<Logout/>} />
          <Route path="/mailForm/:tab" element={<MailForm/>} />
          <Route path="/entity" element={<AuthRequired><TopNav /><EntityLayout/></AuthRequired>} />
          <Route path="/entity/entityKYC" element={<AuthRequired><TopNav /><EntityFlow/></AuthRequired>}/>
          <Route path="/entityTracker" element={<AuthRequired><TopNav /><TrackerLayout /></AuthRequired>} />
          <Route path="/entityChecker" element={<AuthRequired><TopNav /><CheckerLayout/></AuthRequired>} />
      </Routes>
      </HashRouter>
      </Provider>
    </div>
  );
}

export default App;
