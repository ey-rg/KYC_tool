import React from 'react'
import { eyLogo, user, logout } from './assets/images'
import TopNavCss from './TopNav.module.css'
import { Container, Nav, Navbar } from 'react-bootstrap'
import { NavLink } from 'react-router-dom'
import { logoutSuccess } from './redux/authDetails/action'
import { useDispatch, connect } from "react-redux";
import { useNavigate } from "react-router-dom";
import { selectName, selectRole } from './redux/authDetails/selector'

function TopNav({authDetailsRole, authDetailsName}) {
    const activeLink = {
        color:"white"
    }

    const dispatch = useDispatch()
    const navigate = useNavigate()

    const logoutHandler = () => {
        dispatch(logoutSuccess({
            isAuthenticated: false,
            role: ""
          }))
        navigate("/logout")
    }

    return (
        <Navbar variant="dark" className={TopNavCss.navDiv}>
            <Container fluid style={{height: '47px'}}>
                <Navbar.Brand style={{padding:"0px"}}>
                    <div className={TopNavCss.logoDiv}>
                        <img src={eyLogo} alt="ey-icon" />
                    </div>
                    <span className={TopNavCss.NavigationTitle}>KYC Verification Engine</span>
                </Navbar.Brand>
                <Nav className="mx-auto">
                    {
                        authDetailsRole === "admin" &&
                    <NavLink
                        className={TopNavCss.navLink}
                        to="/entityTracker"
                        style={({ isActive }) =>
                        isActive ? activeLink : undefined
                        }
                    >
                        KYC Tracker
                    </NavLink>
                    }
                    { 
                      authDetailsRole === "maker" &&
                    // <NavLink
                    //         className={TopNavCss.navLink}
                    //         to="/control/summarisation&QA"
                    //         style={({ isActive }) => isActive ? activeLink : undefined}
                    //     >
                    //         Individual KYC
                    //     </NavLink>
                        <NavLink
                            className={TopNavCss.navLink}
                            to="/entity"
                            style={({ isActive }) => isActive ? activeLink : undefined}
                        >
                                KYC Refresh
                            </NavLink>
                    }
                    {
                      authDetailsRole === "checker" &&
                    <NavLink
                        className={TopNavCss.navLink}
                        to="/entityChecker"
                        style={({ isActive }) =>
                        isActive ? activeLink : undefined
                        }
                    >
                        KYC QA Checker
                    </NavLink>
                    }
                </Nav>
                <div className={TopNavCss.logoDiv} style={{marginTop: '9px !important'}}>
                    <img src={user} alt="user-icon"/>
                </div>
                <div>
                    <div className={TopNavCss.authUser}>{authDetailsName}</div>
                    <div className={TopNavCss.authUserRole}>{authDetailsRole}</div>    
                </div>
                <div className={TopNavCss.logout} onClick={logoutHandler}>
                    <img src={logout} alt="log off" title="Log Off"/>
                </div>
            </Container>
        </Navbar>
    )
}

const mapStateToProp = (state) => {
    return {
      authDetailsRole: selectRole(state),
      authDetailsName: selectName(state)
    }
}

export default connect(mapStateToProp, null)(TopNav)