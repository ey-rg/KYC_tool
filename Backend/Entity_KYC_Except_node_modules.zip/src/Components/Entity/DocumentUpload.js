import React, { useState, useEffect } from 'react'
import documentUploadCss from './DocumentUpload.module.css'
import { Button, Form, Badge,DropdownButton,Dropdown,ButtonGroup } from 'react-bootstrap';
import { saveIcon, missingDocument, AutoEmail, adhar_combined, pan_card ,electricity_bill} from '../../assets/images';
import BasicTable from '../Utils/BasicTable';
import { connect } from 'react-redux'
import CustomModal from '../Utils/CustomModal';
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import LayoutLoading from '../Utils/LayoutLoading';
import axios from 'axios';
import { messageService } from '../Utils/messageService';

function DocumentUpload({entityDetails, showDocs = false}) {
    const docs = [];
    const initialData = [
        /*{items: 'Company Register', status:"Available", comments: ''},
        {items: 'W-8 Form', status: "Not-Valid", comments: ''},
        {items: 'Audited Annual Report', status: "Available"},        
        {items: 'Organisation Chart', status: "Available"},
        {items: 'Economic Sanctions Due Diligence Questionnaire', status: "Not-Available"},
        {items: 'Annual Meeting of Stockholders Report', status: "Available"}
        */
       {items: 'Adhar Card', status:"Available", comments: ''},
        {items: 'PAN Card', status: "Available", comments: ''},
        {items: 'Passport', status: "Not Available"},        
        {items: 'Voter ID', status: "Not Available"},
        {items: 'Ration Card', status: "Not Available"},
        {items: 'Electricity Bill', status: "Not Valid"}

    ];
    const [showMissDocs, setShowMissDocs] = useState(false)
    const [loading, setLoading] = useState(false);
    const [missDocs, setMissDocs] = useState(docs)
    const [data, setData] = useState(initialData)
  
    const headers = [
        {
            Header:"KYC Documents",
            accessor:"items",
            Cell:(props)=>{
                if (props.value === 'Adhar Card') {
                    return <><span>{props.value}</span><img src={adhar_combined} alt="Adhar Card" className={documentUploadCss.documentImages}/></>
                } else  if (props.value === 'PAN Card') {
                    return <><span>{props.value}</span><img src={pan_card} alt="Pan Card" className={documentUploadCss.documentImages}/></>
                } else if (props.value === 'Electricity Bill') {
                    return <><span>{props.value}</span><img src={electricity_bill} alt="Electricity Bill" className={documentUploadCss.documentImages}/></>
                } else {
                    return <span>{props.value}</span>
                }
            }
        },
        {
            Header:"Status",
            accessor:"status",
            Cell:(props)=>{
                if (props.value === 'Available') {
                    return <Badge bg="success" className={documentUploadCss.badge}>{props.value}</Badge>;
                } else  if (props.value === 'Not Valid') {
                    return <Badge bg="danger" className={documentUploadCss.badge}>{props.value}</Badge>;
                } else {
                    return <Badge bg="secondary" className={documentUploadCss.badge}>{props.value}</Badge>
                }
            }
        },
        {
            Header:"Reviewer's Comments(if any)",
            accessor:"comments",
            Cell:(props)=>{
                return <>
                <Form.Control
                    name="text"
                    required={true}
                    className={documentUploadCss.inputTextArea}
                    value={props.value}
                    onChange={(e) => data.map(item => item.items === props.row.id ? item.comments = e.target.value : item.comments)}
                />
                <span style={{marginLeft: "20px", display: "inline-block"}}><img src={saveIcon} alt="save"></img></span>
                </>
            }
        }
    ]

     data.map(item => {
        if (item.status !== "Available") {
            docs.push(item.items);
        }
     })

     useEffect(() => {
        if (showDocs) {
            setShowMissDocs(showDocs)
          }
     }, [])

    const missDocsHandler = () => {
        setShowMissDocs(true)
    }

    // const sendMailHandler = () => {
    //     setLoading(true)
    //     const mailReqBody = {
    //         subject: "Upload Missing Documents",
    //         recipients: [
    //             "ramya.m3@in.ey.com"
    //         ],
    //         body: "Hi Ramya, \n\n Trust this email finds you well. \n\n We appreciate your cooperation in completing the KYC process with Reliance. In order to complete your application, we have identified that some required documents are currently missing from your submission.\n\n To ensure the swift completion of your KYC requirements, we kindly request you to upload the missing documents in the form: http://localhost:3000/#/mailForm/Documents . \n\nRegards, \nAdmin"
    //     }
    //     axios.post(`${process.env.REACT_APP_API_BASE_URL}/send_mail_non_compliant`, mailReqBody)
    //     .then(response => {
    //         setLoading(false)
    //         messageService.sendMessage({variant: "success", message: "Mail has been Sent Successfully."})
    //     })
    //     .catch(error => {
    //         setLoading(false)
    //         messageService.sendMessage({variant: "danger", message: "server error"});
    //     })     
    // }
    const sendMailHandler = (eventKey) => {
        setLoading(true)
        if (eventKey === 1) {
            //axios.post(`${process.env.REACT_APP_API_BASE_URL}/send_mail_with_attachment_non_compliant`)
            axios.post(`${process.env.REACT_APP_API_BASE_URL}/email_RFI`)
            .then(response => {
                setLoading(false)
                messageService.sendMessage({variant: "success", message: "Mail has been Sent Successfully."})
            })
            .catch(error => {
                setLoading(false)
                messageService.sendMessage({variant: "danger", message: "server error"});
            })
        } else {
        //axios.post(`${process.env.REACT_APP_API_BASE_URL}/send_mail_non_compliant`)
        axios.post(`${process.env.REACT_APP_API_BASE_URL}/email_EDD`)
        .then(response => {
            setLoading(false)
            messageService.sendMessage({variant: "success", message: "Mail has been Sent Successfully."})
        })
        .catch(error => {
            setLoading(false)
            messageService.sendMessage({variant: "danger", message: "server error"});
        })
     }  
    }

    return (
        <><div>
            <span style={{ margin: "10px 5px 0px 0px", float: "right" }}>
                <img src={missingDocument} alt="missingDocument" style={{width: "45px"}}/>
                <Button className={`${documentUploadCss.documentList} backgroundDanger`} variant='danger'
                onClick={() => missDocsHandler()}>Missing Documents</Button>
                <img src={AutoEmail} alt="AutoEmail" style={{width: "36px", marginRight: "4px"}}/>
                {/* <Button className={`${documentUploadCss.documentList} backgroundDanger`} variant="primary"
                onClick={() => sendMailHandler()}>Request Information</Button> */}
                <DropdownButton as={ButtonGroup} title="Customer Outreach"
                className={`${documentUploadCss.documentDropdown} backgroundDanger`} variant="none" id="bg-nested-dropdown">
                <Dropdown.Item eventKey="1" onClick={() => sendMailHandler(1)}>RFI</Dropdown.Item>
                <Dropdown.Item eventKey="2" onClick={() => sendMailHandler(2)}>EDD</Dropdown.Item>
                </DropdownButton>
            </span>
        </div>
        <div className={documentUploadCss.innerDiv}>
         <BasicTable availableColumns={headers} data={data} ></BasicTable></div>
        {
            showMissDocs &&
            <CustomModal onHideHandler={() => setShowMissDocs(false)}
            modalHeader='Missing Documents'>
                { 
                   missDocs.length ? <ul> 
                    {
                      missDocs.map(doc => (
                        <li>{doc}</li>
                      ))  
                    }
                </ul> : <p style={{fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)"}}>There are no missing Documents</p>
                }
            </CustomModal>
        }
        {
            loading &&
            <LayoutLoading message="Loading"/>
        }
        </>
    )
}

const mapStateToProp = (state) => {
    return {
      entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(DocumentUpload)