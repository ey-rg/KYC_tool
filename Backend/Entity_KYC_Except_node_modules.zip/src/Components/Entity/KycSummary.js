import React, { useEffect, useState } from 'react'
import documentUploadCss from './DocumentUpload.module.css'
import guidelinesCss from './KYCGuidelines.module.css'
import { Row, Col, Badge, Button } from 'react-bootstrap';
import axios from 'axios';
import LayoutLoading from './../Utils/LayoutLoading'
import KycSummaryCss from './KycSummary.module.css'
import { messageService } from '../Utils/messageService'
import { edit, saveIcon } from '../../assets/images'
import UpdateAttributes from './UpdateAttributes';
import CustomModal from '../Utils/CustomModal';
import { adhar_combined, pan_card } from '../../assets/images'; // For testing purpose individual KYC

function KYCSummary() {
    const [loading, setLoading] = useState(false);
    const [summary, setSummary] = useState('');
    const [comments, showComments] = useState(false);
    const [riskRating, setRiskRating] = useState({risk_category: '', risk_score: ''})
    const [contentEditable, setContentEditable] = useState(false);

    useEffect(() => {
        setLoading(true)
        axios.get(`${process.env.REACT_APP_API_BASE_URL}/access_entity_risk`)
        .then(response => {
            setRiskRating(response.data)
        })
        .catch(error => {
            messageService.sendMessage({variant:"danger", message:"server problem"})
        })
        axios.get(`${process.env.REACT_APP_API_BASE_URL}/entity_kyc_summary`)
        .then(response => {
            setSummary(response.data)
            setLoading(false)
        })
        .catch(error => {
            setLoading(false)
            messageService.sendMessage({variant:"danger", message:"server problem"})
        })
    }, [])

    const commentsHandler = () => {
       showComments(true);
    }

    const submitHandler = () => {
        messageService.sendMessage({variant:"success", message:"KYC Review Report Submitted Successfully."})
    }

    return (
        <>
            <Row className={guidelinesCss.innerDiv} style={{overflow:"auto", border:0, height:"400px"}}>
                <Col md={12} className={guidelinesCss.summary}>
                <div className={guidelinesCss.backgroundColor}>
                <label>KYC Summary</label>
                <span style={{position: "absolute", right: "87px", cursor: "pointer"}}>
                    <img src={edit} alt="edit" onClick={() => {setContentEditable(true)}}/>
                    <img src={saveIcon} alt="save" onClick={() => {setContentEditable(false)}}/>
                </span>
                </div>
                <div className={KycSummaryCss.summary} contentEditable={contentEditable}>
                <div className={KycSummaryCss.linkBackgroundColor} contentEditable={false}>
                <Row>
                    <Col md={2}></Col>
                    <Col md={4}>
                    <span className={KycSummaryCss.riskRating}><span>Risk Category: </span>
                      {
                        riskRating.risk_category === "Low" ?
                       <Badge bg="success" className={documentUploadCss.badge}>{riskRating.risk_category}</Badge> :
                       <Badge bg="danger" className={documentUploadCss.badge}>{riskRating.risk_category}</Badge>
                      }
                    </span>
                    </Col>
                    <Col md={5}>
                    <span className={KycSummaryCss.riskRating}><span> Enhance Due Diligence Required</span>
                    <Badge bg="success" className={documentUploadCss.badge}>No</Badge></span>
                    </Col>
                </Row>
                </div>
                <div>
                { 
                 summary &&
                    <ul>
                        <span className={KycSummaryCss.summaryHeader}>Risk Status</span>
                        <li>{summary.risk_status}</li>
                        <span className={KycSummaryCss.summaryHeader}>Adverse Media Screening</span>
                        <li>{summary.adverse_media_screening}</li>
                        <span className={KycSummaryCss.summaryHeader}>PEP Result</span>
                        <li>{summary.pep_result}</li>
                        <span className={KycSummaryCss.summaryHeader}>Sanction Result</span>
                        <li>{summary.sanaction_result}</li>
                    </ul>
                }
                </div>
                <div style={{fontFamily: "var(--poppinsSemiBold)", fontSize: "var(--fontSizeMedium)",
                margin: "0 0 10px 20px"}}>List of KYC Attributes To Be Updated</div>
                

                {/* <div className={KycSummaryCss.imageContainer} style={{ padding: '0 20px' }}>
                    <div style={{ display: 'flex', gap: '20px', marginBottom: '20px', flexWrap: 'wrap' }}>
                        <div className={KycSummaryCss.imageTab} style={{ flex: '1 1 300px' }}>
                            <p style={{ fontWeight: 'bold' }}>ID Front</p>
                            <img 
                                src={adhar_combined} 
                                style={{ width: '100%', borderRadius: '8px', border: '1px solid #ddd' }} 
                            />
                        </div>
                        <div className={KycSummaryCss.imageTab} style={{ flex: '1 1 300px' }}>
                            <p style={{ fontWeight: 'bold' }}>ID Back</p>
                            <img 
                                src={pan_card} 
                                style={{ width: '100%', borderRadius: '8px', border: '1px solid #ddd' }} 
                            />
                        </div>
                    </div>
                </div> */}
                

                {/* Existing heading and component */}
                {/* <div style={{fontFamily: "var(--poppinsSemiBold)", fontSize: "var(--fontSizeMedium)", margin: "0 0 10px 20px"}}>
                    List of KYC Attributes To Be Updated
                </div> */}
                


                {/* <UpdateAttributes /> */}
                </div>
                <div style={{position:"absolute", right:"30px", marginTop: "20px"}}>
            <Button variant="danger" className={`${documentUploadCss.documentList} backgroundDanger`}
            onClick={commentsHandler}> Comments </Button>
            <Button variant="success" className={documentUploadCss.documentList} title='To QA Checker'
            onClick={submitHandler}>Submit</Button>
            </div>
                </Col>
            </Row>
             {
               comments &&
               <CustomModal onHideHandler={() => showComments(false)}
               modalHeader="Reviewer's Comment">
                <textarea placeholder='Please enter your comments here...' disabled={!contentEditable} 
                className={KycSummaryCss.comments} />
                </CustomModal>
             }
            {
                loading &&
                <LayoutLoading message="Generating Summary"/>
            }
        </>
    )
}

export default KYCSummary