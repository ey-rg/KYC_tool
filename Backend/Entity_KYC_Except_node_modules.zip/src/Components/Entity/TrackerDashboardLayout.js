import React, { useState } from 'react';
import CheckerLayoutCss from './CheckerLayout.module.css'
import TrackerLayoutCss from './TrackerLayout.module.css'
import BasicTable from '../Utils/BasicTable';
import {Row, Col} from 'react-bootstrap';
import PieChart from '../Utils/PieChart';
import {
	Chart as ChartJS,
	CategoryScale,
	LinearScale,
	BarElement,
	Title,
	Tooltip,
	Legend,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import DoughnutDashboard from './DoughnutDashboard';
import Select from "react-select";

ChartJS.register(
	CategoryScale,
	LinearScale,
	BarElement,
	Title,
	Tooltip,
	ChartDataLabels,
	Legend
);

function TrackerDashboardLayout() {
    const initialData = [
        {entityName: 'Emergent BioSolutions UK Ltd', refreshDate: '16 Nov 2023', assignTo: '', assignedDate: '', dueDate: '16 Jan 2024',
        startDate: '', status: 'Not Assigned', endDate: '', entityRisk: '', nextKycDate: ''},
        {entityName: 'ABCInfoTech', refreshDate: '6 Nov 2023', assignTo: 'user2', assignedDate: '7 Nov 2023', dueDate: '6 Jan 2024',
        startDate: '8 Nov 2023', status: 'In Progress', endDate: '', entityRisk: '', nextKycDate: ''},
        {entityName: 'INC Technology', refreshDate: '6 Feb 2023', assignTo: 'user3', assignedDate: '7 May 2023', dueDate: '6 Jan 2024',
        startDate: '10 Feb 2023', status: 'Completed', endDate: '25 May 2023', entityRisk: 'Low', nextKycDate: '10 May 2026'},
        {entityName: 'L&T InfoTech', refreshDate: '4 Oct 2023', assignTo: '', assignedDate: '', dueDate: '26 Jan 2024',
        startDate: '', status: 'Not Assigned', endDate: '', entityRisk: '', nextKycDate: '' },
        {entityName: 'XYZ Limited', refreshDate: '16 Nov 2023', assignTo: 'user3', assignedDate: '17 Nov 2023', dueDate: '12 May 2024',
        startDate: '', status: 'Not Started', endDate: '', entityRisk: '', nextKycDate: ''},
        {entityName: 'RBC Technology', refreshDate: '6 Feb 2023', assignTo: 'user4', assignedDate: '7 May 2023', dueDate: '6 Jan 2024',
        startDate: '11 Feb 2023', status: 'In Progress', endDate: '', entityRisk: '', nextKycDate: ''},
        {entityName: 'Wipro Tech', refreshDate: '12 March 2023', assignTo: 'user3', assignedDate: '15 March 2023', dueDate: '6 Dec 2023',
        startDate: '17 March 2023', status: 'In Progress', endDate: '', entityRisk: '', nextKycDate: ''}
    ];
    
    const userOptions = [{label: "user1", value:"user1"}, {label: "user2", value: "user2"}, 
    {label: "user3", value: "user3"}, {label:"user4", value: "user4"}];

    const [data, setData] = useState(initialData)

    const userChangeHandler = (row) => {
        const modifiedData = data.map(item => {
            if (item.entityName === row.entityName) {
               item.assignTo = "user1";
               item.status = "In Progress"
               return item;
            } else {
                return item;
            }
           })
           setData(modifiedData);
    }

    const headers = [
        {
            Header:"Entity Name",
            accessor:"entityName",
            Cell:(props) => {
                return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            }
        },
        {
            Header:"Refresh Date",
            accessor:"refreshDate"
        },
        {
            Header:"Assign to",
            accessor:"assignTo",
            Cell:(props) => {
                return props.value !== ""
                ? <span>{props.value}</span> :
                <Select
                name="assignTo"
                options={userOptions}
                onChange={() => userChangeHandler(props.row.values)}
              />
            }
        },
        {
            Header:"Assign Date",
            accessor:"assignedDate"
        },
        {
            Header:"Due Date",
            accessor:"dueDate"
        },
        {
            Header:"Start Date",
            accessor:"startDate"
        },
        {
            Header:"Status",
            accessor:"status",
            Cell:(props) => {
                return (
                props.value === "In Progress"
                ? <div className={TrackerLayoutCss.badge} style={{backgroundColor: "#C36721"}}>{props.value}</div>:
                props.value === "Not Assigned"
                ? <div className={TrackerLayoutCss.badge} style={{backgroundColor: "#006eb3"}}>{props.value}</div> :
                props.value === "Not Started"
                ? <div className={TrackerLayoutCss.badge} style={{backgroundColor: "#b1ceeb"}}>{props.value}</div> :
                <div className={TrackerLayoutCss.badge} style={{backgroundColor: "#198754"}}>{props.value}</div>
                )            
            }
        },
        {
            Header:"End Date",
            accessor:"endDate"
        },
        {
            Header:"Entity Risk",
            accessor:"entityRisk"
        },
        {
            Header:"Next KYC Date",
            accessor:"nextKycDate"
        }
    ]

    const chartData = {labels: ['1', '2', '1', '3'], values: [15, 30, 15, 40]}
    const chartDoughnutData = {labels: ['1'], values: 50}
    return (
        <div className={CheckerLayoutCss.pane}>
        <Row>
        <div className={TrackerLayoutCss.dashboardTitle}><span>Entity KYC</span></div>
        <Col md={10}>
         <BasicTable availableColumns={headers} data={data} tableDivExtraStyle={{
        height: "450px"
    }}></BasicTable>
        </Col>
        <Col md={2} style={{padding: "0", width: '180px'}}>
            <div style={{backgroundColor: "var(--bodyColor)", fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)", padding: '5px', height:"100%"}}>
             <div><span style={{width:"7px", height: "7px", backgroundColor: "#006EB3", display: 'inline-block'}}></span>
              <span style={{display: 'inline-block', marginRight: '15px'}}>Not Assigned</span><span style={{width:"7px", height: "7px", backgroundColor: "#d0e5fa", display: 'inline-block', paddingLeft: '2px'}}></span> Not Started</div>
              <div><span style={{width:"7px", height: "7px", backgroundColor: "#C36721", display: 'inline-block'}}></span>
              <span style={{display: 'inline-block', marginRight: '15px'}}>In Progress</span><span style={{width:"7px", height: "7px", backgroundColor: "#198754", display: 'inline-block', paddingLeft: '2px'}}></span> Completed</div>
            <PieChart chartData={chartData}/>
            <div style={{textAlign: 'center'}}> ABC Info Tech</div>
            <DoughnutDashboard chartData={chartDoughnutData} />
            <div style={{textAlign: 'center'}}> On Track</div>
            </div>
        </Col>
        </Row>
        </div>
    )
}

export default TrackerDashboardLayout