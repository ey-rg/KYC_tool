import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BlankTable from '../Utils/BlankTable';
import MultiLevelTable from '../Utils/MultiLevelTable';
import { Matched, NotMatched } from '../../assets/images';
import ReKYCVerificationCss from './ReKYCVerification.module.css'
import { Button, Col, Row, ButtonGroup, Dropdown, DropdownButton } from 'react-bootstrap'
import { messageService } from '../Utils/messageService'
import LayoutLoading from './../Utils/LayoutLoading'
import { Mailicon, ReportFoldericon, SearchIcon } from '../../assets/images';

function ReKYCVerification({ noItemText = "No Record Found" }) {
  const [excelData, setExcelData] = useState([]);
  const [loading, setLoading] = useState(false);
  const data = [
   
    {
      sl_no: 1, cust_id: 'CUST001', customer_name: 'Salaudin Ansari', poi: 'Aadhaar', poa: 'Aadhaar',
      validity_check: 'NA', dedupe_outcome: '0', name_poi: 'Matched', dob_poi: 'Matched',
      address_poa: 'Matched', identity_no: 'Matched', CompliantStatus: 'Compliant', reason_compliance_status: 'NA', email_id: '123@gmail.com', re_kyc_status: 'Completed', re_kyc_date: '13-06-2024'
    },
    {
      sl_no: 2, cust_id: 'CUST002', customer_name: 'Jasim Uddin', poi: 'PAN', poa: 'Electricity Bill ',
      validity_check: 'Electricity Bill-Older than 3 months', dedupe_outcome: '0', name_poi: 'Matched', dob_poi: 'Matched',
      address_poa: 'Not Matched', identity_no: 'Matched', CompliantStatus: 'Non-Compliant', reason_compliance_status: 'POA  Electricity Bill  not Valid (Bill Date: 25/01/2022)', email_id: 'abc@gmail.com', re_kyc_status: 'Pending', re_kyc_date: '13-06-2024'
    },
    {
      sl_no: 3, cust_id: 'CUST003', customer_name: 'Anindyasundar Mandal', poi: 'Voter ID', poa: 'Voter ID',
      validity_check: 'NA', dedupe_outcome: '0', name_poi: 'Matched', dob_poi: 'Matched',
      address_poa: 'Not Matched', identity_no: 'Matched', CompliantStatus: 'Non-Compliant', reason_compliance_status: 'Address Not Matched with VoterId card', email_id: 'xyz@gmail.com', re_kyc_status: 'Pending', re_kyc_date: '13-06-2024'
    },
    {
      sl_no: 4, cust_id: 'CUST004', customer_name: 'Amarjit Singh', poi: 'Passport', poa: 'Passport',
      validity_check: 'Passport Date Expired', dedupe_outcome: '0', name_poi: 'Not Matched', dob_poi: 'Not Matched',
      address_poa: 'Not Matched', identity_no: 'Not Matched', CompliantStatus: 'Non-Compliant', reason_compliance_status: 'Passport Expired - (Exp. Date: 12/03/2023)', email_id: 'mdjasimussin@gmail.com', re_kyc_status: 'Pending', re_kyc_date: '13-06-2024'
    },
    
     {
       sl_no: 5, cust_id: 'CUST005', customer_name: 'Sunder Singh', poi: 'Nrega Card', poa: 'Nrega Card',
       validity_check: 'Signature is Missing', dedupe_outcome: '0', name_poi: 'Not Matched', dob_poi: 'Not Matched',
        address_poa: 'Not Matched', identity_no: 'Not Matched', CompliantStatus: 'Non-Compliant', reason_compliance_status: 'Not a Valid Document-Signature is Missing', email_id: 'qwer@gmail.com', re_kyc_status: 'Pending', re_kyc_date: '13-06-2024'
    },
  //   {
  //     sl_no: 6, cust_id: 'CUST006', customer_name: 'Kumari Anjali', poi: 'PAN', poa: 'Aadhar',
  //     validity_check: 'NA', dedupe_outcome: '0', name_poi: 'Matched', dob_poi: 'Matched',
  //     address_poa: 'Matched', identity_no: 'Matched', compliance_status: 'Compliant', reason_compliance_status: 'NA'
  //   },
  //   {
  //     sl_no: 7, cust_id: 'CUST007', customer_name: 'Neha Desai', poi: 'Voter ID', poa: 'Driving License',
  //     validity_check: 'Valid Driving License', dedupe_outcome: '0', name_poi: 'Matched', dob_poi: 'Matched',
  //     address_poa: 'Not Matched', identity_no: 'Matched', compliance_status: 'Non-Compliant', reason_compliance_status: 'Address not matched with Driving License'
  //   },
  //   {
  //     sl_no: 8, cust_id: 'CUST008', customer_name: 'Adarsh Kumar', poi: 'Voter ID', poa: 'Voter ID',
  //     validity_check: 'NA', dedupe_outcome: '0', name_poi: 'Matched', dob_poi: 'Matched',
  //     address_poa: 'Matched', identity_no: 'Matched', compliance_status: 'Compliant', reason_compliance_status: 'NA'
  //   },
  // {
  //     sl_no: 9, cust_id: 'CUST009', customer_name: 'Arjun Mehta', poi: 'Nrega Card', poa: 'Voter ID',
  //     validity_check: 'NA', dedupe_outcome: '0', name_poi: 'Matched', dob_poi: 'Matched',
  //     address_poa: 'Matched', identity_no: 'Matched', compliance_status: 'Compliant', reason_compliance_status: 'NA'
  //   },
  // {
  //     sl_no: 10, cust_id: 'CUST010', customer_name: 'Deepika Choudhary', poi: 'PAN', poa: 'Voter ID',
  //     validity_check: 'NA', dedupe_outcome: '0', name_poi: 'Matched', dob_poi: 'Matched',
  //     address_poa: 'Matched', identity_no: 'Matched', compliance_status: 'Compliant', reason_compliance_status: 'NA'
  //   }
  ];
  const [tableData, setTableData] = useState(data);
  const cmpData = ["CUST003", 'Amarjit Singh', '', 'Pending', '-'];
  const [complianceData, setComplianceData] = useState(cmpData);
  const [chartData, setChartData] = useState({
    labels: [],
    datasets: [
      {
        label: 'Re-KYC Outcome',
        backgroundColor: ["#0b1d78", "#008ac5", "#00c698"],
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 0,
        hoverBackgroundColor: 'rgba(255, 252, 127,0.4)',
        hoverBorderColor: 'rgba(75,192,192,1)',
        data: [],
      },
    ],
  });

  const options = {
    scales: {
      x: {
        title: {
          display: false,
          text: 'Accounts',
        },
        grid: {
          display: false, // Set to false to remove x-axis grid lines
        },
      },
      y: {
        title: {
          display: true,
          text: '',
        },
        ticks: {
          display: false, // Set this to false to hide y-axis data points
        },
        grid: {
          display: false, // Set to false to remove x-axis grid lines
        },
      },
    },
    plugins: {
      legend: {
        display: false,
      },
      datalabels: {
        display: true, color: 'black',
        backgroundColor:
          (context) => {
            const label = context.dataset.data[context.dataIndex];
            if (label === 'Total') {
              return '#0b1d78';
            } else if (label === 'Compliant') {
              return '#008ac5';
            } else {
              return '#00c698';
            }
          },
      },
    },
  };

  const onStorageUpdate = (e) => {
    const { key, newValue } = e;
    if (key === "Email") {
      data[3].compliance_status = "Compliant"
      data[3].name_poi = 'Matched'
      data[3].dob_poi = 'Matched'
      data[3].address_poa = 'Matched'
      data[3].identity_no = 'Matched'
      data[3].reason_compliance_status = 'NA'
      data[3].re_kyc_status = 'Completed'
      data[3].re_kyc_date = '13/06/2024'
      setTableData([...data]);
    }
    localStorage.removeItem("Email");
  };

  useEffect(() => {
    // Fetch data from backend (replace 'your_backend_endpoint' with the actual endpoint)
    // axios.post(`${process.env.REACT_APP_API_BASE_URL}/individual_kyc`, {
    //   "tab": "bar_graph_kyc_verification"
    // })
    //   .then(response => {
    //     // Assuming the backend returns Excel data in some format
    //     setChartData({
    //       labels: ['Total', 'Compliant', 'Non-Compliant'],
    //       datasets: [
    //         {
    //           ...chartData.datasets[0], // Preserve other dataset properties
    //           data: response.data,
    //         },
    //       ],
    //     });
    //   })
    //   .catch(error => {
    //     console.error('Error fetching Excel data:', error);
    //   });
    window.addEventListener("storage", onStorageUpdate);
    return () => {
      window.removeEventListener("storage", onStorageUpdate);
    };
  }, []);

  const columns = [
    // {
    //   Header: 'Retail Customer',
    //   colSpan: 11,
    //   columns: [
        {
          Header: 'Database',
          colSpan: 6,
          columns: [
            {
              Header: 'SL No.',
              accessor: 'sl_no'
            },
            {
              Header: 'Cust ID',
              accessor: 'cust_id'
            },
            {
              Header: 'Customer Name',
              accessor: 'customer_name',
              Cell: (props) => {
               
                  return <span  style={{ fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
              }
            },
            {
              Header: 'Email ID',
              accessor: 'email_id',
              Cell: (props) => {
               
                  return <span  style={{ fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
              }
            },
            {
              Header: 'Re-KYC Status',
              accessor: 're_kyc_status',
              Cell: (props) => {
               
                if (props.value === "Completed") {
                  return <span style={{ color: "#008000", fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
                } else {
                  return <span style={{ color: "#FF0000", fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
                }
              }
            },
            {
              Header: 'Re-KYC Date',
              accessor: 're_kyc_date'
            },
          ],
        },
        {
          Header: 'KYC Document Availability, Validity Status & Dedupe',
          colSpan: 4,
          columns: [
            {
              Header: 'POI',
              accessor: 'poi'
            },
            {
              Header: 'POA',
              accessor: 'poa'
            },
            {
              Header: 'Validity Check',
              accessor: 'validity_check'
            },
            {
              Header: 'Dedupe Outcome',
              accessor: 'dedupe_outcome'
            },
          ],
        },
        {
          Header: 'KYC Attributes',
          colSpan: 4,
          columns: [
            {
              Header: 'Name(POI)',
              accessor: 'name_poi',
              Cell: (props) => {
                if (props.value === "Matched") {
                  return <img src={Matched} alt="matched" className={ReKYCVerificationCss.Matched} />
                } else if (props.value === "Not Matched") {
                  return <img src={NotMatched} alt="notmatched" className={ReKYCVerificationCss.notMatched} />
                } else {
                  return <span>{props.value}</span>
                }
              }
            },
            {
              Header: 'DOB(POI)',
              accessor: 'dob_poi',
              Cell: (props) => {
                if (props.value === "Matched") {
                  return <img src={Matched} alt="matched" className={ReKYCVerificationCss.Matched} />
                } else if (props.value === "Not Matched") {
                  return <img src={NotMatched} alt="notmatched" className={ReKYCVerificationCss.notMatched} />
                } else {
                  return <span>{props.value}</span>
                }
              }
            },
            {
              Header: 'Address(POA)',
              accessor: 'address_poa',
              Cell: (props) => {
                if (props.value === "Matched") {
                  return <img src={Matched} alt="matched" className={ReKYCVerificationCss.Matched} />
                } else if (props.value === "Not Matched") {
                  return <img src={NotMatched} alt="notmatched" className={ReKYCVerificationCss.notMatched} />
                } else {
                  return <span>{props.value}</span>
                }
              }
            },
            {
              Header: 'Identity No.',
              accessor: 'identity_no',
              Cell: (props) => {
                if (props.value === "Matched") {
                  return <img src={Matched} alt="matched" className={ReKYCVerificationCss.Matched} />
                } else if (props.value === "Not Matched") {
                  return <img src={NotMatched} alt="notmatched" className={ReKYCVerificationCss.notMatched} />
                } else {
                  return <span>{props.value}</span>
                }
              }
           },
          ],
      //   },
      // ],
    },
    {
          Header: 'Compliance Status',
          accessor: 'CompliantStatus',
          colSpan: 1,
          rowSpan: 3,
          Cell: (props) => {
            if (props.value === "Compliant") {
              return <span style={{ color: "#008000", fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
            } else if (props.value === "Non-Compliant") {
              return <span style={{ color: "#FF0000", fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
            } else {
              return <span>{props.value}</span>
            }
          }
    },
    {
      Header: 'KYC Outcome',
      colSpan: 1,
      columns: [
        {
          Header: 'Reason For Non-Compliance',
          accessor: 'reason_compliance_status',
          Cell: (props) => {
            if (props.value !== "NA") {
              return <span style={{ color: "#008000", color: "#2471A3", fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
            } else {
              return <span>{props.value}</span>
            }
          }
        }
      ],
    },
  ];

  const DownloadReport = (e) => {
    let headers = [];
    columns.map(col => {
      if (col.columns) {
       col?.columns.map(colHeader => {
        headers.push(colHeader.Header)
      })
      } else {
        headers.push(col.Header)
      }
    });
    headers = headers.join(",")
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/download/${e}`, {data: tableData})
      .then(response => {
        setLoading(false)
        let dataCsv = processData(response.data.data)
        let data = [headers, ...dataCsv].join('\n');
        const blob = new Blob([data], { type: 'text/csv' })
        const a = document.createElement('a')
        a.download = response.data.filename
        a.href = window.URL.createObjectURL(blob)
        const clickEvt = new MouseEvent('click', {
            view: window,
            bubbles: true,
            cancelable: true,
        })
        a.dispatchEvent(clickEvt)
        a.remove()
      })
      .catch(error => {
        setLoading(false)
        messageService.sendMessage({ variant: "danger", message: "server problem" })
      })
  }

  const processData = (data) => {
    let dataCsv =  data.reduce((acc, data) => {
       let {sl_no, cust_id, customer_name, email_id, re_kyc_status, re_kyc_date, poi, poa, validity_check, dedupe_outcome, name_poi, dob_poi, address_poa, identity_no, CompliantStatus, reason_compliance_status } = data
       identity_no = `"${identity_no}"`
       reason_compliance_status = `"${reason_compliance_status}"`
       acc.push([sl_no, cust_id, customer_name, email_id, re_kyc_status, re_kyc_date, poi, poa, validity_check, dedupe_outcome, name_poi, dob_poi, address_poa, identity_no, CompliantStatus, reason_compliance_status].join(","))
       return acc
   }, [])
   return dataCsv
 }

  const custOutreach = () => {
    setLoading(true)
    const mailReqBody = {
        data: {
          CustomerID: ["Prasanna"],
          CompliantStatus: ["Non-Compliant"],
          EmailId:["sriprasanna60@gmail.com"],
          reason:["Electricity Bill is older than 3 months."]
        }
    }
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/send_mail_non_compliant`, mailReqBody)
    .then(response => {
        setLoading(false)
        messageService.sendMessage({variant: "success", message: "Mail has been Sent Successfully."})
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message: "server error"});
    })
    data[3].re_kyc_status = "Email sent for Non-Compliance";
    setTableData([...data]);
   
}

  return (
    <>
      {/* <div style={{ display: "flex", flexDirection:"column" }}> */}
      <div style={{  width: "100%" }}>
        <div>
        <span style={{ display: "inline-block", marginTop: "15px"}}>
          
              {/* <input type="text" placeholder='Search here...' 
              style={{border: "0", width: "210px", fontFamily: "var(--poppinsRegular)",
              fontSize: "var(--fontSizeSmall)", height:"40px"}} />
              <img src={SearchIcon} alt="right" style={{height: '20px'}}/> */}
              <span style={{ display: "inline-block", margin: "4px 10px", backgroundColor: "#D3D3D3", width:"145px" }}>
            <span className={ReKYCVerificationCss.statusSpan}><div style={{marginLeft: "42px", width: "100px", fontFamily: "var(--poppinsSemiBold)", color: "white"}}>Customers</div>
            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center", marginLeft: "35px", color: "white" }}>5</div></span>
        </span>
        <span style={{ display: "inline-block", margin: "4px 10px", backgroundColor: "darkgrey", width:"145px" }}>
            <span className={ReKYCVerificationCss.statusSpan}><div style={{marginLeft: "42px", width: "100px", fontFamily: "var(--poppinsSemiBold)", color: "white"}}>Compliant</div>
            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center", marginLeft: "35px", color: "white" }}>1</div></span>
        </span>
        <span style={{ display: "inline-block", margin: "4px 10px", backgroundColor: "#AB3951", width:"145px" }}>
            <span className={ReKYCVerificationCss.statusSpan}><div style={{marginLeft: "30px", width: "100px", fontFamily: "var(--poppinsSemiBold)", color: "white"}}>Non-Compliant</div>
            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center", marginLeft: "35px" , color: "white"}}>4</div></span>
        </span>
             
          <img src={Mailicon} alt="matched"  style={{marginLeft: '230px', marginBottom: "10px"}}/>
          <Button className={ReKYCVerificationCss.CustomerOutreach} onClick={custOutreach}>Customer Outreach</Button>
          <img src={ReportFoldericon} alt="matched" style={{marginBottom: "10px"}} />
          <ButtonGroup>
          <DropdownButton
        as={ButtonGroup}
        title="Download Report"
        className={ReKYCVerificationCss.dropdownBtn}
        variant="none"
        id="bg-nested-dropdown"
        >
        <Dropdown.Item eventKey="1" onClick={() => DownloadReport("compliant")}>Compliance</Dropdown.Item>
        <Dropdown.Item eventKey="2" onClick={() => DownloadReport("non-compliant")}>Non-Compliance</Dropdown.Item>
        <Dropdown.Item eventkey="3" onClick={() => DownloadReport("both")}>All</Dropdown.Item>
        </DropdownButton>
        </ButtonGroup>
        </span>
        </div>
        
        {/* <span style={{ display: "inline-block", margin: "4px 10px", backgroundColor: "#D3D3D3", width:"145px" }}>
            <span className={ReKYCVerificationCss.statusSpan}><div style={{marginLeft: "42px", width: "100px", fontFamily: "var(--poppinsSemiBold)"}}>Customers</div>
            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center", marginLeft: "35px" }}>5</div></span>
        </span>
        <span style={{ display: "inline-block", margin: "4px 10px", backgroundColor: "darkgrey", width:"145px" }}>
            <span className={ReKYCVerificationCss.statusSpan}><div style={{marginLeft: "42px", width: "100px", fontFamily: "var(--poppinsSemiBold)"}}>Compliant</div>
            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center", marginLeft: "35px" }}>1</div></span>
        </span>
        <span style={{ display: "inline-block", margin: "4px 10px", backgroundColor: "#AB3951", width:"145px" }}>
            <span className={ReKYCVerificationCss.statusSpan}><div style={{marginLeft: "30px", width: "100px", fontFamily: "var(--poppinsSemiBold)"}}>Non-Compliant</div>
            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center", marginLeft: "35px" }}>4</div></span>
        </span> */}
          
          
        {/* </div> */}
        {columns.length > 0 ?
          <div style={{ width: "100%" }}>
            <MultiLevelTable columns={columns} data={tableData} tableDivExtraStyle={{
              height: "430px",
            }} />
          </div>
          :
          <BlankTable message={noItemText} />
        }
      </div>
      {
        loading &&
        <LayoutLoading message="Generating Summary" />
      }
    </>

  );

}
export default ReKYCVerification