import React from 'react'
import CustomTabs from '../Utils/CustomTabs'
import ReKycHome from './ReKYCHome'
import ReKYCVerification from './ReKYCVerification'
import DuplicateAccount from './DuplicateAccount'
import { pepCheckIcon, PersonaDetailsIcon, IndividualCDDIcon } from '../../assets/images';

function ReKyc() {
    return (
        <CustomTabs
            tabList={[
                {
                    title: "KYC Verification",
                    icon:  IndividualCDDIcon,
                    eventKey: "KycVerification",
                    getTabComponent: () => <ReKYCVerification/>
                },
                {
                    title: "CDD",
                    icon: pepCheckIcon,
                    eventKey: "Home",
                    getTabComponent: () => <ReKycHome/>
                },
                {
                    title: "Duplicate Account",
                    icon: PersonaDetailsIcon,
                    eventKey: "Duplicate Account",
                    getTabComponent: () => <DuplicateAccount/>
                }
            ]}
        />
    )
}

export default ReKyc