import React from 'react'
import CustomTabs from '../Utils/CustomTabs'
import DocumentUpload from './DocumentUpload'
import KYCGuidelines from './KYCGuidelines'
import { DocumentUploadIcon, GuidelineIcon } from '../../assets/images'

function Documents() {
    return (
        <DocumentUpload/>
        <CustomTabs
            tabList={[
                {
                    title: "KYC Documents",
                    icon: DocumentUploadIcon,
                    eventKey: "calculate",
                    getTabComponent: () => <DocumentUpload/>
                }
                // {
                //     title: "Guidelines",
                //     icon: GuidelineIcon,
                //     eventKey: "bulk_calculate",
                //     getTabComponent: () => <KYCGuidelines/>
                // }
            ]}
        />
    )
}

export default Documents