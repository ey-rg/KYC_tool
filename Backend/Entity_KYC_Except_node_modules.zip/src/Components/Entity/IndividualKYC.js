import React, {useEffect, useState} from 'react';
import BasicTable from '../Utils/BasicTable';
import { Bar } from 'react-chartjs-2';
import { messageService } from '../Utils/messageService';
import axios from 'axios';

function IndividualKYC() {
    const initialData = [
        {cust_id: 'CUST001', name: 'Ajay', kyc_doc: ['Name does not match with Addhar','DOB is different in PAN and Adhaar'], internal_database: 'No duplicate Account'},
        {cust_id: 'CUST002', name: 'Raj', kyc_doc: ['Compliant'], internal_database: '1 duplicate Account, Acc Holder Name: Manoj Raj, ID: CUST005'}
    ];
    const [tableData, setTableData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [chartData, setChartData] = useState({
        labels: [],
    datasets: [
      {
        label: 'Compliance',
        backgroundColor: [ 'rgba(75,192,192,0.2)',
        'rgba(255,99,132,0.2)',
        'rgba(255,205,86,0.2)',],
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 0,
        hoverBackgroundColor: 'rgba(255, 252, 127,0.4)',
        hoverBorderColor: 'rgba(75,192,192,1)',
        data: [],
      },
    ],
    });

  const options = {
    scales: {
      x: {
        title: {
          display: true,
          text: 'Accounts',
        },
        grid: {
            display: false, // Set to false to remove x-axis grid lines
          },
      },
      y: {
        title: {
          display: true,
          text: '',
        },
        ticks: {
            display: false, // Set this to false to hide y-axis data points
          },
          grid: {
            display: false, // Set to false to remove x-axis grid lines
          },
      },
      legend: {
        display: false,
        position: 'top', // Change position to 'bottom', 'left', 'right' as needed
      },
    },
  };


const headers = [
    {
        Header:"Customer ID",
        accessor:"cust_id",
        Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
        }
    },
    {
        Header:"Customer Name",
        accessor:"name"
    },
    {
        Header:"KYC Documents",
        accessor:"kyc_doc",
        Cell: (props) => {
            const splitArray = props.value
            return (
              <span>
              {
                splitArray?.map(element => (
                  <div style={{color:"#0863f1"}}>{element}</div>
                ))
              }
              </span>
            )      
          }
    },
    {
        Header:"Internal Database",
        accessor:"internal_database"
    }
]

useEffect(() => {
    setLoading(true)
    // axios.post(`${process.env.REACT_APP_API_BASE_URL}/individual_kyc`, {
    //     "tab":"individual_kyc_details"
    // })
    //   .then(response => {
    //     setLoading(false)
    //     setTableData(response.data.output)
    //   })
    //   .catch(error => {
    //     setLoading(false)
    //     messageService.sendMessage({ variant: "danger", message: "Server Problem" })
    //   })

        let reqOne = axios.post(`${process.env.REACT_APP_API_BASE_URL}/individual_kyc`, {
            "tab":"individual_kyc_details"
        });
        let reqTwo = axios.post(`${process.env.REACT_APP_API_BASE_URL}/individual_kyc`, {
            "tab":"bar_graph"
        });

        axios.all([reqOne, reqTwo])
        .then((res) => {
        setLoading(false)
        setTableData(res[0].data.output)
        setChartData({
            labels: ['Compliant', 'Non-Compliant', 'Multiple-Account'],
            datasets: [
              {
                ...chartData.datasets[0], // Preserve other dataset properties
                data: res[1].data,
              },
            ],
          });
    });
  }, [])

  return (
    <>
    <div style={{display: "flex"}}>
    <div style={{width: "40%", height: "1000px", paddingTop: "30px"}}>
      <Bar data={chartData} options={options} />
    </div>
    <div style={{width: "60%", height: "1000px", paddingTop: "30px"}}>
    <BasicTable availableColumns={headers} data={tableData}></BasicTable>
    </div>
    </div>
    </>
    
  );
};
export default IndividualKYC