import React from 'react';
import CheckerLayoutCss from './CheckerLayout.module.css'
import CustomTabsChecker from '../Utils/CustomTabsChecker';
import TrackerDashboardLayout from './TrackerDashboardLayout';
import CaseStatus from './CaseStatus';
import QAStatus from './QAStatus';
function TrackerLayout() {
  return (
    <div className={CheckerLayoutCss.processFlow}>
           <CustomTabsChecker
            tabList={[
                {
                    title: "Dashboard",
                    icon: "",
                    eventKey: "calculate",
                    getTabComponent: () => <TrackerDashboardLayout/>
                },
                {
                    title: "Case Status",
                    icon: "",
                    eventKey: "bulk_calculate",
                    getTabComponent: () => <CaseStatus/>
                },
                {
                    title: "QA Status",
                    icon: "",
                    eventKey: "bulk_calculate1",
                    getTabComponent: () => <QAStatus/>
                }
            ]}
        />
    </div>
  )
}

export default TrackerLayout