import React from 'react'
import { QAStatusIcon } from '../../assets/images'
import CheckerLayoutCss from './CheckerLayout.module.css'

function QAStatus() {
    return (
    <div className={CheckerLayoutCss.pane}>
      <img src={QAStatusIcon} alt="QAStatus" style={{width: "100%", height: "520px"}}></img>
    </div>
    )
}

export default QAStatus