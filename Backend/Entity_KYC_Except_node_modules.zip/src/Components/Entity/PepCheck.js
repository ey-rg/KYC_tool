import React, {useEffect, useState} from 'react'
import BasicTable from '../Utils/BasicTable'
import { connect } from 'react-redux'
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import axios from 'axios';
import LayoutLoading from '../Utils/LayoutLoading';
import { Badge } from 'react-bootstrap';
import documentUploadCss from './DocumentUpload.module.css';
import { messageService } from '../Utils/messageService';
import { downloadIcon } from '../../assets/images';

function PepCheck({entityDetails}) {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);

    const headers = [
        { Header:"Name", accessor:"name",
          Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          }
        },
        { Header:"Number of Hits", accessor:"pep_check_summary"},
        { Header: "Source", accessor: "source"},
        { Header:"PEP Check Result", accessor:"pep_check_result",
        Cell:(props) => {
            if (props.value === "Matched") {
              return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            } else if (props.value === "Not Matched") {
                return <span style={{color: "#6c757db3"}}>{props.value}</span>
            } else {
                return <span>{props.value}</span>
            }
        }
        },
        { Header:"Risk Status", accessor: "pep_check_status",
          Cell:(props) => {
            if (props.value === "Low") {
                return <Badge bg="success" className={documentUploadCss.badge}>{props.value}</Badge>
            } else {
                return <Badge bg="danger" className={documentUploadCss.badge}>{props.value}</Badge>
            }
          }
        },
        { Header:"PEP Report", accessor:"matcher_li",
          Cell: (props) => {
            return <img src={downloadIcon} alt="download" onClick={() => DownloadReport(props.row)}/>
          }
        }
    ]

    const DownloadReport = (row) => {
        const headers = { 'Accept': 'application/text' };
        axios.post(`${process.env.REACT_APP_API_BASE_URL}/media_pep_report_download`, {"tab": "pep_screen",
        "name": row.values.name}, {
          responseType: 'blob',
          headers
        })
        .then(response => {
            setLoading(false)
            const element = document.createElement("a");
            element.href = URL.createObjectURL(response.data);
            element.download = `report_${row.values.name}`;
            document.body.appendChild(element);
            element.click();
        })
        .catch(error => {
            setLoading(false)
            messageService.sendMessage({variant:"danger", message: "server problem"})
        })    
    }

    useEffect(() => {
    setLoading(true);
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/media_pep_screen_result`, {"tab": "pep_screen",
    "entity": entityDetails.entityName})
    .then(response => {
        setLoading(false)
        setData(response.data.output)
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message:"server problem"})
    })
    }, [])  
    
    return (
    <>
    <div>
    <BasicTable availableColumns={headers} data={data}></BasicTable>
    </div>
    {
        loading &&
        <LayoutLoading message="Fetching Data"/>
    }
    </>
   )
}

const mapStateToProp = (state) => {
    return {
      entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(PepCheck)
