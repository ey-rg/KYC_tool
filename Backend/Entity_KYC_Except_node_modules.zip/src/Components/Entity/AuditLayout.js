import React, { useState } from 'react';
import { newRequestIcon, progressIcon, completedIcon } from '../../assets/images';
import CheckerLayoutCss from './CheckerLayout.module.css'
import BasicTable from '../Utils/BasicTable';
import { Button } from 'react-bootstrap';
import { Badge } from 'react-bootstrap';
import documentUploadCss from './DocumentUpload.module.css'

function AuditLayout() {
    const initialData = [
        {entityName: 'Emergent BioSolutions UK Ltd', date:"8.10.2023", name: 'user1', checkerName: "user1", assignStatus: "No",
        reviewStatus: 'Not Started', assignedDate: ''},
        {entityName: 'TCS', date:"26.10.2023", name: 'user1', checkerName: "Checker_user", assignStatus:"Yes",
        reviewStatus: 'In Progress', assignedDate: ''},
    ];

    const [data, setData] = useState(initialData)
    const headers = [
        {
            Header:"Entity Name",
            accessor:"entityName",
            Cell:(props) => {
                return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            }
        },
        {
            Header:"Submission Date",
            accessor:"date"
        },
        {
            Header:"Creator Name",
            accessor:"name"
        },
        {
            Header:"Checker Name",
            accessor:"checkerName",
            Cell: (props) => {
                return (
                 props.value === "Checker_user"
                 ? <span>{props.value}</span> :
                <Button variant="secondary" className={CheckerLayoutCss.accept} onClick={() => acceptHandler(props.row)}>Accept</Button>
                )
            }
        },
        {
            Header:"Assign Status",
            accessor:"assignStatus"
        },
        {
            Header:"Review Status",
            accessor:"reviewStatus",
            Cell:(props) => {
                return (
                props.value === "In Progress"
                ? <Badge className={`${documentUploadCss.badge} backgroundDanger`} bg='danger'>{props.value}</Badge>:
                <Badge bg="secondary" className={`${documentUploadCss.badge}`}>{props.value}</Badge>
                )            
            }
        },
        {
            Header:"Assign Date",
            accessor:"assignDate"
        }
    ]
    const acceptHandler = (row) => {
       const modifiedData = data.map(item => {
        if (item.entityName === row.values.entityName) {
           item.assignStatus = "Yes";
           item.checkerName = "Checker_user";
           item.reviewStatus = "In Progress"
           return item;
        } else {
            return item;
        }
       })
       setData(modifiedData);
    }

    return (
        <div className={CheckerLayoutCss.pane}>
            <span style={{ display: "inline-block", margin: "20px 50px", backgroundColor: "#006EB3" }}>
                        <span style={{display: "inline-block", height: "47px", backgroundColor: "#fff"}}><img src={newRequestIcon} alt="progress" style={{ width: "50px" }} /></span>
                        <span className={CheckerLayoutCss.statusSpan} style={{width: "80px"}}><div style={{marginLeft: "6px"}}>New Request</div>
                            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center" }}>1</div></span>
                    </span>
            <span style={{ display: "inline-block", margin: "20px 50px", backgroundColor: "#F17720" }}>
                        <span style={{display: "inline-block", height: "50px"}}><img src={progressIcon} alt="progress" style={{ width: "50px" }} /></span>
                        <span className={CheckerLayoutCss.statusSpan}><div style={{marginLeft: "6px"}}>In Progress</div>
                            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center" }}>1</div></span>
            </span>
            <span style={{ display: "inline-block", margin: "20px 50px", backgroundColor: "#198754" }}>
                        <span style={{display: "inline-block", height: "47px"}}><img src={completedIcon} alt="progress" style={{ width: "50px" }} /></span>
                        <span className={CheckerLayoutCss.statusSpan}><div style={{marginLeft: "6px"}}>Completed</div>
                            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center" }}>0</div></span>
                    </span>
        <div className={CheckerLayoutCss.innerDiv}>
        <BasicTable availableColumns={headers} data={data}></BasicTable>
        </div> 
        </div>
    )
}

export default AuditLayout