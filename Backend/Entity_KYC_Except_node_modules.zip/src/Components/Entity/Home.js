import React, { useState, useEffect } from 'react'
import {Row, Col, Form, Button, Badge} from 'react-bootstrap'
import HomeLayoutCss from './HomeLayout.module.css'
import { verified, pending, hand, summaryAI, DownloadIcon } from '../../assets/images';
import axios from 'axios';
import { messageService } from '../Utils/messageService'
import KycSummaryCss from './KycSummary.module.css'
import documentUploadCss from './DocumentUpload.module.css'
import LayoutLoading from './../Utils/LayoutLoading'
import UpdateAttributes from './UpdateAttributes';
import CustomModal from '../Utils/CustomModal';
import KycReport from './KycReport';
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import { selectSummaryDetails } from '../../redux/summaryDetails/selector';
import { connect } from 'react-redux';
import { Subject } from 'rxjs';
import { navigationService } from '../Utils/NavigationService';
import store from '../../redux/store';
import { setSummaryDetails } from '../../redux/summaryDetails/action'

function Home({ entityDetails, summaryDetails }) {
  const stageInfo = [
   {name: 'Documents', status: ' Pending', isActive: false},
   {name: 'Review', status: ' Pending', isActive: false},
  // {name: 'Screening', status: ' Completed', isActive: false},
   {name: 'Fulfilment', status: ' Pending', isActive: false},
   {name: 'Approval', status: ' Pending', isActive: true},
  ];

  const [stages, setStages] = useState(stageInfo);
  const [loading, setLoading] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [summary, setSummary] = useState('');
  const [riskRating, setRiskRating] = useState({risk_category: '', risk_score: ''})

  const clickHandler = (stageName, e) => {
    stages.forEach(stage => {
      stage.isActive = stage.name === stageName ? true : false
    })
    setStages([...stages]);
  }

  const reportHandler = () => {
    setShowReport(true);
  }

  const navigationHandler = (e) => {
    navigationService.sendMessage(e);
  }

  const DownloadReport = () => {
    const headers = { 'Accept': 'application/text' };
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/download_entity_final_report`, { "entity": entityDetails.entityName }, {
        responseType: 'blob',
        headers
    })
        .then(response => {
            setLoading(false)
            const element = document.createElement("a");
            element.href = URL.createObjectURL(response.data);
            element.download = `report_${entityDetails.entityName}`;
            document.body.appendChild(element);
            element.click();
        })
        .catch(error => {
            setLoading(false)
            messageService.sendMessage({ variant: "danger", message: "server problem" })
        })
}

  useEffect(() => {
    setLoading(true)
    axios.get(`${process.env.REACT_APP_API_BASE_URL}/access_entity_risk`)
    .then(response => {
        setRiskRating(response.data)
        setLoading(false)
    })
    .catch(error => {
        messageService.sendMessage({variant:"danger", message:"server problem"})
    })
   
   
}, [])

useEffect(() => {
  setLoading(true)
  if(Object.keys(summaryDetails).length == 0){
  axios.get(`${process.env.REACT_APP_API_BASE_URL}/entity_kyc_summary`)
  .then(response => {
      // setSummary(response.data)
      store.dispatch(setSummaryDetails(response.data));
      setLoading(false)
  })
  .catch(error => {
    setLoading(false)
    messageService.sendMessage({variant:"danger", message:"server problem"})
})
  }
},[])

  return (
    <div className={HomeLayoutCss.container}>
        <Row style={{backgroundColor: "var(--bodyColor)", border: "1px solid grey", height: "435px"}}>
            <Col md={4}>
              {
                stages.map(stage => {
                  return(
                    <><div className={HomeLayoutCss.stage}>
                      {stage.status === ' Completed' ?
                        <div className={HomeLayoutCss.stageName} onClick={() => clickHandler(stage.name)}>
                          <div style={{ display: "inline-block", paddingTop: "7px", width: "70px" }}>{stage.name}</div>
                        </div> :
                        <div className={HomeLayoutCss.stageName} onClick={() => clickHandler(stage.name)}>
                          <div style={{ display: "inline-block", paddingTop: "7px", width: "70px" }}>{stage.name}</div>
                        </div>}
                      <div className={HomeLayoutCss.stageStatus}>
                        {stage.status === ' Completed' ?
                          <><img style={{ width: "25px" }} src={verified} alt="completed" /><span>{stage.status}</span></> :
                          <><img style={{ width: "25px" }} src={pending} alt="pending" /><span style={{ color: "red" }}>{stage.status}</span></>}
                      </div>
                    </div><div className={HomeLayoutCss.stageDetails}>
                        {
                          stage.name === "Documents" && stage.isActive ?
                          <><ul style={{ margin: "3px 0 0 5px" }}>
                              <li><a onClick={() => navigationHandler('missingDocuments')} className={HomeLayoutCss.navigationLink}>List of Missing Documents(if any)</a>:</li>
                              <li>Passport, Voter ID and Ration Card is not available</li>
                              <li>Electricity bill is not valid</li>
                            </ul><span style={{ marginLeft: "5px" }}><span style={{ fontFamily: "var(--poppinsSemiBold)" }}>Final Status: </span>Few documents are not available</span></> :
                          stage.name === "Review" && stage.isActive ?
                          <><ul style={{ margin: "3px 0 0 5px" }}>
                                <li><a onClick={() => navigationHandler('missingAttributes')} className={HomeLayoutCss.navigationLink}>KYC Review Findings</a>:</li>
                                <li>Found invalid documents</li>
                                <li>Pending and action required</li>
                              </ul><span style={{ marginLeft: "5px" }}><span style={{ fontFamily: "var(--poppinsSemiBold)" }}>Final Status: </span>Kindly review the invalid/unavailable documents and resubmit.</span></>
                          /* : stage.name === "Screening" && stage.isActive ?
                          <><ul style={{ margin: "3px 0 0 5px" }}>
                                  <li><a onClick={() => navigationHandler('ANNMatch')} className={HomeLayoutCss.navigationLink}>ANN Match</a>: 0</li>
                                  <li><a onClick={() => navigationHandler('PEPMatch')}>PEP Match</a>: 0</li>
                                  <li>Sanctions Match: 0</li>
                                </ul><span style={{ marginLeft: "5px" }}><span style={{ fontFamily: "var(--poppinsSemiBold)" }}>Final Status: </span>Entity network Screening  completed</span></>
                                */
                          : stage.name === "Fulfilment" && stage.isActive ?
                          <><ul style={{ margin: "3px 0 0 5px" }}>
                                    <p style={{marginBottom: "0", fontFamily:"var(--poppinsSemiBold)"}}>List of updated KYC Attributes:</p>
                                    <li>Action required on pending documents</li>
                                  </ul><span style={{ marginLeft: "5px" }}><span style={{ fontFamily: "var(--poppinsSemiBold)" }}>Final Status: </span>Kindly resubmit the documents to proceed with the case</span></>
                          : stage.name === "Approval" && stage.isActive ?
                          <div><Form.Control as="textarea"
                          name="inputText"
                          placeholder="Please Add Your Comment here..."
                          style={{resize:"None", height:"50px", width: "360px", margin: "auto", border: "1px solid black", marginTop: "2px"}}
                          className={HomeLayoutCss.textArea}
                          required/>
                          <Button variant="success" className={HomeLayoutCss.submit}>Submit</Button>
                          </div> 
                          : ""
                        }
                      </div></>
                  )
                })
              }
              <img src={hand} alt="hand" /><span className={HomeLayoutCss.comment}>Reviewer's comment & Approval is required for submission of KYC Report for QA Check </span>
            </Col>
            <Col md={8}>
              <div className={HomeLayoutCss.summaryContainer}>
                <div style={{marginBottom:"2px"}}>
                  <img src={summaryAI} alt="summary" />
                  <span className={HomeLayoutCss.summaryTitle}>Case Summary</span>
                  <span className={HomeLayoutCss.report} onClick={reportHandler}>KYC Report</span>
                  <img src={DownloadIcon} alt="download" style={{position:"absolute", right:"115px", width:"30px", height:"25px", cursor: "pointer"}} onClick={DownloadReport}/>
                </div>
                <div className={HomeLayoutCss.summaryDiv}>
                <Row style={{backgroundColor: "#fff", width: "655px", marginLeft: "2px", height: "30px"}}>
                    <Col md={7}>
                    <span className={KycSummaryCss.riskRating}><span>Risk Category: </span>
                      {
                        riskRating.risk_category === "Low" ?
                       <Badge bg="success" className={documentUploadCss.badge}>{riskRating.risk_category}</Badge> :
                       <Badge bg="danger" className={documentUploadCss.badge}>{riskRating.risk_category}</Badge>
                      }
                    </span>
                    </Col>
                    <Col md={5}>
                    <span className={KycSummaryCss.riskRating}><span> Enhance Due Diligence Required</span>
                    <Badge bg="success" className={documentUploadCss.badge}>No</Badge></span>
                    </Col>
                </Row>
                <div style={{overflowY: "auto", height:"305px"}}>
                <div>
                { 
                 summaryDetails &&
                    <ul>
                        <span className={KycSummaryCss.summaryHeader}>Customer Profile</span>
                        <li>{summaryDetails.customer_profile}</li>
                        {/* <li>{summaryDetails.company_profile}</li>}  //Entity KYC */}
                        <span className={KycSummaryCss.summaryHeader}>Overall Risk Assessment</span>
                        <li>{summaryDetails.overall_risk_assesment}</li>
                        <span className={KycSummaryCss.summaryHeader}>Operational Risk</span>
                        <li>{summaryDetails.operational_risk}</li>
                        <span className={KycSummaryCss.summaryHeader}>Geographic Risk</span>
                        <li>{summaryDetails.geographic_risk}</li>
                        <span className={KycSummaryCss.summaryHeader}>Sanctions and Related Activities</span>
                        <li>{summaryDetails.sanctions_related_activities}</li>
                        <span className={KycSummaryCss.summaryHeader}>Business Risk</span>
                        <li>{summaryDetails.business_risk}</li>
                        <span className={KycSummaryCss.summaryHeader}>Financial Risk</span>
                        <li>{summaryDetails.financial_risk}</li>
                        <span className={KycSummaryCss.summaryHeader}>Adverse Media Screening</span>
                        <li>{summaryDetails.adverse_media_screening}</li>
                        <span className={KycSummaryCss.summaryHeader}>Pep Screening</span>
                        <li>{summaryDetails.pep_result}</li>
                        <span className={KycSummaryCss.summaryHeader}>Sanction Screening</span>
                        <li>{summaryDetails.sanaction_result}</li>
                        <span className={KycSummaryCss.summaryHeader}>Ultimate Beneficial Owner (UBO)</span>
                        <li>{summaryDetails.ultimate_beneficial_owner}</li>
                        <span className={KycSummaryCss.summaryHeader}>UBO Determinatoin:</span>
                        <li>{summaryDetails.ubo_determination}</li>

                    </ul>
                }
                </div>
                <Row style={{backgroundColor: "#fff", width: "650px", margin: "2px", height: "30px"}}>
                <span className={KycSummaryCss.riskRating}><span style={{display:"inline-block",padding:"5px"}}>List of KYC Attributes to be updated </span></span>
                </Row>
                <UpdateAttributes />
                </div>
                </div>
              </div>
            </Col>
        </Row>
        {
                loading &&
                <LayoutLoading message="Generating Summary"/>
        }
        {
          showReport &&
          <CustomModal onHideHandler={() => setShowReport(false)} modalHeader='Report' size="lg">
            <KycReport />
          </CustomModal>
        }
    </div>
  )
}

const mapStateToProp = (state) => {
  return {
      entityDetails: selectEntityDetails(state),
      summaryDetails: selectSummaryDetails(state)
  }
}

// const mapStateToProp = (state) => {
//   return {
//       summaryDetails: selectSummaryDetails(state)
//   }
// }

export default connect(mapStateToProp, null)(Home)
