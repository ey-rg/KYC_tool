import React, {useEffect, useState} from 'react'
import BasicTable from '../Utils/BasicTable'
import { connect } from 'react-redux'
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import axios from 'axios';
import LayoutLoading from '../Utils/LayoutLoading';
import { Badge } from 'react-bootstrap';
import documentUploadCss from './DocumentUpload.module.css';
import { messageService } from '../Utils/messageService';
import { downloadIcon } from '../../assets/images';
import DoughnutChart from '../Utils/DoughnutChart';
import {
	Chart as ChartJS,
	CategoryScale,
	LinearScale,
	BarElement,
	Title,
	Tooltip,
	Legend,
} from 'chart.js';
import ChartDataLabels from 'chartjs-plugin-datalabels';
ChartJS.register(
	CategoryScale,
	LinearScale,
	BarElement,
	Title,
	Tooltip,
	ChartDataLabels,
	Legend
);

function Screening({entityDetails}) {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [loadingMsg, setLoadingMsg] = useState("Loading")

    const headers = [
        { Header:"Name", accessor:"name",
          Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          }
        },
        { Header:"NNS Summary", accessor:"media_screening_summary"},
        { Header:"Sentiment Analysis", accessor:"sentiment_analysis",
          Cell: (props) => {
            const splitArray = {};
            const a = props.value.split('% Positive,')
            const b = a.length !== 0 ? a[1].split('% Negative,'): [];
            const c = b.length !== 0 ? b[1].split('% Neutral'): [];
            splitArray['labels'] = ['Positive', 'Negative', 'Neutral']
            splitArray['values'] = [Number(a[0]), Number(b[0]), Number(c[0])]
            return (
             <DoughnutChart chartData={splitArray}/>
            )
          }
        },
        { Header:"Risk Status", accessor: "media_screening_result",
          Cell:(props) => {
            if (props.value === "Low") {
                return <Badge bg="success" className={documentUploadCss.badge}>{props.value}</Badge>
            } else if (props.value === "High") {
                return <Badge bg="danger" className={documentUploadCss.badge}>{props.value}</Badge>
            } else {
                return <span className={`backgroundColor ${documentUploadCss.badge}`}>{props.value}</span>
            }
          }
        },
        { Header:"NNS Report", accessor:"source",
          Cell: (props) => {
            return <img src={downloadIcon} alt="download" onClick={() => DownloadReport(props.row)}/>
          }
        }
    ]

    useEffect(() => {
    setLoading(true);
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/media_pep_screen_result`, {"tab": "media_screen",
    "entity": entityDetails.entityName})
    .then(response => {
        setLoading(false)
        // const data = response.data.output.filter(item => item.name !== 'Mukesh Ambani')
        // const mukesh = response.data.output.find(item => item.name === 'Mukesh Ambani');
        // data.splice(2, 0, mukesh);
        setData(response.data.output)
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message: "server problem"})
    })
    }, [])

    const DownloadReport = (row) => {
       const headers = { 'Accept': 'application/text' };
        axios.post(`${process.env.REACT_APP_API_BASE_URL}/media_pep_report_download`, {"tab": "media_screen",
        "name": row.values.name}, {
          responseType: 'blob',
          headers
        }
       )
        .then(response => {
            setLoading(false)
            const element = document.createElement("a");
            element.href = URL.createObjectURL(response.data);
            element.download = `report_${row.values.name}.txt`;
            document.body.appendChild(element);
            element.click();
        })
        .catch(error => {
            setLoading(false)
            messageService.sendMessage({variant:"danger", message: "server problem"})
        })    
    }
    
    return (
    <>
    <div>
    <BasicTable availableColumns={headers} data={data} tableDivExtraStyle={{
        height: "400px"
    }}></BasicTable>
    </div>
    {
        loading &&
        <LayoutLoading message={loadingMsg}/>
    }
    </>
   )
}

const mapStateToProp = (state) => {
    return {
      entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(Screening)
