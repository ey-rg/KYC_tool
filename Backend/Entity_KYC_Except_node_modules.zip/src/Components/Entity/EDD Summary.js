import React, { useEffect, useState } from 'react'
import guidelinesCss from './KYCGuidelines.module.css'
import { Row, Col } from 'react-bootstrap';
import axios from 'axios';
import LayoutLoading from './../Utils/LayoutLoading'
import KycSummaryCss from './KycSummary.module.css'
import { messageService } from '../Utils/messageService'

function EDDSummary() {
    const [loading, setLoading] = useState(false);
    const [summary, setSummary] = useState('');

    //useEffect(() => {
        //setLoading(true)
    //})
    //     axios.get(`${process.env.REACT_APP_API_BASE_URL}/edd_summary`)
    //     .then(response => {
    //         setSummary(response.data.output)
    //         setLoading(false)
    //     })
    //     .catch(error => {
    //         setLoading(false)
    //         messageService.sendMessage({variant:"danger", message:"server problem"})
    //     })
    // }, [])

    return (
        <>
            <Row className={guidelinesCss.innerDiv} style={{height: "400px"}}>
                <Col md={12} className={guidelinesCss.summary}>
                <div className={guidelinesCss.backgroundColor}>
                <label>EDD Summary</label>
                </div>
                <div className={KycSummaryCss.summary}>
                {/* { 
                 summary &&
                    <ul>
                       <li>{summary[0]}</li>
                        <li>{summary[1]}</li>
                    </ul>
                } */}
                </div>
                </Col>
            </Row>
            {
                loading &&
                <LayoutLoading message="Generating Summary"/>
            }
        </>
    )
}

export default EDDSummary