import React from 'react'
import Streetview  from "react-google-streetview";

function LocationOfc({locationAttr}) {
    const googleMapsKey = locationAttr.apiKey;
  const StreetMapOptions = {
    position: { lat: locationAttr.lat, lng: locationAttr.lng },
    pov: { heading: 100, pitch: 0 },
    zoom: 1,
  };
 return (
    <div
      style={{
        height: "550px",
        backgroundColor: "#cccccc",
      }}
    >
      <Streetview
        apiKey={googleMapsKey}
        streetViewPanoramaOptions={StreetMapOptions}
      />
    </div>
 )
}

export default LocationOfc