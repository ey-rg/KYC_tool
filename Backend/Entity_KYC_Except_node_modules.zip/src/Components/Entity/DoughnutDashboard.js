import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Doughnut } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

function DoughnutDashboard({
    chartData
}) {

    const data = {
        labels: chartData.labels.map(item=>item.toUpperCase()),
        datasets: [
            {
                data: [chartData.values, 100-chartData.values],
                backgroundColor: [
                    '#C36721',
                    '#fff',
                ],
                borderColor: [
                    '#C36721',
                    '#fff',
                ],
                borderWidth: 2
            },
        ]
    };
    return (
        <div style={{width:"120px", height: "120px"}}>
            <Doughnut data={data}
                options={
                    {
                        responsive: true,
                        maintainAspectRatio: true,
                        layout: {
                            padding: 14
                          },
                        plugins: {
                            title: {
                                display: false,
                                text: chartData.title,
                            },
                            legend: {
                                display: false
                            },
                            tooltip: {
                                enabled: false
                              },
                            datalabels: {
                                anchor:"central",
                                backgroundColor: function (context) {
                                    return context.dataset.backgroundColor;
                                },
                                borderRadius: 90,
                                borderWidth: 1,
                                color: 'white',
                                textAlign:"center",
                                font: {
                                    weight: 'bold',
                                    size: "8px"
                                },
                                padding: 5,
                                formatter: function (value, context) {
                                    if (value !== 0) {
                                        return [`${value}%`];
                                    }
                                    return null
                                }
                            }

                        }
                    }
                } />
        </div>
    )
}

export default DoughnutDashboard
