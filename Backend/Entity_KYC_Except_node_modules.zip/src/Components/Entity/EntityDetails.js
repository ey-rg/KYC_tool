import React from 'react'
import CustomTabs from '../Utils/CustomTabs'
import CompanyDetails from './CompanyDetails'
import BusinessTypeRisk from './BusinessTypeRisk'
import PersonaDetails from './PersonaDetails'
import IndividualCDD from './IndividualCDD'
import { CompanyDetailsIcon, BusinessTypeIcon, PersonaDetailsIcon, IndividualCDDIcon } from '../../assets/images'
import BasicTable from '../Utils/BasicTable';


function EntityDetails({showAttr = false}) {
    // const headers = [
    //         { Header:"Beneficiary Name", accessor:"Name", // Update headers as required
    //           Cell:(props) => {
    //             return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
    //           }
    //         },
    //         { Header: "Beneficiary Photo", accessor: "Recent Image",
    //           Cell: (props) => {
    //             return <img style={{width:"50px"}} src={`data:image/jpg;base64,${props.value}`} alt="recent"/>
    //           }
    //         },
    //         { Header:"Identity Proof", accessor:"ID Image",
    //           Cell: (props) => {
    //             return <img style={{width:"70px"}} src={`data:image/jpg;base64,${props.value}`} alt="ID Proof"/>
    //           }
    //         },
    //         { Header: "Identity Proof Type", accessor: "Proof Type"},
    //         { Header:"Identification Number", accessor:"Identification Number"},
    //         { Header: "Gender", accessor: "Gender"},
    //         { Header:"Date of Birth", accessor:"Date of Birth"},
    //         { Header:"Address", accessor:"Address"},
    //         {Header:"Verified", accessor: "",
    //           Cell: (props) => {
    //             // return <img style={{width:"25px"}} src={verified} alt="ID Proof"/>
    //           }
    //         },
    //         {Header:"Score", accessor:"score"},
    //       { Header: "Image Comparision", accessor: "result",
    //         Cell: (props) => {
    //           if (props.value === "Not Matched") {
    //             return <span style={{color:"red", fontWeight: "Bold"}}>{props.value}</span>
    //           } else {
    //             return <span>{props.value}</span>
    //           }
    //         }
    //       }
    //     ]



    // Fetch or pass the data as required for individual KYC
        const headers = [
            { Header:"ID", accessor:"id"},
            { Header: "Document Name", accessor: "documentName"},
            { Header:"Status", accessor:"status"},
            { Header: "Comments", accessor: "comments"},
        ]

        const data = [{ id: 1, documentName: 'Adhar Card', status: 'Available', comments: 'Verified'},
                      { id: 2, documentName: 'PAN Card', status: 'Available', comments: 'Verified'},
                      { id: 3, documentName: 'Passport', status: 'Not Available', comments: 'Pending'},
                      { id: 4, documentName: 'Voter ID Card', status: 'Not Available', comments: 'Pending'},
                      { id: 5, documentName: 'Ration Card', status: 'Not Available', comments: 'Pending'},
                      { id: 6, documentName: 'Electricity Bill', status: 'Not Valid', comments: 'Pending - Blurred Image'}] // Fetch or pass the data as required for individual KYC
    return ( 
    <BasicTable availableColumns={headers} data={data}></BasicTable>
            /*<CustomTabs
            tabList={[
                {
                    title: "Company Details",
                    icon: CompanyDetailsIcon,
                    eventKey: "company details",
                    getTabComponent: () => <CompanyDetails showAttr={showAttr}/>
                },
                {
                    title: "Business Risk",
                    icon: BusinessTypeIcon,
                    eventKey: "Business Type/Risk",
                    getTabComponent: () => <BusinessTypeRisk/>
                },
                {
                    title: "Personal Details",
                    icon: PersonaDetailsIcon,
                    eventKey: "persona details",
                    getTabComponent: () => <PersonaDetails/>
                },
                {
                    title: "Individual CDD",
                    icon: IndividualCDDIcon,
                    eventKey: "Individual CDD",
                    getTabComponent: () => <IndividualCDD/>
                }
                // {
                //     title: "Missing/Update Attributes",
                //     icon: MissingattributesIcon,
                //     eventKey: "Missing Attributes",
                //     getTabComponent: () => <MissingAttributes/>
                // }
                
            ]}
        />
        */
    )
}

export default EntityDetails