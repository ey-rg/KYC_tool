import React, { useState, useEffect } from 'react'
import axios from 'axios'
import LayoutLoading from '../Utils/LayoutLoading';
import { messageService } from '../Utils/messageService';
import BasicTable from '../Utils/BasicTable';
import { verified, MissingattributesIcon } from '../../assets/images';
import MissAttributes from './MissAttributes';
import CustomModal from '../Utils/CustomModal';
import { Button } from 'react-bootstrap';
import documentUploadCss from './DocumentUpload.module.css'

function IndividualCDD() {
    const [loading, setLoading] = useState(false);
    const [data, setData] = useState([]);
    const [showMissAttributes, setShowMissAttributes] = useState(false);

    const headers = [
        { Header:"Beneficiary Name", accessor:"Name",
          Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          }
        },
        { Header: "Beneficiary Photo", accessor: "Recent Image",
          Cell: (props) => {
            return <img style={{width:"50px"}} src={`data:image/jpg;base64,${props.value}`} alt="recent"/>
          }
        },
        { Header:"Identity Proof", accessor:"ID Image",
          Cell: (props) => {
            return <img style={{width:"70px"}} src={`data:image/jpg;base64,${props.value}`} alt="ID Proof"/>
          }
        },
        { Header: "Identity Proof Type", accessor: "Proof Type"},
        { Header:"Identification Number", accessor:"Identification Number"},
        { Header: "Gender", accessor: "Gender"},
        { Header:"Date of Birth", accessor:"Date of Birth"},
        { Header:"Address", accessor:"Address"},
        {Header:"Verified", accessor: "",
          Cell: (props) => {
            return <img style={{width:"25px"}} src={verified} alt="ID Proof"/>
          }
        },
        {Header:"Score", accessor:"score"},
      { Header: "Image Comparision", accessor: "result",
        Cell: (props) => {
          if (props.value === "Not Matched") {
            return <span style={{color:"red", fontWeight: "Bold"}}>{props.value}</span>
          } else {
            return <span>{props.value}</span>
          }
        }
      }
    ]

    useEffect(() => {
        setLoading(true)
        axios.get(`${process.env.REACT_APP_API_BASE_URL}/individual_cdd`)
        .then(response => {
            setLoading(false)
            const cddArray = [];
            const obj1 = {};
            const obj2 = {};
            Object.keys(response.data).forEach(key => {
               obj1[key] = response.data[key][0]
               obj2[key] = response.data[key][1]
            })
            cddArray.push(obj1);
            cddArray.push(obj2);
            setData(cddArray);
        })
        .catch(error => {
            setLoading(false)
            messageService.sendMessage({variant: "danger", message: "Server Problem"})
        })
    }, [])

  return (
   <>
           <img src={MissingattributesIcon} alt="missingAttribute" style={{width: "45px"}} className={documentUploadCss.attributes}/>
    <Button className={`${documentUploadCss.attributes} backgroundDanger`} variant='danger' 
    onClick={() => setShowMissAttributes(true)}>Missing Attributes</Button>
    <BasicTable availableColumns={headers} data={data}></BasicTable>
   {
        loading &&
        <LayoutLoading message="Loading"/>
    }
  {
    showMissAttributes &&
    <CustomModal onHideHandler={() => setShowMissAttributes(false)} modalHeader='Missing Attributes'>
     <MissAttributes />
    </CustomModal>
  }
   </>
  )
}

export default IndividualCDD