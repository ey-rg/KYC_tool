import React, {useEffect, useState} from 'react'
import OrgChart from 'react-orgchart';
import axios from 'axios';
import { messageService } from '../Utils/messageService';
import LayoutLoading from '../Utils/LayoutLoading';
import HierarchyModuleCss from './Hierarchy.module.css';
import 'react-orgchart/index.css';

function Hierarchy({tab}) {
  const [loading, setLoading] = useState(false);
  const [hierarchy, setHierarchy] = useState([]);

  function MyNodeComponent({ node }) {
    let nodeName;
    if (node && node.name) {
       nodeName = node.name.split(' ').join('')
    }
    if (node && node.percent_share && node.percent_share !== '<1%'){
    return (
      <div className={HierarchyModuleCss.initechNode} id={nodeName} style={{backgroundColor: '#C36721', fontFamily: 'var(--poppinsBold)'}}>
        {node.name} {node.place ? `, ${node.place}`: ''} 
        {node.percent_share ? node.percent_share === '<1%' ? `, *` : `, ${node.percent_share}`: ''}
      </div>
    );
    } else {
      return (
        <div className={HierarchyModuleCss.initechNode} id={nodeName} style={{backgroundColor: (node.percent_share != 'undefined' && node.name !== "5% or greater stockholders") ? '#C36721 !important' : '#f3a061'}}>
        {node.name} {node.place ? `, ${node.place}`: ''} 
        {node.percent_share ? node.percent_share === '<1%' ? `, *` : `, ${node.percent_share}`: ''}
      </div>
      ) 
    }
  }

  useEffect(() => {
    setLoading(true)
    if (tab === "ownership_hierarchy") {
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/hierarchy_chart`, {"tab": "ownership_hierarchy"})
    .then(response => {
        setLoading(false)
        setHierarchy(response.data)
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message: "server problem"})
    })
    } else {
        axios.post(`${process.env.REACT_APP_API_BASE_URL}/hierarchy_chart`, {"tab": "organization_hierarchy"})
        .then(response => {
            setLoading(false)
            setHierarchy(response.data)
        })
        .catch(error => {
            setLoading(false)
            messageService.sendMessage({variant: "danger", message: "server problem"})
        })  
    }
    }, [])  

  return (
    <div id="initechOrgChart">
        <OrgChart tree={hierarchy} NodeComponent={MyNodeComponent} /><div>
         { tab === "ownership_hierarchy" && <div style={{display: 'flex', marginTop: '196px'}}>
          <div style={{fontSize: 'var(--fontSizeHeading)', fontFamily: "var(--poppinsBold)",marginRight: '10px'}}>'*'</div>
          <div className={HierarchyModuleCss.legend}> Represents beneficial ownership of less than 1% of common stock.</div>
          </div>}
        
          {loading &&
              <LayoutLoading message="Loading" />} </div></div>
  )
}

export default Hierarchy