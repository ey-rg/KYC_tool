import React from 'react'
import CustomTabs from '../Utils/CustomTabs'
import Screening from './Screening'
import PepCheck from './PepCheck'
import SanctionCheck from './SanctionCheck'
import { ScreeningIcon, pepCheckIcon, SanctionCheckIcon } from '../../assets/images'

function MediaScreening({key}) {
    return (
        <CustomTabs
            tabList={[
                {
                    title: "Adverse Media Screening",
                    icon: ScreeningIcon,
                    eventKey: "Screening",
                    getTabComponent: () => <Screening/>
                },
                {
                    title: "Sanctions Screening",
                    icon: SanctionCheckIcon,
                    eventKey: "Sanction Check",
                    getTabComponent: () => <SanctionCheck/>
                },
                {
                    title: "PEP Screening",
                    icon: pepCheckIcon,
                    eventKey: "PEP Check",
                    getTabComponent: () => <PepCheck/>
                }
            ]} key={key}
        />
    )
}

export default MediaScreening