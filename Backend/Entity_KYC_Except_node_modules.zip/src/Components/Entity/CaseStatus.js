import React from 'react'
import { caseStatus } from '../../assets/images'
import CheckerLayoutCss from './CheckerLayout.module.css'

function CaseStatus() {
    return (
    <div className={CheckerLayoutCss.pane}>
      <img src={caseStatus} alt="caseStatus" style={{width: "100%", height: "520px"}}></img>
    </div>
    )
}

export default CaseStatus