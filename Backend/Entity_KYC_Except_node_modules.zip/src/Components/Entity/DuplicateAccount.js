import React, { useState, useEffect } from 'react';
import axios from 'axios';
import BlankTable from '../Utils/BlankTable';
import { Bar } from 'react-chartjs-2';
import MultiLevelTable from '../Utils/MultiLevelTable';
import ReKYCVerificationCss from './ReKYCVerification.module.css'
import {Button} from 'react-bootstrap'

function DuplicateAccount({noItemText = "No Record Found"}) {
    const [excelData, setExcelData] = useState([]);
    const [chartData, setChartData] = useState({
        labels: [],
    datasets: [
      {
        label: 'Compliance',
        backgroundColor: [ "#003f5c",'#58508d',"#bc5090"],
        borderColor: 'rgba(75,192,192,1)',
        borderWidth: 0,
        hoverBackgroundColor: 'rgba(255, 252, 127,0.4)',
        hoverBorderColor: 'rgba(75,192,192,1)',
        data: [],
      },
    ],
    });

  const options = {
    scales: {
      x: {
        title: {
          display: false,
          text: 'Accounts',
        },
        grid: {
            display: false, // Set to false to remove x-axis grid lines
          },
      },
      y: {
        title: {
          display: true,
          text: '',
        },
        ticks: {
            display: false, // Set this to false to hide y-axis data points
          },
          grid: {
            display: false, // Set to false to remove x-axis grid lines
          },
      },
     
    },
    plugins: {
      legend: {
        display: false,
      },
      datalabels: {
        display: true, color: 'black',
      },
    },
  };

  useEffect(() => {
    // Fetch data from backend (replace 'your_backend_endpoint' with the actual endpoint)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/individual_kyc`, {
      "tab":"bar_graph_duplicate_acc"
    })
      .then(response => {
        // Assuming the backend returns Excel data in some format
        setChartData({
          labels: ['Total','Compliant', 'Non-Compliant'],
          datasets: [
            {
              ...chartData.datasets[0], // Preserve other dataset properties
              data: response.data,
            },
          ],
        });
      })
      .catch(error => {
        console.error('Error fetching Excel data:', error);
      });
  }, []); 
  
   
    const data = 
      [{cust_id: "CUST001", name: "Ajay kumar", pan_no: "xxxxxx7585F", no_ucic_id: "2", no_joint_acc:"1", no_ind_acc: "1", compliance_status:"Non-Compliant"},
      {"cust_id": "CUST002", "name": "Kamal Kumar", "pan_no": "xxxxxx4921A", "no_ucic_id": "1", "no_joint_acc": "1", "no_ind_acc": "0", "compliance_status": "Compliant"}, 
      {"cust_id": "CUST003", "name": "Sri Ram", "pan_no": "xxxxxx6132P", "no_ucic_id": "3", "no_joint_acc": "1", "no_ind_acc": "2", "compliance_status": "Non-Compliant"},
      {"cust_id": "CUST004", "name": "Amit", "pan_no": "xxxxxx8497G", "no_ucic_id": "4", "no_joint_acc": "2", "no_ind_acc": "2", "compliance_status": "Non-Compliant"},
      {"cust_id": "CUST005", "name": "Kumari Anjali", "pan_no": "xxxxxx2053J", "no_ucic_id": "1", "no_joint_acc": "1", "no_ind_acc": "0", "compliance_status": "Compliant"}, 
      {"cust_id": "CUST006", "name": "Pooja Reddy", "pan_no": "xxxxxx3186H", "no_ucic_id": "0", "no_joint_acc": "0", "no_ind_acc": "0", "compliance_status": "Compliant"},
      {"cust_id": "CUST007", "name": "Neha Desai", "pan_no": "xxxxxx4690K", "no_ucic_id": "0", "no_joint_acc": "0", "no_ind_acc": "0", "compliance_status": "Compliant"}, 
      {"cust_id": "CUST008", "name": "Rajesh Verma", "pan_no": "xxxxxx7248R", "no_ucic_id": "0", "no_joint_acc": "0", "no_ind_acc": "0", "compliance_status": "Compliant"}, 
      {"cust_id": "CUST009", "name": "Arjun Mehta", "pan_no": "xxxxxx5832M", "no_ucic_id": "1", "no_joint_acc": "1", "no_ind_acc": "0", "compliance_status": "Compliant"}, 
      {"cust_id": "CUST010", "name": "Deepika Choudhary", "pan_no": "xxxxxx9461N", "no_ucic_id": "0", "no_joint_acc": "0", "no_ind_acc": "0", "compliance_status": "Compliant"}]
    ;
  
    // const columns = [
    //   {
    //     Header: 'Database',
    //     colSpan: 2,
    //     columns: [
    //       {
    //         Header: 'Customer Details',
    //         accessor: 'cust_det',
    //         colSpan: 2,
    //         columns: [
    //           { Header: 'Cust ID',
    //            accessor: 'cust_id' },
    //           { Header: 'Customer Name',
    //            accessor: 'customer_name' },
    //         ],
    //       },
    //     ],
    //   },
    //   {
    //     Header: 'KYC Document Status',
    //     colSpan: 2,
    //     columns: [
    //       {
    //         Header: 'KYC Documents',
    //         accessor: 'kyc_doc',
    //         columns: [
    //           { Header: 'Available',
    //            accessor: 'available' },
              
    //         ],
    //       },
    //       {
    //         Header: 'Passport/DL',
    //         accessor: 'pass/dl',
    //         columns: [
    //           { Header: 'Expiry Check',
    //            accessor: 'expiry_check' },
              
    //         ],
    //       },
    //     ],
    //   },
    //   {
    //     Header: 'KYC Compliance Parameter',
    //     colSpan: 5,
    //     columns: [
    //       {
    //         Header: 'POI',
    //         accessor: 'poi',
    //         colSpan: 2,
    //         columns: [
    //           { Header: 'Name',
    //            accessor: 'name' ,
    //            Cell:(props) => {
    //             if (props.value === "Matched") {
    //               return <img src={Matched} alt="matched" style={{width: "36px", marginRight: "4px"}}/>
    //             } else if (props.value === "Not Matched") {
    //                 return <img src={NotMatched} alt="notmatched" style={{width: "36px", marginRight: "4px"}}/>
    //             } else {
    //                 return <span>{props.value}</span>
    //             }
    //         }},
    //            { Header: 'DOB',
    //            accessor: 'dob' }
              
    //         ],
    //       },
    //       {
    //         Header: 'POV',
    //         accessor: 'pov',
    //         colSpan: 2,
    //         columns: [
    //           { Header: 'Address',
    //            accessor: 'address' },
    //            { Header: 'Identity No.',
    //            accessor: 'id_no' },
    //         ],
    //       },
    //       {
    //         Header: 'Photo Verification',
    //         accessor: 'photo_verification',
    //         colSpan: 1,
    //         columns: [
    //           { Header: 'Face Matching',
    //            accessor: 'face_matching' },
              
    //         ],
    //       },
    //     ],
    //   },
    //   {
    //     Header: 'RE-KYC Outcome',
    //     rowSpan: 2,
    //     colSpan: 1,
    //     columns: [
    //           {  Header: 'Compliance Status',
    //           accessor: 'compliance_status' }
    //     ],
    //   },
    // ];

    const columns = [
      {
        Header: 'Customer Database',
        colSpan: 2,
        columns: [
         
              { Header: 'Cust ID',
               accessor: 'cust_id' },
              { Header: 'Customer Name',
               accessor: 'name' },
            ],
      },
      {
        Header: 'Multiple CUST ID Check',
        colSpan: 2,
        columns: [
              { Header: 'PAN NO.',
               accessor: 'pan_no' },
              { Header: 'No. of UCIC/CUST ID with same PAN NO.',
               accessor: 'no_ucic_id' },   
        ],
      },
      {
        Header: 'Account Type of Duplicate CUST IDs',
        colSpan: 2,
        columns: [
             
               { Header: 'No. of Joint Account',
               accessor: 'no_joint_acc' },
              { Header: 'No. of Individual Account',
               accessor: 'no_ind_acc' ,
               Cell:(props) => {
                   return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
                }
              },
            ],
      },
      {
        Header: 'Outcome',
        accessor: 'compliance_status',
        Cell:(props) => {
          if (props.value === "Compliant") {
            return <span style={{color:"#008000", fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          } else if (props.value === "Non-Compliant") {
              return <span style={{color:"#FF0000", fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          } else {
              return <span>{props.value}</span>
          }
       },
        colSpan: 1,
      },
    ];
    
  
    
  
    return (
      <>
      <div style={{display: "flex"}}> 
        { columns.length > 0 ? 
        <div style={{width: "54%"}}>
            <MultiLevelTable columns={columns} data={data} tableDivExtraStyle={{
        height: "350px", 
    }}/>
          </div>
        : 
        <BlankTable message={noItemText} />
        
        }
        <div style={{flexDirection: "column", width: "48%"}}>
        <Button  className={ReKYCVerificationCss.DownloadReport}>Download Report</Button>
        <div className={ReKYCVerificationCss.BarStyle}>
        <h2 className={ReKYCVerificationCss.BarTitle}>Duplicate Account Verification</h2>
        <Bar data={chartData} options={options} />
        </div>
        </div>
        </div>
        </>
      
    );
    
}
export default DuplicateAccount