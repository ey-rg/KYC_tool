import React, { useState } from 'react'
import { Button, InputGroup, Form, Badge } from 'react-bootstrap';
import ReKycCss from './ReKyc.module.css'
import axios from 'axios';
import { messageService } from '../Utils/messageService';
import BasicTable from '../Utils/BasicTable';
import LayoutLoading from '../Utils/LayoutLoading';
import documentUploadCss from './DocumentUpload.module.css';
import ReKYCVerificationCss from './ReKYCVerification.module.css';
import { Matched, NotMatched } from '../../assets/images';
import { read, utils, write } from 'xlsx';
import BasicTableCss from '../Utils/BasicTable.module.css'
import { Table } from 'react-bootstrap'
import CustomAlert from '../CustomAlert'

function ReKycHome() {
    const fileFieldRef = React.createRef();
    const [loading, setLoading] = useState(false);
    const [files, setFiles] = useState();
    const [modalData, setModalData] = useState('');
    const [showExcelData, setShowExcelData] = useState(false);
    const [data, setData] = useState([]);
    const obj = {};
    const headers = [
        {
          Header: "CUST ID", accessor: "cid",
          Cell:(props) => {
            return <div>{"CI00" + props.value}</div>
          }
        },
        { Header: "POI (Database)", accessor: "poi_db"
        },
        {
          Header: "POA (Database)", accessor: "pov_db"
        },
        { Header: "Validity Check", accessor: "validity_check" },
        {
          Header: "Name", accessor: "name",
          Cell: (props) => {
               
            return <span  style={{ fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
        }
        },
        { Header: "DOB", accessor: "dob" },
        { Header: "IDENTITY Number", accessor: "id_no" },
        { Header: "Address", accessor: "address" },
        { Header: "POI  Match", 
          accessor: "poi_match",
          Cell: (props) => {
            if (props.value === "Matched") {
              return <img src={Matched} alt="matched" className={ReKYCVerificationCss.Matched} />
            } else if (props.value === "Not Matched" || props.value === "NA") {
              return <img src={NotMatched} alt="notmatched" className={ReKYCVerificationCss.notMatched} />
            } else {
              return <span>{props.value}</span>
            }
          }   
        },
        { Header: "POA Match", 
          accessor: "pov_match",
          Cell: (props) => {
            if (props.value === "Matched") {
              return <img src={Matched} alt="matched" className={ReKYCVerificationCss.Matched} />
            } else if (props.value === "Not Matched" || props.value === "NA") {
              return <img src={NotMatched} alt="notmatched" className={ReKYCVerificationCss.notMatched} />
            } else {
              return <span>{props.value}</span>
            }
          }
        },
        { Header: "Compliance Status", accessor: "compliant_status",
        Cell: (props) => {
            if (props.value === "Compliant") {
              return <span style={{ color: "#008000", fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
            } else if (props.value === "Non-Compliant") {
              return <span style={{ color: "#FF0000", fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
            } else {
              return <span>{props.value}</span>
            }
          }
        },
        { Header: "Reason of Non-Compliance", accessor: "reason_non_complaint_area",
        Cell: (props) => {
            if (props.value !== "NA") {
              return <span style={{ color: "#008000", color: "#2471A3", fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
            } else {
              return <span>{props.value}</span>
            }
          }
     },
      ]

    const uploadHandler = (e) => {
        const filestmp = e.target.files;
        (filestmp[0].type.includes('image')) == true ?
        readFile(1, filestmp) :
        readExcel(filestmp);

    }

    const readExcel = (filestmp) => {
      const excelFile = filestmp[0];
      setShowExcelData(true);
      const formData = new FormData();
      formData.append("file", excelFile);
      for (const [key, value] of formData.entries()) {
        console.log(`${key}: ${value}`);
      }
      // const ws = utils.json_to_sheet(excelfile);
      // const wb = utils.book_new();
      // utils.book_append_sheet(wb, ws, 'Sheet1');
      // const blob = write(wb, { bookType: 'xlsx', type: 'blob', mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      // console.log(blob);
    // const reader = new FileReader();

    // reader.onload = (e) => {

    // const arrayBuffer = e.target.result;
    // const workbook = read(arrayBuffer, { type: 'array' });
    // const sheetName = workbook.SheetNames[0];
    // const worksheet = workbook.Sheets[sheetName];
    // console.log(worksheet);
    // // const excelData = processDateCells(utils.sheet_to_json(worksheet, { header: 1 }));
    // // const processedData = customSheetToJSON(worksheet, { header: 1 });
    //const processedData = processDateCells(worksheet);
    const headers= {
      'Content-Type': 'multipart/form-data',
    };
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/reference_db`, formData, {headers})
    .then(response => {
              setData(response.data);
              setModalData('Please Upload the KYC Images');
            });
     // console.log(processedData);
    

    // reader.readAsArrayBuffer(excelfile);
    }

    const processDateCells = (worksheet) => {
      const range = utils.decode_range(worksheet['!ref']);
      const data = [];
  
      for (let rowIndex = range.s.r; rowIndex <= range.e.r; rowIndex++) {
        const row = [];
        for (let colIndex = range.s.c; colIndex <= range.e.c; colIndex++) {
          const cellAddress = { r: rowIndex, c: colIndex };
          const cellRef = utils.encode_cell(cellAddress);
          const cell = worksheet[cellRef];
  
          // Check if the cell is a date and format it
          if (cell && isDate(cell.w)) {
            row.push(formatDate(cell.w));
          } else {
            row.push(cell ? cell.v : undefined);
          }
        }
        data.push(row);
      }
  
      return data;
    };
  
    // Check if a value is a date
    const isDate = (value) => {
      const date = new Date(value);
    // Check if the date is valid and the input string was not an invalid date representation
      return !isNaN(date.getTime()) && date.toString() !== 'Invalid Date';
    };
  
    // Format a date for display
    const formatDate = (dateValue) => {
      // const jsDate = new Date((dateValue - (25567 + 1)) * 86400 * 1000);
      // return jsDate.toLocaleDateString(); // Adjust date formatting as needed
      const [day, month, year] = dateValue.split('/').map(Number);

  // Assuming 'DD-MM-YY' format, so adding '20' to the year for the 21st century
  const fullYear = year >= 0 && year <= 99 ? 2000 + year : year;

  const date = new Date(fullYear, month - 1, day); // Note: Month is zero-indexed in JavaScript

  if (!isNaN(date.getTime())) {
    // If the date is valid, format it as 'DD-MM-YYYY'
    const formattedDate = `${day}-${month < 10 ? '0' + month : month}-${date.getFullYear()}`;
    return formattedDate;
  }

  return null;
    };

    const readFile = (index, filestmp) => {
      setShowExcelData(false);
        let reader = new FileReader();
        if (index > filestmp.length) {
            setFiles(obj);
            setLoading(true)
            axios.post(`${process.env.REACT_APP_API_BASE_URL}/individual_kyc`, obj)
            .then(response => {
                setLoading(false)
                const tmpData = [];
                Object.keys(response.data).forEach(key => {
                    tmpData.push(response.data[key]);
                })
                tmpData.sort((data1, data2) => data1.cid - data2.cid)
                setData(tmpData)
            })
            .catch(error => {
                setLoading(false)
                messageService.sendMessage({variant: "danger", message: "Server Problem"})
            })
            return;
        };
        reader.onload = (e) => {
           obj["image_" + (index)] = e.target.result
           readFile(index + 1, filestmp);
        }
        reader.readAsDataURL(filestmp[(index-1)]);
    }

    return (
        <Form style={{width: "100%"}}>
             {
        loading &&
        <LayoutLoading message="Retreiving Information" />
      }
            <input type="file" multiple placeholder='Upload Document' onChange={uploadHandler} hidden={true}
                ref={fileFieldRef} />
            <InputGroup size="sm" className={ReKycCss.inputGroup}>
                <Form.Control
                    aria-label="Example text with button addon"
                    aria-describedby="basic-addon1"
                    disabled
                    value={files ? files.name : ""}
                    title={files ? files.name : ""}
                    placeholder='No file choosen...'
                />
                <Button style={{background: '#676767'}}
                    disabled={loading}
                    onClick={() => {
                        fileFieldRef.current.value = null
                        fileFieldRef.current.click()
                    }}>
                    Upload
                </Button>
            </InputGroup>
            <div>
            { !showExcelData && data.length>0 ? 
            <BasicTable availableColumns={headers} data={data}  tableDivExtraStyle={{
                height: "380px", borderCollapse: "separate"
            }}></BasicTable> : showExcelData && data.length > 0 ? 
            <div className={BasicTableCss.tableDiv} style={{height: '395px'}}>
            <Table size="sm" borderless  
            className={`table ${BasicTableCss.customTable}`} >
          <thead>
            <tr>
              {data.length>0 && data[0].map((header, index) => (
                <th key={index}>{header}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data .length> 0 && data.slice(1).map((row, rowIndex) => (
              <tr key={rowIndex}>
                {row.map((cell, cellIndex) => (
                  <td key={cellIndex}>{cell}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </Table>
        </div> : 
        <div className={ReKYCVerificationCss.Message}>
          Please Upload the Database File.
        </div>
        }
            </div>
            {
          modalData !== "" &&
          <CustomAlert message={modalData} hideHandler={() => {
              setModalData("")
          }} />
            }
        </Form>
       
    )
}

export default ReKycHome