import React, { useState } from 'react'
import EntityLayoutCss from './EntityLayout.module.css'
import { useNavigate } from 'react-router-dom'
import { setEntityDetails } from '../../redux/entityDetails/action'
import store from '../../redux/store'
import { progressIcon, completedIcon } from '../../assets/images';
import CheckerLayoutCss from './CheckerLayout.module.css'
import BasicTable from '../Utils/BasicTable';
import { Badge } from 'react-bootstrap';
import documentUploadCss from './DocumentUpload.module.css'

function EntityLayout() {
    const navigate = useNavigate();
    const initialData = [
        {customerName: "Deepak Srivastava", jurisdiction: "IND", rmDetails: "Rajiv", assignedDate: "24 Dec 2025",email: 'deepaksrivastava92@gmail.com',// 'biswasdipanjanaey24@gmail.com',
        dueDate: "15 Jan 2026", completionDate: "", reviewStatus: "In Progress", kycProcessStatus: "KYC Review incomplete due to missing documents", caseID: "114562389"},
        // {entityName: "XYZ Limited", jurisdiction: "UK", rmDetails: "Peter", assignedDate: "22 Jun 2024",
        // dueDate: "15 Sep 2024", completionDate: " ", reviewStatus: "In Progress", kycProcessStatus: "Entity Information Review completed , wating for Client Confirmation Mail", caseID: "142463282"},
    ];
    const [data, setData] = useState(initialData)
    const headers = [
        {
            Header: "Case ID",
            accessor: "caseID",
            Cell: (props) => {
                return (
                  <span onClick={() => clickHandler(props.row.values.entityName)}
                        style={{ color: 'rgb(0, 110, 179)', fontFamily: "var(--poppinsSemiBold)", fontSize: "var(--fontSizeSmall)", cursor: "pointer" }}>{props.value}</span>
                )
              }
        },
        {
            Header:"Customer Name",
            accessor:"customerName"
        },
        {
            Header:"Jurisdiction",
            accessor:"jurisdiction"
        },
        {
            Header:"RM Details",
            accessor:"rmDetails"
        },
        {
            Header:"E-mail",
            accessor:"email"
        },
        {
            Header:"Assigned Date",
            accessor:"assignedDate"
        },
        {
            Header: "Due Date",
            accessor: "dueDate"
        },
        {
            Header: "Review Status",
            accessor: "reviewStatus",
            Cell:(props) => {
                return <Badge className={`${documentUploadCss.badge} backgroundDanger`} bg='danger'>{props.value}</Badge>
            }
        },
        {
            Header: "KYC Progress Status",
            accessor: "kycProcessStatus",
            Cell:(props) => {
                return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            }
        },
        {
            Header: "Completion Date",
            accessor: "completionDate"
        }
    ]

    const clickHandler = (entityName) => {
      store.dispatch(setEntityDetails({entityName}));
      navigate('/entity/entityKYC');
    }

    return (
        <><div className={EntityLayoutCss.entityLayoutTitle}>
            <span style={{ display: "inline-block"}}>KYC Refresh Dashboard</span></div><div className={EntityLayoutCss.pane}>
                <div className={EntityLayoutCss.innerDiv}>
                    <span style={{ display: "inline-block", margin: "20px 50px", backgroundColor: "#F17720", width:"145px" }}>
                        <span style={{display: "inline-block", height: "47px"}}><img src={progressIcon} alt="progress" style={{ width: "47px" }} /></span>
                        <span className={CheckerLayoutCss.statusSpan}><div style={{marginLeft: "6px"}}>In Progress</div>
                            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center" }}>1</div></span>
                    </span>
                    <span style={{ display: "inline-block", margin: "20px 50px", backgroundColor: "#198754", width:"145px" }}>
                        <span style={{display: "inline-block", height: "41px"}}><img src={completedIcon} alt="progress" style={{ width: "50px" }} /></span>
                        <span className={CheckerLayoutCss.statusSpan}><div style={{marginLeft: "6px"}}>Completed</div>
                            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center" }}>0</div></span>
                    </span>
                    <div className={CheckerLayoutCss.innerDiv}>
                        <BasicTable availableColumns={headers} data={data}></BasicTable>
                    </div>
                </div>
            </div></>
    )
}

export default EntityLayout