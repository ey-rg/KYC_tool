import React, { useState, useEffect } from 'react'
import reportCss from './KycReport.module.css'
import axios from 'axios'
import { messageService } from '../Utils/messageService';
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import LayoutLoading from '../Utils/LayoutLoading';
import { connect } from 'react-redux';
import { pdfjs, Document, Page } from 'react-pdf';

function KycReport({ entityDetails }) {
    const [loading, setLoading] = useState(false);
    const [file, setFile] = useState('');
    const [numPages, setNumPages] = useState(1);
    const maxWidth = 760; 

    pdfjs.GlobalWorkerOptions.workerSrc = new URL(
        'pdfjs-dist/build/pdf.worker.min.js',
        import.meta.url,
      ).toString();
      

    const DownloadReport = (item) => {
        const headers = { 'Accept': 'application/text' };
        axios.post(`${process.env.REACT_APP_API_BASE_URL}/download_entity_final_report`, { "entity": entityDetails.entityName }, {
            responseType: 'blob',
            headers
        })
            .then(response => {
                setLoading(false)
                if (item === "Download") {
                const element = document.createElement("a");
                element.href = URL.createObjectURL(response.data);
                element.download = `report_${entityDetails.entityName}`;
                document.body.appendChild(element);
                element.click();
                } else {
                  setFile(response.data)
                }
            })
            .catch(error => {
                setLoading(false)
                messageService.sendMessage({ variant: "danger", message: "server problem" })
            })
    }

    const onDocumentLoadSuccess = ({ numPages: nextNumPages }) => {
        setNumPages(nextNumPages);
      }
    
    useEffect(() => {
       DownloadReport("view");
    }, [])

    return (
        <div className={reportCss.verification}>
            <div className={reportCss.reports}>
            <Document file={file} onLoadSuccess={onDocumentLoadSuccess}>
            {Array.from(new Array(numPages), (el, index) => (
              <Page
                renderTextLayer={false}
                renderAnnotationLayer={false}
                customTextRenderer={false}
                key={`page_${index + 1}`}
                pageNumber={index + 1}
                width={maxWidth}
              />
            ))}
          </Document>
                {/* <Row>
                <Col md={2}></Col>
                <Col md={3}></Col>
                <Col md={1}></Col>
                <Col md={3} className={reportCss.alignCenter}>
                <Button variant="danger" className={`${reportCss.label} backgroundDanger`}>View</Button></Col>
                <Col md={3} className={reportCss.alignCenter}>
                <Button variant="danger" className={`${reportCss.label} backgroundDanger`} onClick={DownloadReport}>Download</Button></Col>
                </Row>
                <Row>
                <Col md={2}></Col>
                <Col md={3}></Col>
                <Col md={1}></Col>
                <Col md={2} className={reportCss.alignCenter}><Badge bg="success">Submit To Checker</Badge></Col>
                </Row> */}
            </div>
            {
                loading &&
                <LayoutLoading message="Fetching Data" />
            }
        </div>
    )
}

const mapStateToProp = (state) => {
    return {
        entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(KycReport)