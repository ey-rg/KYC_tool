import React, { useState } from 'react';
import { CheckerDashboard, progressIcon, completedIcon, DownloadPDF } from '../../assets/images';
import CheckerLayoutCss from './CheckerLayout.module.css'
import BasicTable from '../Utils/BasicTable';
import { Badge } from 'react-bootstrap';
import documentUploadCss from './DocumentUpload.module.css';

function CheckerDashboardLayout() {
    const initialData = [
        {entityName: 'Emergent BioSolutions UK Ltd', name: 'user1', reviewStatus: 'Not Started', assignedDate: '23 Nov 2023', kycReport: '',
        reviewResult: '', viewComment: '', completionDate: ''},
        {entityName: 'TCS', name: 'user1', reviewStatus: 'Not Started', assignedDate: '20 Nov 2023', kycReport: '',
        reviewStatus: 'In Progress', completionDate: ''},
    ];

    const [data, setData] = useState(initialData)
    const headers = [
        {
            Header:"Entity Name",
            accessor:"entityName",
            Cell:(props) => {
                return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            }
        },
        {
            Header:"Creator Name",
            accessor:"name"
        },
        {
            Header:"Review Status",
            accessor:"reviewStatus",
            Cell:(props) => {
                return (
                props.value === "In Progress"
                ? <Badge className={`${documentUploadCss.badge} backgroundDanger`} bg='danger'>{props.value}</Badge>:
                <Badge bg="secondary" className={`${documentUploadCss.badge}`}>{props.value}</Badge>
                )            
            }
        },
        {
            Header:"Assigned Date",
            accessor:"assignedDate"
        },
        {
            Header:"KYC Report",
            accessor:"kycReport",
            Cell:(props) => {
                return <img style={{width:"30px"}} src={DownloadPDF}/>
            }
        },
        {
            Header:"Review Result",
            accessor:"reviewResult"
        },
        {
            Header:"View Comment",
            accessor:"viewComment"
        },
        {
            Header:"Completion Date",
            accessor:"completionDate"
        }
    ]
    return (
        <div className={CheckerLayoutCss.pane}>
          <span style={{ display: "inline-block", margin: "20px 50px", backgroundColor: "#F17720" }}>
                        <span style={{display: "inline-block", height: "50px"}}><img src={progressIcon} alt="progress" style={{ width: "50px" }} /></span>
                        <span className={CheckerLayoutCss.statusSpan}><div style={{marginLeft: "6px"}}>In Progress</div>
                            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center" }}>1</div></span>
            </span>
            <span style={{ display: "inline-block", margin: "20px 50px", backgroundColor: "#198754" }}>
                        <span style={{display: "inline-block", height: "47px"}}><img src={completedIcon} alt="progress" style={{ width: "50px" }} /></span>
                        <span className={CheckerLayoutCss.statusSpan}><div style={{marginLeft: "6px"}}>Completed</div>
                            <div style={{ fontFamily: "var(--poppinsSemiBold)", width: "100%", textAlign: "center" }}>0</div></span>
                    </span>
            <span style={{display: "inline-block", margin: "10px 50px"}}>
               <img src={CheckerDashboard} alt="dashboard" style={{width: "280px", height: "110px"}}/>
            </span>
        <div className={CheckerLayoutCss.innerDiv}>
        <BasicTable availableColumns={headers} data={data}></BasicTable>
        </div> 
        </div>
    )
}

export default CheckerDashboardLayout