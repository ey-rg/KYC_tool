// import React from 'react';
// import MailFormCss from './MailForm.module.css';
// import { Button, Form } from 'react-bootstrap';
// import { messageService } from '../Utils/messageService';

// function MailForm() {
//   const EDDAttributeLabels = [
//     {label: "Registered Office Address", options: ["Reliance Avenue, Mumbai, India", "Office -101, Saffron Nr. Centre Point, Panchwati 5 Rasta,Ambawadi Ahmedabad - 380006 , IN"]}, 
//     {label: "List of Directors", options: ["Isha Ambani, Mukesh Ambani, Sanjay Mashruwala", "Isha Ambani, Mukesh Ambani, Sanjay Mashruwala, Shumeet Banerji"]},
//     {label: "Chairman", options: ["Dhirubai Ambani, Mukesh Ambani", "Mukesh Ambani"]}];

//   const ClickHandler = () => {
//     messageService.sendMessage({variant: "success", message: "Information has been recorded successfully."})
//   }

//   return (
//     <div className={MailFormCss.form}>
//       <div style={{textAlign: "center"}}>
//        <label style={{fontSize: "var(--fontSize)", margin:0}}>Please confirm the below Details</label>
//        </div>
//        <div>
//        {
//         EDDAttributeLabels.map(item => {
//           return(
//        <><label style={{ marginTop: "7px" }}>{item.label}:</label>
//        {
//          item.options.map(option => {
//           return(
//           <div style={{fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)"}}>
//           <Form.Check type="radio"
//           name={item.label}
//           id="normal"
//           label={option} /></div>
//           )
//          })
//        }</>
//           )
//         })
//       }
//       </div>
//         <Button variant="success" className={MailFormCss.submit} onClick={() => ClickHandler()}>Submit</Button>
//       </div>
//   )
// }

// export default MailForm



import React from 'react';
import BulkUpload from '../Utils/BulkUpload';
import MailFormCss from './MailForm.module.css';
import { Button } from 'react-bootstrap';
import { useParams } from "react-router-dom";
import { messageService } from '../Utils/messageService';

function MailForm() {
const { tab } = useParams();
const ClickHandler = () => {
     messageService.sendMessage({variant: "success", message: "Information has been recorded successfully."})
  }

  return (
    <div className={MailFormCss.form}>
    <div style={{fontFamily: "var(--poppinsSemiBold)", fontSize: "var(--fontSize)", margin: "20px", textAlign: "center"}}>
      <span style={{ display: "inline-block"}}>Missing Documents Upload Form</span>
       </div>
         <div style={{fontFamily: "var(--poppinsSemiBold)", fontSize: "var(--fontSizeMedium)", marginLeft:"20%",
        marginBottom: "20px"}}>Please upload below Document</div>
        <label>Trust Deed:</label>
        <BulkUpload />
        <Button variant="success" className={MailFormCss.submit} onClick={() => ClickHandler()}>Submit</Button>
      </div>
  )
}

export default MailForm