import React from 'react';
import CheckerLayoutCss from './CheckerLayout.module.css'
import AuditLayout from './AuditLayout';
import CheckerDashboardLayout from './CheckerDashboard';
import CustomTabsChecker from '../Utils/CustomTabsChecker';

function CheckerLayout() {
  return (
    <div className={CheckerLayoutCss.processFlow}>
           <CustomTabsChecker
            tabList={[
                {
                    title: "Task Log",
                    icon: "",
                    eventKey: "calculate",
                    getTabComponent: () => <AuditLayout/>
                },
                {
                    title: "Checker Dashboard",
                    icon: "",
                    eventKey: "bulk_calculate",
                    getTabComponent: () => <CheckerDashboardLayout/>
                }
            ]}
        />
    </div>
  )
}

export default CheckerLayout