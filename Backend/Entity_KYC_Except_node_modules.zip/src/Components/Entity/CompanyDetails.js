import React, {useEffect, useState} from 'react'
import BasicTable from '../Utils/BasicTable'
import { connect } from 'react-redux'
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import axios from 'axios';
import LayoutLoading from '../Utils/LayoutLoading';
import { messageService } from '../Utils/messageService';
import CustomModal from '../Utils/CustomModal';
import { Form, Button } from 'react-bootstrap';
import documentUploadCss from './DocumentUpload.module.css'
import { MissingattributesIcon, orgHierarchy } from '../../assets/images';
import Hierarchy from './Hierarchy';
import MissAttributes from './MissAttributes';
import { location } from '../../assets/images';
import LocationOfc from './locationOfc';

function CompanyDetails({entityDetails, showAttr}) {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedRow, setSelectedRow] = useState(null);
    const [notes, setNotes] = useState('');
    const [OrgHierachy, setOrgHierchy] = useState(false);
    const [showMissAttributes, setShowMissAttributes] = useState(false);
    const [showLocation, setShowLocation] = useState(false)
    const [locationAttr, setLocationAttr] = useState({apiKey: '', lat: "", lng: ''})

    const headers = [
        { Header:"KYC Attributes", accessor:"Detail",
          Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          }
        },
        { Header:"Previous Details", accessor:"company_database"},
        { Header:"Latest Details", accessor:"llm",
          Cell:(props) => {
            if (props.row.values.llm === 'Data not available' || props.row.values.llm === 'Data not Available') {
              return <span style={{color:"#FF3131"}}>{props.value}</span>
            }else if (props.row.values.Detail !== 'Registered Office Address') {
              return <span style={{color:"#0863f1"}}>{props.value}</span>
            }else {
              return <><span style={{color:"#0863f1"}}>{props.value}</span>
              <img style={{width:"30px"}} src={location} alt="location" onClick={() => locationHandler(props.value)}/></>
            }
          }
        },
        { Header:"Source", accessor: "source"},
        { Header:"Review Status", accessor:"matcher_li",
          Cell:(props) => {
            if (props.value === "Not Matched") {
              return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            } else if (props.value === "Matched") {
                return <span style={{color: "#6c757db3"}}>{props.value}</span>
            } else {
                return <span>{props.value}</span>
            }
          }
        },
        // { Header:"Company Database Update", accessor:"update_database",
        // Cell:(props) => {
        //     if (props.value === 'Required') {
        //        return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
        //     } else {
        //        return <span>{props.value}</span>
        //     }
        // }
        // }
    ]

    const orgHierarchyHandler = () => {
      setOrgHierchy(true);
    }

    const locationHandler = (officeAddress) => {
      setLoading(true)
      axios.post(`${process.env.REACT_APP_API_BASE_URL}/street_view`, {"location": officeAddress})
      .then(response => {
          setLoading(false)
          setShowLocation(true)
          setLocationAttr({apiKey: response.data.api_key, lat: response.data.latitude, lng: response.data.longitude})
      })
      .catch(error => {
          setLoading(false)
          messageService.sendMessage({variant: "danger", message: "server problem"})
      })  
    }

    useEffect(() => {
      if (showAttr) {
        setShowMissAttributes(showAttr)
      }
    setLoading(true)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/entity_details`, {"tab": "company_details",
    "entity": entityDetails.entityName})
    .then(response => {
        setLoading(false)
        setData(response.data.output)
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message: "server problem"})
    })
    }, [])  
    
    return (
    <>
    <img src={orgHierarchy} alt="orgHierarchy" className={documentUploadCss.hierarchy} onClick={orgHierarchyHandler}/>
    {/* <img src={MissingattributesIcon} alt="missingAttribute" style={{    width: '66px', top: '125px'}} className={documentUploadCss.attributes}/> */}
    <Button className={`${documentUploadCss.attributes} backgroundDanger`} variant='danger' 
    onClick={() => setShowMissAttributes(true)}>Missing Attributes</Button>
    <div>
    <BasicTable availableColumns={headers} data={data} setSelectedData={setSelectedRow}
    tableDivExtraStyle={{
      height: "400px"
  }}></BasicTable>
    </div>
    {
        loading &&
        <LayoutLoading message="Loading"/>
    }
    {
      selectedRow !== null &&
      <CustomModal onHideHandler={() => setSelectedRow(null)}
            modalHeader={selectedRow.Detail}>
            <Form.Control as="textarea"
            name="inputText"
            style={{resize:"None", height:"150px"}}
            required
            className={documentUploadCss.notes}
            value={notes}/>
            <Button variant="success" className={documentUploadCss.upload}>Save</Button>     
        </CustomModal>
    }
  {
    OrgHierachy &&
    <CustomModal onHideHandler={() => setOrgHierchy(false)} modalHeader="Organisation Hierarchy" fullscreen={true}>
     <Hierarchy tab="organization_hierarchy"/>
    </CustomModal>
  }
  {
    showMissAttributes &&
    <CustomModal onHideHandler={() => setShowMissAttributes(false)} modalHeader='Missing Attributes'>
     <MissAttributes />
    </CustomModal>
  }
  {
    showLocation &&
    <CustomModal onHideHandler={() => setShowLocation(false)} modalHeader='Location' size="xl">
     <LocationOfc locationAttr={locationAttr}/>
    </CustomModal>
  }
    </>
   )
}

const mapStateToProp = (state) => {
    return {
      entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(CompanyDetails)
