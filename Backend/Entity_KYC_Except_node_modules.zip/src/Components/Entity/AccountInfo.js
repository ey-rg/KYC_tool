import React, { useState, useEffect } from 'react'
import axios from 'axios'
import BasicTable from '../Utils/BasicTable'
import { messageService } from '../Utils/messageService';
import LayoutLoading from '../Utils/LayoutLoading';
import CustomModal from '../Utils/CustomModal';
import { Form, Button } from 'react-bootstrap';
import { AutoEmail } from '../../assets/images';
import { connect } from 'react-redux';
import documentUploadCss from './DocumentUpload.module.css'
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import { useNavigate } from 'react-router-dom';

function AccountInfo({ entityDetails }) {
    const navigate = useNavigate();
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedRow, setSelectedRow] = useState(null);
    const [notes, setNotes] = useState('');

    const headers = [
        { Header:"KYC Attributes", accessor:"Detail",
          Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          }
        },
        { Header:"Company Database", accessor:"company_database",
        Cell: (props) => {
            const splitArray = props.value.split(',')
                  return (
                    <span>
                    {
                      splitArray.map(element => (
                        <div>{element}</div>
                      ))
                    }
                    </span>
                  )
          }
        },
        // { Header:"Gen AI Output", accessor:"llm",
        //   Cell:(props) => {
        //     const splitArray = props.value.split(',')
        //     return (
        //       <span>
        //       {
        //         splitArray.map(element => (
        //           <div style={{color:"#0863f1"}}>{element}</div>
        //         ))
        //       }
        //       </span>
        //     )
        //   }
        // },
        // { Header: "Source", accessor: "source"},
        { Header:"Information From Client", accessor:"information_from_client",
          Cell: (props) => {
            const splitArray = props.value.split(',')
                  return (
                    <span>
                    {
                      splitArray.map(element => (
                        <div>{element}</div>
                      ))
                    }
                    </span>
                  )
          }
        },
        { Header:"Confirmation From Client", accessor:"confirmation"},
        // { Header:"Client Remarks", accessor:"ClientReply",
        // Cell:(props) => {
        //     if (props.value === 'Required') {
        //        return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
        //     } else {
        //        return <span>{props.value}</span>
        //     }
        // }
        // },
        { Header:"Database Update", accessor:"update_database",
        Cell:(props) => {
            if (props.value === 'Required') {
               return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            } else {
               return <span>{props.value}</span>
            }
        }
        }
    ]

    useEffect(() => {
    setLoading(true)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/entity_details`, {"tab": "fund_account_details",
    "entity": entityDetails.entityName})
    .then(response => {
        setLoading(false)
        setData(response.data.output)
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message: "Server Problem"})
    })
    }, [])  
    
    const sendMailHandler = () => {
      setLoading(true)
      const mailReqBody = {
          subject: "EDD Confirmation",
          recipients: [
              "ramya.m3@in.ey.com"
          ],
          body: "Hi Ramya, \n\n I trust this email finds you well. \n We appreciate your cooperation in completing the KYC process with Reliance. As part of our commitment to maintaining a secure and compliant environment, we are currently in the final stages of the Enhanced Due Diligence (EDD) process.\n To ensure the swift completion of your KYC requirements, we kindly request your prompt confirmation on the details mentioned in the form: http://localhost:3000/#/mailForm/Documents . \n\nRegards, \nAdmin"
      }
      axios.post(`${process.env.REACT_APP_API_BASE_URL}/send_mail`, mailReqBody)
      .then(response => {
          setLoading(false)
          messageService.sendMessage({variant: "success", message: "Mail has been Sent Successfully."})
      })
      .catch(error => {
          setLoading(false)
          messageService.sendMessage({variant: "danger", message: "server error"});
      }) 
    }

    return (
    <>
    <div>
    <BasicTable availableColumns={headers} data={data} setSelectedData={setSelectedRow}
    tableDivExtraStyle={{
        height: "320px"
    }}></BasicTable>
    <img src={AutoEmail} alt="AutoEmail" style={{width: "36px", marginRight: "4px"}}/>
    <Button className={`${documentUploadCss.documentList} backgroundDanger`} variant="primary" 
    onClick={() => {sendMailHandler()}}>Auto Email to Client</Button>
    </div>
    {
        loading &&
        <LayoutLoading message="Loading"/>
    }
    {
      selectedRow !== null &&
      <CustomModal onHideHandler={() => setSelectedRow(null)}
            modalHeader={selectedRow.Detail}>
            <Form.Control as="textarea"
            name="inputText"
            style={{resize:"None", height:"150px"}}
            required
            className={documentUploadCss.notes}
            value={notes}/>
            <Button variant="success" className={documentUploadCss.upload}>Save</Button>     
        </CustomModal>
    }
    </>
   )
}

const mapStateToProp = (state) => {
    return {
      entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(AccountInfo)