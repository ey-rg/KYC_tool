import React, { useEffect, useState } from 'react'
import Select from 'react-select';
import documentUploadCss from './DocumentUpload.module.css'
import guidelinesCss from './KYCGuidelines.module.css'
import { Row, Col } from 'react-bootstrap';
import CustomTextControl from './../Utils/CustomTextControl'
import axios from 'axios';
import LayoutLoading from './../Utils/LayoutLoading'
import { messageService } from '../Utils/messageService';
import CustomModal from '../Utils/CustomModal';

function KYCGuidelines() {
    const [showReferences, setShowReferences] = useState(false)
    const [loading, setLoading] = useState(false);
    const [summary, setSummary] = useState('');

    useEffect(() => {
        setLoading(true)
        axios.get(`${process.env.REACT_APP_API_BASE_URL}/judication_summary`)
        .then(response => {
            setSummary(response.data.output)
            setLoading(false)
        })
        .catch(error => {
            setLoading(false)
            messageService.sendMessage({variant: "danger", message: "Server Problem"})
        })
    }, [])

    const ReferenceHandler = () => {
      setShowReferences(true)
    }

    return (
        <>
            <div className={documentUploadCss.dropdown}>
                <a onClick={ReferenceHandler} className={guidelinesCss.links}>References</a>
            </div>
            <Row className={guidelinesCss.innerDiv}>
                <Col md={12}>
                <div className={guidelinesCss.backgroundColor}>
                <label>Summary</label>
                </div>
            <CustomTextControl
                required={true}
                name="inputText"
                value={summary} />
                </Col>
            </Row>
            {
                loading &&
                <LayoutLoading message="Generating Summary"/>
            }
            {
                showReferences &&
                <CustomModal onHideHandler={() => setShowReferences(false)}
                modalHeader='References' className="headerWidth">
                 <ul className={guidelinesCss.referenceLinks}>
                    <li><a href="#">KYC Jurisdiction Document</a></li>
                    <li><a href="#">KYC Form</a></li>
                 </ul>
                </CustomModal>
            }
        </>
    )
}

export default KYCGuidelines