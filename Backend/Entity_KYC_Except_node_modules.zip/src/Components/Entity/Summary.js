import React from 'react'
import CustomTabs from '../Utils/CustomTabs'
import KYCSummary from './KycSummary'
import UpdateAttributes from './UpdateAttributes'
import { AttributesIcon, SummaryIcon } from '../../assets/images'

function Summary() {
    return (
        <KYCSummary/>
        // <CustomTabs
        //     tabList={[
        //         {
        //             title: "KYC Summary",
        //             icon: SummaryIcon,
        //             eventKey: "Screening",
        //             getTabComponent: () => <KYCSummary/>
        //         },
        //         {
        //             title: "Update Attributes",
        //             icon: AttributesIcon,
        //             eventKey: "Update Attributes",
        //             getTabComponent: () => <UpdateAttributes/>
        //         }
        //     ]}
        // />
    )
}

export default Summary