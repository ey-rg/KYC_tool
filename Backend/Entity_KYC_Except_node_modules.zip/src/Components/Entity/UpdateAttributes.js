import React, { useState, useEffect } from 'react'
import LayoutLoading from './../Utils/LayoutLoading'
import { messageService } from '../Utils/messageService'
import axios from 'axios'
import { selectEntityDetails } from '../../redux/entityDetails/selector'
import { connect } from 'react-redux'
import {Row, Col} from 'react-bootstrap'
import KycSummaryCss from './KycSummary.module.css'
import BasicTable from '../Utils/BasicTable'
import documentUploadCss from './DocumentUpload.module.css'
import { Button } from 'react-bootstrap'
import { AutoEmail, adhar_combined, pan_card, electricity_bill, verified} from '../../assets/images'; 


function UpdateAttributes({ entityDetails }) {
  const [loading, setLoading] = useState(false);
  const [attributes, setAttributes] = useState([]);

  // === Individual KYC update ===
  const getDocumentImage = (detailName) => {
    if (detailName.toLowerCase().includes('adhar')) {
      return adhar_combined;
    } else if (detailName.toLowerCase().includes('pan')) {
      return pan_card;
    }
    return null; 
  };
  // === Individual KYC update ended ===


  const headers = [
    {
      Header: "Detail", accessor: "detail",
      Cell: (props) => {
        return <span style={{ fontFamily: "var(--poppinsSemiBold)" }}>{props.value}</span>
      }
    },
    { Header: "Previous Details", accessor: "previous_value" },
    { Header: "Latest Details", accessor: "recent_value" }
  ]

  useEffect(() => {
    setLoading(true)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/entity_details`, { tab: 'update_attributes', entity: entityDetails.entityName })
      .then(response => {
        setAttributes(response.data.output)
        setLoading(false)
      })
      .catch(error => {
        setLoading(false)
        messageService.sendMessage({ variant: "danger", message: "server problem" })
      })
  }, [])

  const saveHandler = () => {
    //messageService.sendMessage({variant: 'success', message: "Attributes has been updated in the database successfully"});
    const mailReqBody = {
      subject: "Attributes Confirmation",
      recipients: [
        "ramya.m3@in.ey.com"
      ],
      body: "Hi Ramya, \n\n Trust this email finds you well. \n We appreciate your cooperation in completing the KYC process with Reliance. As part of our commitment to maintaining a secure and compliant environment, we are currently in the final stages of the Enhanced Due Diligence (EDD) process.\n To ensure the swift completion of your KYC requirements, we kindly request your prompt confirmation on the details mentioned in the form: http://localhost:3000/#/mailForm/Documents . \n\nRegards, \nAdmin"
    }
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/send_mail`, mailReqBody)
      .then(response => {
        setLoading(false)
        messageService.sendMessage({ variant: "success", message: "Mail has been Sent Successfully." })
      })
      .catch(error => {
        setLoading(false)
        messageService.sendMessage({ variant: "danger", message: "server error" });
      })
  }
  return (
    <>

        {
            attributes.map(item => {

              const currentImageSrc = getDocumentImage(item.detail); /*Updated for Individual KYC update */

              return (
              <Row style={{width: "650px", margin:"2px"}}>
                <Col md={4}>

                <span style={{fontFamily: "var(--poppinsSemiBold)", fontSize: "var(--fontSizeSmall)"}}>{item.detail}</span>
                </Col>
                <Col md={8}>
                <span style={{fontFamily: "var(--poppinsRegular)", fontSize: "Var(--fontSizeSmall)"}}>{item.recent_value}</span>
                </Col></Row>
              )
          })
        }
      {/* <BasicTable availableColumns={headers} data={attributes} tableDivExtraStyle={{
        height: "200px"
    }}></BasicTable> */}
      {/* <div style={{marginTop: "40px", marginLeft: "20px"}}>
       <img src={AutoEmail} alt="AutoEmail" style={{width: "36px", marginRight: "4px"}}/>
        <Button variant="danger" className={`${documentUploadCss.documentList} backgroundDanger`} 
        onClick={saveHandler}> Auto Email to RM</Button>
        </div> */}
      {
        loading &&
        <LayoutLoading message="Generating Summary" />
      }
    </>
  )
}

const mapStateToProp = (state) => {
  return {
    entityDetails: selectEntityDetails(state)
  }
}

export default connect(mapStateToProp, null)(UpdateAttributes)