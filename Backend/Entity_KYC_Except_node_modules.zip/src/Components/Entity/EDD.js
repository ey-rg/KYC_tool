import React from 'react'
import CustomTabs from './../Utils/CustomTabs'
import AccountInfo from './AccountInfo'
import IndividualCDD from './IndividualCDD'
import EDDSummary from './EDD Summary'
import { AccountIcon,IndividualCDDIcon, EDDSummaryIcon} from '../../assets/images'

function EDD() {
  return (
    <CustomTabs
    tabList={[
        {
            title: "Fund/Account Information",
            icon: AccountIcon,
            eventKey: "Fund Info",
            getTabComponent: () => <AccountInfo/>
        },
        {
            title: "Individual CDD",
            icon: IndividualCDDIcon,
            eventKey: "Individual CDD",
            getTabComponent: () => <IndividualCDD/>
        },
        {
            title: "EDD Summary",
            icon: EDDSummaryIcon,
            eventKey: "EDD summary",
            getTabComponent: () => <EDDSummary/>
        }
    ]}
  />
  )
}

export default EDD