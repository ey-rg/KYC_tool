import React, {useEffect, useState} from 'react'
import BasicTable from '../Utils/BasicTable'
import { connect } from 'react-redux'
import { selectEntityDetails } from '../../redux/entityDetails/selector';
import axios from 'axios';
import LayoutLoading from '../Utils/LayoutLoading';
import { messageService } from '../Utils/messageService';
import documentUploadCss from './DocumentUpload.module.css'
import CustomModal from '../Utils/CustomModal';
import { Form, Button } from 'react-bootstrap';
import { AutoEmail } from '../../assets/images';

function MissingAttributes({entityDetails}) {
    const [data, setData] = useState([]);
    const [loading, setLoading] = useState(false);
    const [selectedRow, setSelectedRow] = useState(null);
    const [notes, setNotes] = useState('');

    const headers = [
        { Header:"KYC Attributes", accessor:"Detail",
          Cell:(props) => {
            return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
          }
        },
        { Header:"Company Database", accessor:"company_database"},
        { Header:"Gen AI Output", accessor:"llm",
          Cell:(props) => {
            return <span style={{color:"#0863f1"}}>{props.value}</span>
          }
        },
        { Header:"Client Confirmation", accessor:"matcher_li",
          Cell:(props) => {
            if (props.value === "Not Matched") {
              return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            } else if (props.value === "Matched") {
                return <span style={{color: "#6c757db3"}}>{props.value}</span>
            } else {
                return <span>{props.value}</span>
            }
          }
        },
        { Header:"Information from Client", accessor:"update_database",
        Cell:(props) => {
            if (props.value === 'Required') {
               return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            } else {
               return <span>{props.value}</span>
            }
        }
        },
        { Header:"Update Database", accessor:"update_database1",
        Cell:(props) => {
            if (props.value === 'Required') {
               return <span style={{fontFamily: "var(--poppinsSemiBold)"}}>{props.value}</span>
            } else {
               return <span>{props.value}</span>
            }
        }
        }
    ]

    useEffect(() => {
    setLoading(true)
    axios.post(`${process.env.REACT_APP_API_BASE_URL}/entity_details`, {"tab": "missing_attributes",
    "entity": entityDetails.entityName})
    .then(response => {
        setLoading(false)
        setData(response.data.output)
    })
    .catch(error => {
        setLoading(false)
        messageService.sendMessage({variant: "danger", message: "Server Problem"})
    })
    }, [])  
    
    return (
    <>
    <div>
    <BasicTable availableColumns={headers} data={data} setSelectedData={setSelectedRow}
      tableDivExtraStyle={{
        height: "250px"
    }}></BasicTable>
    <img src={AutoEmail} alt="AutoEmail" style={{width: "36px", marginRight: "4px"}}/>
    <Button className={`${documentUploadCss.documentList} backgroundDangerDisable`} variant="primary">Auto Email to Client</Button>
    </div>
    {
        loading &&
        <LayoutLoading message="Loading"/>
    }
    {
      selectedRow !== null &&
      <CustomModal onHideHandler={() => setSelectedRow(null)}
            modalHeader={selectedRow.Detail}>
            <Form.Control as="textarea"
            name="inputText"
            style={{resize:"None", height:"150px"}}
            required
            className={documentUploadCss.notes}
            value={notes}/>
            <Button variant="success" className={documentUploadCss.upload}>Save</Button>     
        </CustomModal>
    }
    </>
   )
}

const mapStateToProp = (state) => {
    return {
      entityDetails: selectEntityDetails(state)
    }
}

export default connect(mapStateToProp, null)(MissingAttributes)