import React from 'react'
import documentUploadCss from './DocumentUpload.module.css'
import { Button } from 'react-bootstrap';

function MissAttributes() {
    return (
    <>
        {/* <div style={{ fontFamily: "var(--poppinsRegular)", fontSize: "var(--fontSizeSmall)", marginBottom:"15px" }}>There are no missing Attributes</div> */}
        <ul>
            <li>Foreign Tax Identification Number</li>
            <li>Engaged in Economic Sanctions</li>
            <li>US Tax Identification Number</li>
        </ul>
        <Button variant="primary" className={`${documentUploadCss.documentList} backgroundDangerDisable`}>
            Request Information</Button>
    </>
    )
}

export default MissAttributes