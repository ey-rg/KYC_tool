import React from 'react'
import { Tab, Tabs } from 'react-bootstrap'
import CustomTabCss from './CustomTabsChecker.module.css';
import PropTypes from 'prop-types';
function CustomTabsChecker({
    tabList=[]
    }) {
    const renderTitle = (icon, title ) => {
        return (
            <div style={{backgroundColor: "#006EB3"}}>
                {
                    icon &&
                    <img src={icon} alt={title} style={{width:'30px', marginRight: "5px"}}/>
                }
            <span style={{padding: "7px 15px", marginTop: "2px", display: "inline-block"}}>{title}</span>
            </div>
        )

    }
    return tabList.length>0 ?
        <div>
        <Tabs
            defaultActiveKey={tabList[0].eventKey}
            transition={false}
            className={CustomTabCss.tabUl}
            mountOnEnter={true}
            variant='pill'
        >
            {
                tabList.map((item,itemIndex)=>(
                    <Tab
                        key={itemIndex}
                        tabClassName={CustomTabCss.tabCls}
                        eventKey={item.eventKey}
                        title={renderTitle(item.icon, item.title)}>
                        {item.getTabComponent()}
                    </Tab>
                ))
            }
        </Tabs ></div>:""
}


CustomTabsChecker.propTypes={
    tabList:PropTypes.arrayOf(
        PropTypes.shape({
            title:PropTypes.string,
            icon:PropTypes.string,
            eventKey:PropTypes.string,
            getTabComponent:PropTypes.func
        })
    )
}
export default CustomTabsChecker