import React, { useMemo } from 'react';
import { useTable, usePagination, useGlobalFilter } from 'react-table';
import BasicTableBody from './BasicTableBody';
import BlankTable from './BlankTable';

function BasicTable({
    data,
    availableColumns,
    tableDivExtraStyle = {},
    setSelectedData,
    isCommentIconVisible,
    noItemText = "No Record Found"
}) {
    const tableColumns = useMemo(() => availableColumns, [availableColumns])
    const tableData = useMemo(() => data, [data])
    const tableInstance = useTable({
        columns: tableColumns,
        data: tableData,
        initialState: { pageIndex: 0, pageSize: 50 },
        autoResetPage: false,
        autoResetGlobalFilter: false,
        autoResetFilters: false
    }, useGlobalFilter, usePagination)



    return (
        <React.Fragment> 
            {
                data.length > 0 ?
                    <React.Fragment>
                        <BasicTableBody
                            tableDivExtraStyle={tableDivExtraStyle}
                            tableInstance={tableInstance}
                            setSelectedData={setSelectedData}
                            isCommentIconVisible={isCommentIconVisible}/>
                    </React.Fragment> :
                    <BlankTable message={noItemText} />
            }
        </React.Fragment>
    )
}

export default BasicTable
