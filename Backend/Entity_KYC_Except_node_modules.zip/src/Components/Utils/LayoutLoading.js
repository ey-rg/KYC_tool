import React from 'react'
import { Spinner,Modal } from 'react-bootstrap'
import ReactDOM from 'react-dom'
import LayoutLoadingCss from './LayoutLoading.module.css'
function LayoutLoading({message=""}) {
    return ReactDOM.createPortal(
        
        <Modal
        show={true}
        size="md"
        
        aria-labelledby="contained-modal-title-vcenter"
        variant="dark"
        backdropClassName={LayoutLoadingCss.customModalBackdrop}
        contentClassName={LayoutLoadingCss.customModalContent}
        centered
        >
            

            <Spinner animation="border" variant='warning' className={LayoutLoadingCss.spinnerCustom}>

            </Spinner>            <span
                className={LayoutLoadingCss.spinnerCustomText}
            >{message} ...</span>

            
           
        </Modal>,
        document.getElementById("portal-root")
    )
}

export default LayoutLoading
