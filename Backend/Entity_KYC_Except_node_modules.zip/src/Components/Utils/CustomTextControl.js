import React from 'react'
import {Form } from 'react-bootstrap'
import CustomTextControlCss from './CustomTextControl.module.css';

function CustomTextControl({
    className,
    name,
    maxLength,
    required,
    disabled,
    value,
    onChange
    }) {
    const textControlRef = React.createRef();
    const onChangeHandler = (e)=>{
        onChange(e);
      
    }

    return (
        <Form.Control as="textarea"
            ref={textControlRef}
            className = {CustomTextControlCss.textareaCustom}
            name={name}
            rows={4}
            style={{resize:"None", height:"250px"}}
            maxLength={maxLength}
            required = {required}
            disabled={disabled}
            value={value}
            onChange={onChangeHandler}/>
    )
}

export default CustomTextControl