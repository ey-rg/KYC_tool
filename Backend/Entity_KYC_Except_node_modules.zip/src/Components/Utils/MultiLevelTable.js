import React, { useMemo } from 'react';
import { useTable, usePagination, useGlobalFilter } from 'react-table';
import BasicTableBody from './BasicTableBody';
import BlankTable from './BlankTable';
import BasicTableCss from './BasicTable.module.css'
import { Table } from 'react-bootstrap'
import MultiLevelTableCss from './MultiLevel.module.css'

function MultiLevelTable({
    data,
    columns,
    tableDivExtraStyle = {},
    setSelectedData,
    isCommentIconVisible,
    noItemText = "No Record Found"
}) {
    const tableColumns = useMemo(() => columns, [columns])
    const tableData = useMemo(() => data, [data])
    const tableInstance = useTable({
        columns: tableColumns,
        data: tableData,
        initialState: { pageIndex: 0, pageSize: 50 },
        autoResetPage: false,
        autoResetGlobalFilter: false,
        autoResetFilters: false
    }, useGlobalFilter, usePagination)

    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        prepareRow,
        page,
        rows
    } = tableInstance


    return (
        <React.Fragment> 
            {
                columns.length > 0 ?
                    <React.Fragment>
                        <div
            className={MultiLevelTableCss.tableDiv}
            style={tableDivExtraStyle}
        >
                        <Table {...getTableProps()} size="sm"  striped
                         className={`table ${MultiLevelTableCss.customTable}`} style={{borderCollapse: "separate"}}>
                            <thead>
                                {headerGroups.map(headerGroup => (
                                <tr {...headerGroup.getHeaderGroupProps()}>
                                    {headerGroup.headers.map(column => (
                                    <th {...column.getHeaderProps()}>{column.render('Header')}</th>
                                    ))}
                                </tr>
                                ))}
                            </thead>
                            <tbody {...getTableBodyProps()}>
                                {rows.map(row => {
                                prepareRow(row);
                                return (
                                    <tr {...row.getRowProps()}>
                                    {row.cells.map(cell => (
                                        <td {...cell.getCellProps()}>{cell.render('Cell')}</td>
                                    ))}
                                    </tr>
                                );
                                })}
                            </tbody>
                        </Table>
                        </div>
                    </React.Fragment> :
                    <BlankTable message={noItemText} />
            }
        </React.Fragment>
    )
}

export default MultiLevelTable
