import React from 'react'
import { Table } from 'react-bootstrap'
import { commentIcon } from '../../assets/images'
import BasicTableCss from './BasicTable.module.css'
function BasicTableBody({
    tableDivExtraStyle,
    setSelectedData,
    tableInstance,
    isCommentIconVisible
    }) {
    const {
        getTableProps,
        getTableBodyProps,
        headerGroups,
        prepareRow,
        page
    } = tableInstance
    return (
        <div
            className={BasicTableCss.tableDiv}
            style={tableDivExtraStyle}
        >
            <Table {...getTableProps()} size="sm" borderless  
                className={`table ${BasicTableCss.customTable}`} >
                <thead>
                    {
                        headerGroups.map(headerGroup => (
                            <tr {...headerGroup.getHeaderGroupProps()}>
                                {
                                    headerGroup.headers.map(column => (
                                        <th {...column.getHeaderProps()}>
                                            {column.render('Header')}
                                        </th>
                                    ))
                                }
                                { isCommentIconVisible &&
                                  <th>External Review</th>
                                }
                            </tr>
                        ))
                    }
                </thead>
                <tbody {...getTableBodyProps()}>
                    {
                           tableInstance.rows.length < 1 ?
                           <tr>
                               <td colSpan={headerGroups[0].headers.length + 1}
                                   className={BasicTableCss.noDataTD}>
                                   No Record Found
                               </td>
                           </tr> :
                        page.map((row, index) => {
                            prepareRow(row)
                            return (
                                <tr {...row.getRowProps()} key={index}>
                                    {
                                        row.cells.map((cell, index) => {
                                            return (
                                                <td {...cell.getCellProps()}>
                                                    {
                                                        cell.render('Cell')}
                                                </td>
                                            )
                                        })
                                    }
                                    {
                                        isCommentIconVisible &&
                                        <td className={BasicTableCss.editCell}>
                                            <img src={commentIcon}
                                                alt="comment"
                                                onClick={() => setSelectedData(row.original)} />
                                        </td>
                                    }
                                </tr>
                            )
                        }
                        )}
                </tbody>
            </Table>
        </div>
    )
}

export default BasicTableBody