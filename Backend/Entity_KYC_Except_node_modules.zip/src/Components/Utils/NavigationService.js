import { Subject } from 'rxjs';

const NavigationSubject = new Subject();

export const navigationService = {
  sendMessage: message => NavigationSubject.next(message),
  clearMessages: () => NavigationSubject.next(),
  getMessage: () => NavigationSubject.asObservable()
};