import axios from 'axios'
import React, { useState } from 'react'
import { Button, Form,InputGroup } from 'react-bootstrap'
import CustomAlert from '../CustomAlert'
import BulkUploadCss from './BulkUpload.module.css'
import LayoutLoading from './LayoutLoading'

function BulkUpload({ setData,formClsExtra }) {
    const fileFieldRef = React.createRef()
    const [loading,setLoading] = useState(false)
    const [alertMsg, setAlertMsg] = useState("")
    const [file, setFile] = useState(null)
    const fileChangeHandler = (e) => {
        let file = e.target.files[0]
        setFile(file)
        let formData = new FormData()
        formData.append("file", file)
        let loadingTimeout = setTimeout(()=>setLoading(true),1000);
            axios.post(
                `${process.env.REACT_APP_API_BASE_URL}/upload_records`,
                formData,
            )
                .then(response => {
                    setData(response.data)              
                })
                .catch(error => {
                    setAlertMsg("Some error from server side")
                })
                .finally(()=>{
                    clearTimeout(loadingTimeout)
                    setLoading(false)
                })
    }

    return (
        <React.Fragment>
           
            <Form className={BulkUploadCss.form}>
                <Form.Group controlId="formFile">
                    <Form.Group >
                        <input type="file"
                            hidden={true}   
                            onChange={fileChangeHandler}
                            ref={fileFieldRef}
                            accept="image/jpg, image/jpeg"
                        />
                        <InputGroup className={BulkUploadCss.fileGroup} size="sm">
                            <Form.Control
                                aria-label="Example text with button addon"
                                aria-describedby="basic-addon1"
                                disabled
                                value={file ? file.name : ""}
                                title={file ? file.name : ""}
                                placeholder='No file choosen...'
                            />
                            <Button variant="dark" 
                            disabled={loading}
                            onClick={() => {
                                fileFieldRef.current.value=null
                                fileFieldRef.current.click()
                            }}>
                                Upload File
                            </Button>
                        </InputGroup>
                    </Form.Group>
                </Form.Group>
            </Form>
            {
                alertMsg !== "" &&
                <CustomAlert message={alertMsg} hideHandler={() => {
                    setAlertMsg("")
                }} />
            }
            {
                loading &&
                <LayoutLoading message="Uploading file data"/>
            }
        </React.Fragment>
    )
}

export default BulkUpload