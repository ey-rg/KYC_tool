import React from 'react'
import { Tab, Tabs } from 'react-bootstrap'
import CustomTabCss from './CustomTabs.module.css';
import PropTypes from 'prop-types';
function CustomTabs({
    tabList=[], key
    }) {
    const renderTitle = (icon, title ) => {
        return (
            <div>
                {
                    icon &&
                    <img src={icon} alt={title} style={{width:'30px', marginRight: "5px"}}/>
                }
            <span style={{backgroundColor: "#006EB3", padding: "7px 15px", marginTop: "2px", display: "inline-block"}}>{title}</span>
            </div>
        )

    }
    return tabList.length>0 ?
        <div>
        <Tabs
            defaultActiveKey={key ? key : tabList[0].eventKey}
            transition={false}
            className={CustomTabCss.tabUl}
            mountOnEnter={true}
            variant='pill'
        >
            {
                tabList.map((item,itemIndex)=>(
                    <Tab
                        key={itemIndex}
                        tabClassName={CustomTabCss.tabCls}
                        eventKey={item.eventKey}
                        title={renderTitle(item.icon, item.title)}>
                        {item.getTabComponent()}
                    </Tab>
                ))
            }
        </Tabs ></div>:""
}


CustomTabs.propTypes={
    tabList:PropTypes.arrayOf(
        PropTypes.shape({
            title:PropTypes.string,
            icon:PropTypes.string,
            eventKey:PropTypes.string,
            getTabComponent:PropTypes.func
        })
    )
}
export default CustomTabs