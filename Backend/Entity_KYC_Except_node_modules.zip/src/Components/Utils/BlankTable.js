import React from 'react'
import { Table } from 'react-bootstrap'
import BasicTableCss from './BasicTable.module.css'
function BlankTable({message="",extraStyle=undefined}) {

    return (
        <div style={extraStyle?extraStyle:{}}>
        <Table className={BasicTableCss.blankTable} borderless>
            <thead>
                <tr>
                  <th></th>
                  <th></th>
                  <th></th>
                  <th></th>
                    
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colSpan={4} style={{
                        fontFamily:"var(--poppinsSemiBold)",
                        fontSize:"var(--fontSizeMedium)",
                        padding:"40px"
                    
                        }}>
                        {
                            message!==""?
                            message:
                            "No Records Found"
                        }
                        
                    </td>
                </tr>
            </tbody>
        </Table>
        </div>
    )
}

export default BlankTable
