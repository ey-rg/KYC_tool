import React from 'react';
import { Chart as ChartJS, ArcElement, Tooltip, Legend } from 'chart.js';
import { Pie } from 'react-chartjs-2';

ChartJS.register(ArcElement, Tooltip, Legend);

function PieChart({
    chartData
}) {

    const data = {
        labels: chartData.labels.map(item=>item.toUpperCase()),
        datasets: [
            {
                label: chartData.labels,
                data: chartData.values,
                backgroundColor: [
                    '#198754',
                    '#006EB3',
                    '#d0e5fa',
                    '#C36721'
                ],
                borderColor: [
                    '#198754',
                    '#006EB3',
                    '#d0e5fa',
                    '#C36721'
                ],
                borderWidth: 2
            },
        ]
    };
    return (
        <div style={{width:"180px", height: "180px"}}>
            <Pie data={data}
                options={
                    {
                        responsive: true,
                        maintainAspectRatio: true,
                        layout: {
                            padding: 14
                          },
                        plugins: {
                            title: {
                                display: false,
                                text: chartData.title,
                            },
                            legend: {
                                display: false
                            },
                            tooltip: {
                                enabled: false
                              },
                            datalabels: {
                                anchor:"middle",
                                borderColor: 'white',
                                borderRadius: 100,
                                color: 'white',
                                textAlign:"center",
                                font: {
                                    weight: 'bold',
                                    size: "8px"
                                },
                                padding: 5,
                                formatter: function (value, context) {
                                    if (value !== 0) {
                                        return [context.chart.data.labels[context.dataIndex]];
                                    }
                                    return null
                                }
                            }
                        }
                    }
                } />
        </div>
    )
}

export default PieChart
