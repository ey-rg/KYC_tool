import React from 'react'
import ReactDOM from 'react-dom';
import { Modal } from 'react-bootstrap';
import CustomModalCss from './CustomModal.module.css';

function CustomModal({onHideHandler,noWhiteBackground=true,
  modalHeader="",children,size="md",fullscreen=false}) {
    return ReactDOM.createPortal(
        <Modal
            show={true}
            dialogClassName={CustomModalCss.modalClass}
            size={size}
            aria-labelledby="contained-modal-title-vcenter"
            fullscreen={fullscreen}
            variant="primary"
            onHide={onHideHandler}
            centered
            style={{border:"none"}}
        >
          {
            modalHeader!=="" &&
            <Modal.Header 
              className={
                onHideHandler!==undefined?
                CustomModalCss.modalHeaderCls:
                CustomModalCss.modalHeaderClsSmall} 
          
              closeButton={onHideHandler!==undefined?true:false}>  
              {
                onHideHandler!==undefined?
                modalHeader:
                <div className={CustomModalCss.modalHeaderInner}>
                  {modalHeader}
                </div>
              }

              
            </Modal.Header>
          }


          <Modal.Body 
          
          className={onHideHandler===undefined?
					CustomModalCss.modalBodyCls:
					CustomModalCss.modalBodyClsAlt}
					
					style={noWhiteBackground?{}:{padding:"0px !important"}}>
               {children} 
          </Modal.Body>

        </Modal>,
        document.getElementById("portal-root")
      );
}

export default CustomModal
