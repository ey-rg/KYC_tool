import React, {useEffect} from 'react'
import ReactDOM from 'react-dom';
import { Modal,Button } from 'react-bootstrap';
import CustomAlertCss from './CustomAlert.module.css';

function CustomAlert({hideHandler,message=""}) {
  const [domReady, setDomReady] = React.useState(false)
 
  useEffect(() => {
    setDomReady(true)
  }, [])

    return domReady 
    ? ReactDOM.createPortal(
        <Modal
            show={true}
            size="md"
            aria-labelledby="contained-modal-title-vcenter"
            variant="primary"
            centered
        >

          <Modal.Body>
               <div className={CustomAlertCss.alertMessageDiv}>
                   {
                       message!==""?
                       message:
                       "No Message !!!"
                   }
               </div>
               <div className={CustomAlertCss.alertCloseDiv}>
                   <Button variant="warning" onClick={hideHandler} 
                   className={`customBtnAlt ${CustomAlertCss.alertCloseBtn}`}
                    >OK</Button>
               </div>
          </Modal.Body>
        
        </Modal>,
        document.getElementById("portal-root")
      ): null;
}

export default CustomAlert
