# Getting Started with Create React App
If you are running the app for the first time in your system locate to desired app
--(e.g. EntityKYC_Frontend - for entity KYC functionality
-- ReKYC_Frontend - for re-KYC functionality)

> "cd "c:\\Users\<...>\KYC_Tool_Sharable\EntityKYC_Fronted"

Once above comand is execute successfully run below command in the terminal
> npm start

If your app shows errors related to
1.Fix the critical issues (browserslist + missing Babel plugin)?
Then run below commands in terminal
    > npx update-browserslist-db@latest
    > npm install --save-dev @babel/plugin-proposal-private-property-in-object

 It installs "caniuse latest version" and the @babel/plugin-proposal-private-property-in-object package as a dev dependency to your project.
 The command breaks down as:
'''Python
npm install - the install command
--save-dev - saves it to devDependencies in package.json
@babel/plugin-proposal-private-property-in-object - the package name
'''

1. Install the recommended Babel package (the deprecation warning suggests using the newer one):
> npm install --save-dev @babel/plugin-transform-private-property-in-object
2. Fix the vulnerabilities (optional but recommended):
npm audit fix
3. Fix the ESLint warnings in your code files automatically
4. Run npm start again to test the application



**Step 1: Start the Frontend (EntityKYC_Frontend)**
Open a terminal
Run these commands:
    > cd "c:\Users\ZH168VY\OneDrive - EY\2026\KYC_Tool_Sharable 2\KYC_Tool_Sharable\EntityKYC_Frontend"
    > npm start
Wait for it to compile and show webpack compiled successfully
The app will open at http://localhost:3015

**Step 2: Start the Backend (in a new terminal)**
Open a new terminal window
Run these commands:
> cd "c:\Users\ZH168VY\OneDrive - EY\2026\KYC_Tool_Sharable 2"
.\.venv\Scripts\python.exe .\KYC_Tool_Sharable\Backend\main.py
Wait for Flask to start (you'll see "Running on" message)
Backend runs on http://localhost:5003

**Step 3: Login**
Go to http://localhost:3015 in your browser
Use these credentials:
Username: user1
Password: 1234
Click Login and you're in!


### Latest 
(.venv) PS C:\Users\ZH168VY\OneDrive - EY\2026\KYC_Tool_Sharable 2\KYC_Tool_Sharable\EntityKYC_Frontend> npm start

(.venv) PS C:\Users\ZH168VY\OneDrive - EY\2026\KYC_Tool_Sharable 2\KYC_Tool_Sharable\Backend>  ..\..\\.venv\Scripts\python.exe main.py

(.venv) PS C:\Users\ZH168VY\OneDrive - EY\2026\KYC_Tool_Sharable 2\KYC_Tool_Sharable\Backend>  ..\..\\.venv\Scripts\python.exe main_individual.py